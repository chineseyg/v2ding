/**
 * Senflare Link Lite — Login 登录逻辑
 */
(function () {
    var REMEMBER_KEY = 'sf_lite_remember';           // 记住密码：本地存账号密码，下次自动回填

    var showToast = window.showToast;   // Toast 唯一实现在 admin.js，此处仅别名引用

    // 回填记住的账号密码（勾选「记住密码」登录过才会存在）
    try {
        var saved = JSON.parse(localStorage.getItem(REMEMBER_KEY) || 'null');
        if (saved && saved.u) {
            document.getElementById('username').value = saved.u;
            document.getElementById('password').value = saved.p || '';
            document.getElementById('rememberPwd').checked = true;
        }
    } catch (e) {}

    // 自动登录：已有未过期令牌直接进后台
    (function checkAutoLogin() {
        if (!window.LiteAPI) return;                 // API 层缺失时不拦截（纯静态预览）
        if (!window.LiteAPI.loginExpired()) location.replace('/sf-admin');
    })();

    document.getElementById('loginForm').addEventListener('submit', async function (e) {
        e.preventDefault();
        var username = document.getElementById('username').value.trim();
        var password = document.getElementById('password').value;
        var btn = document.getElementById('adminLoginBtn');

        if (!username || !password) {
            showToast('请输入账号和密码', true);
            return;
        }

        var remember = document.getElementById('rememberPwd').checked;
        btn.textContent = '验证中...';
        btn.disabled = true;

        var r = window.LiteAPI ? await window.LiteAPI.login(username, password) : null;
        if (!r || !r.token) {
            btn.textContent = '登 录';
            btn.disabled = false;
            return;                                   // 错误 Toast 已由 API 层统一弹出
        }

        try {
            window.LiteAPI.setToken(r.token);         // 令牌必须落库，否则后续所有 /api 调用都是未授权
            localStorage.setItem('sf_lite_login_time', String(Date.now()));
            if (remember) localStorage.setItem(REMEMBER_KEY, JSON.stringify({ u: username, p: password }));
            else localStorage.removeItem(REMEMBER_KEY);
        } catch (e) {}
        showToast('登录成功');
        setTimeout(function () { location.href = '/sf-admin'; }, 400);
    });

    // ==================== 登录页壁纸（刷新随机一张，停留期间静止） ====================
    // 图源：Firefly 主题 banner（assets/images/wallpapers/）。
    // 刷新时在 6 张中随机挑一张静止展示，不再 8s 自动轮播。
    // 桌面横版 / 移动竖版两套，按 1024px 断点选用。
    var WALLPAPERS_DESKTOP = [
        'assets/images/wallpapers/banner-1.webp',
        'assets/images/wallpapers/banner-2.webp',
        'assets/images/wallpapers/banner-3.webp'
    ];
    var WALLPAPERS_MOBILE = [
        'assets/images/wallpapers/banner-mobile-1.webp',
        'assets/images/wallpapers/banner-mobile-2.webp',
        'assets/images/wallpapers/banner-mobile-3.webp'
    ];
    (function initWallpaper() {
        // 已配置第三方/自定义壁纸时，交给 js/theme.js 的 initLoginBg() 处理（接口背景/自定义直链），
        // 本模块只负责「源站壁纸」随机；未配置/源站时才接管
        var bgSrc = '';
        try { bgSrc = localStorage.getItem('sf_lite_bg_source') || ''; } catch (e) {}
        if (bgSrc && bgSrc !== 'builtin') return;
        var root = document.getElementById('bgSlides');
        if (!root) return;
        var REDUCED = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
        var isDesktop = !window.matchMedia || matchMedia('(min-width: 1024px)').matches;
        var list = isDesktop ? WALLPAPERS_DESKTOP : WALLPAPERS_MOBILE;
        var pick = list[Math.floor(Math.random() * list.length)];
        var cls = isDesktop ? 'only-desktop' : 'only-mobile';
        // 预加载选中图，成功后替换为单张静止背景；失败保留 HTML 首帧兜底
        var im = new Image();
        im.onload = function () {
            root.innerHTML = '';
            var slide = document.createElement('div');
            slide.className = 'bg-slide active ' + cls;
            if (REDUCED) slide.style.transition = 'none';
            slide.style.backgroundImage = 'url("' + pick + '")';
            root.appendChild(slide);
        };
        im.onerror = function () {
            // 加载失败：仍清理隐藏断点的冗余节点，仅保留可见那张
            var slides = root.querySelectorAll('.bg-slide');
            for (var i = slides.length - 1; i >= 0; i--) {
                if (slides[i].offsetParent === null) slides[i].remove();
            }
        };
        im.src = pick;
    })();
})();
