/**
 * Senflare Link Lite - 子后端
 */

import { connect } from 'cloudflare:sockets';

// ==================== 1. 核心凭证 ====================

const AdminVersion = 'v4.4.5'; // 子后端版本（/api/version 输出）
const SyncKey = '67e9cbf4ce525fc6323c326ffcd562442c257a548e79eb7a'; // 子后端通信密钥（须与主后端一致，二创请修改）

// ==================== 2. 全局配置 ====================

const NodeDefaults = {

  UUID: '07890f07-c112-4bc6-9dff-10e3915d73eb',   // 订阅凭证（与主后端同步，优先级：D1 > 内置默认值；唯一保留的兜底默认——D1 不可用窗口内没有它节点无法认证）

  ProxyIPMode: '',        // 反代模式: OFFICIAL(官方反代) / AUTO(智能匹配) / 固定地区码(池内18区) / CUSTOM(自定义出口) / LOCAL(在线优选)，空 = AUTO
  ProxyIP: '',            // 反代出口（CUSTOM 用）：内联列表或 API URL（拉取缓存 5 分钟），留空回落 AUTO
  LocalProxyIP: '',       // Local 模式的在线优选出口
  ProxyIPMax: '',         // 兜底反代（所有模式失效时回退），空 = 无兜底，等面板同步
  ChainEnabled: false,    // 链式代理开关
  Upstream: '',           // 上游链式出口（链式开关开启时生效）
  Outbound: '',           // 出站模式: auto(智能分流：CF直连优先，失败切反代/链式，保留兜底) / global(全局代理：开链式全走链式，否则CF直连优先+CF站固定IP，无兜底)，空 = auto
  Doh: '',                // DoH 劫持: auto(双端点竞速) / 自定义单端点 URL，空 = auto
  Cache: true,            // 配置缓存总开关（空值同样视为开，D1 值优先）
};

const ConfigKeys = ['UUID', 'ProxyIPMode', 'ProxyIP', 'LocalProxyIP', 'ProxyIPMax', 'ChainEnabled', 'Upstream', 'Outbound', 'Doh', 'Cache'];   // 配置键白名单
const ConfigTtl = 5 * 60 * 1000;   // 配置缓存时长（5 分钟）

// ==================== 3. 运行时状态与配置加载 ====================

let runtimeEnv = null;   // 运行时 env 引用
const textDecoder = new TextDecoder();   // 全局编解码器

/** 恒定时间字符串比较（长度差不早退） */
const safeEqual = (a, b) => {
  const x = String(a ?? ''), y = String(b ?? '');
  let diff = x.length ^ y.length;
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) diff |= x.charCodeAt(i) ^ y.charCodeAt(i);
  return diff === 0;
};

let nodeConf = null, nodeConfTime = 0, nodeConfInflight = null, nodeConfFailUntil = 0, confGeneration = 0;   // 节点配置缓存、加载去重、D1 故障退避、推送代数

/** 出站模式归一 */
const applyOutboundRules = (conf) => {
  let outbound = String(conf.Outbound ?? '').trim().toLowerCase();
  if (outbound === 'fixed') conf.Outbound = outbound = 'global';   // 旧值 fixed 归一为 global（两模式制）
  const chainOff = conf.ChainEnabled !== true;
  let mode = String(conf.ProxyIPMode || '').toUpperCase();
  if (outbound === 'global' && chainOff && mode !== 'CUSTOM' && mode !== 'LOCAL') mode = conf.ProxyIPMode = 'CUSTOM';   // 全局未开链式 = 固定 IP 语义，出口须为列表型
  if ((mode === 'CUSTOM' || mode === 'LOCAL') && !hasPoolSource(mode === 'LOCAL' ? conf.LocalProxyIP : conf.ProxyIP)) conf.ProxyIPMode = mode = 'AUTO';
};

/** 加载节点配置（5 分钟缓存 + 去重 + 30s 故障退避 + D1 8s 超时兜底 + 推送代数校验） */
const loadNodeConfig = async () => {
  const now = Date.now(), cacheOn = (nodeConf?.Cache ?? NodeDefaults.Cache) !== false;
  if (cacheOn && nodeConf && now - nodeConfTime < ConfigTtl) return nodeConf;
  if (cacheOn && now < nodeConfFailUntil) return nodeConf ?? { ...NodeDefaults };
  if (nodeConfInflight) return nodeConfInflight;
  nodeConfInflight = (async () => {

    // 推送竞态防护
    for (let gen = confGeneration; ;) {
      const conf = { ...NodeDefaults }, db = runtimeEnv?.Senflare;
      let loaded = false;
      if (db) {
        let killer;
        try {
          const query = db.prepare(`SELECT key, value FROM config WHERE key IN (${ConfigKeys.map(() => '?').join(',')})`).bind(...ConfigKeys).all();
          query.catch(() => { });   // 超时败者拒绝兜底
          const { results } = await Promise.race([query, new Promise((_, rej) => { killer = setTimeout(() => rej(new Error('d1-timeout')), 8000); })]);   // D1 挂起时新会话全被拖死，8s 强制回落旧缓存/默认
          for (const row of results) try { conf[row.key] = JSON.parse(row.value); } catch { conf[row.key] = row.value; }
          loaded = true;
        } catch { }
        finally { clearTimeout(killer); }
      } else loaded = true;   // 无 D1 绑定：纯默认即最终配置
      if (loaded && gen === confGeneration) {
        applyOutboundRules(conf);
        nodeConf = conf, nodeConfTime = Date.now();
        return conf;
      }
      if (!loaded) return (nodeConfFailUntil = Date.now() + 30 * 1000), nodeConf ?? conf;
      gen = confGeneration;   // 缓存过期：再读一轮
    }
  })();
  try { return await nodeConfInflight; } finally { nodeConfInflight = null; }
};

/** 校验 UUID 形态（8-4-4-4-12 十六进制，大小写均可） */
const isValidUuid = (s) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);

/** 生效 UUID：优先级 D1 > 内置默认值 */
const getUuid = () => {
  const cfg = String(nodeConf?.UUID || '').trim();
  return isValidUuid(cfg) ? cfg.toLowerCase() : NodeDefaults.UUID;
};

let uuidBytesFor = '', uuidBytes = null;   // UUID 二进制
const getUuidBytes = () => {
  const uuid = getUuid();
  if (uuidBytesFor !== uuid) uuidBytes = Uint8Array.from(uuid.replace(/-/g, '').match(/../g), (hex) => parseInt(hex, 16)), uuidBytesFor = uuid;
  return uuidBytes;
};

// ==================== 4. 通用工具 ====================

/** 二进制地址转字符串（addrType：1=IPv4 / 2=域名 / 3=IPv6） */
const binaryAddrToString = (addrType, addrBytes) => {
  if (addrType === 2) return textDecoder.decode(addrBytes);
  if (addrType === 1) return `${addrBytes[0]}.${addrBytes[1]}.${addrBytes[2]}.${addrBytes[3]}`;
  let ipv6 = ((addrBytes[0] << 8) | addrBytes[1]).toString(16);
  for (let i = 1; i < 8; i++) ipv6 += ':' + ((addrBytes[i * 2] << 8) | addrBytes[i * 2 + 1]).toString(16);
  return `[${ipv6}]`;
};

/** 是否方括号包裹（IPv6 字面量形态） */
const isBracketed = (s) => s.startsWith('[');

/** 解析 host:port 条目（支持 IPv6 [host]:port / 裸 IPv6 自动补方括号，#备注忽略） */
const parseHostPort = (entry) => {
  const raw = String(entry || '').trim();
  if (!raw) return null;
  const endpoint = raw.split('#')[0].trim();
  let host = endpoint, port = null;
  if (isBracketed(endpoint)) {
    // IPv6: [host]:port
    const idx = endpoint.indexOf(']:');
    if (idx !== -1) host = endpoint.substring(0, idx + 1), port = parseInt(endpoint.substring(idx + 2)) || null;
  } else {
    const idx = endpoint.lastIndexOf(':');
    if (idx !== -1 && endpoint.indexOf(':') === idx) host = endpoint.substring(0, idx), port = parseInt(endpoint.substring(idx + 1)) || null;
    else if (idx !== -1) host = `[${endpoint}]`;   // 裸 IPv6（多冒号）整体视作地址补方括号
  }
  return host ? { host, port } : null;
};

/** 合法出口主机：域名 / IPv4 / 方括号 IPv6（裸 IPv6 已由 parseHostPort 补括号） */
const NodeHostRe = /^(\[[\da-fA-F:]+\]|[\w.-]+)$/;

/** 出口源有效性：直链或可解析条目均算有效 */
const hasPoolSource = (src) => String(src || '').trim().split(/[\r\n]+/).some((line) => /^https?:\/\//i.test(line.trim()) || line.split(/[,，、]+/).some((s) => parseHostPort(s.trim())));

const readCappedBody = async (body, cap) => {
  if (!body) return '';
  const reader = body.getReader(), parts = [];
  let total = 0;
  for (; ;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > cap) {
      try { reader.cancel().catch(() => { }); } catch { }
      return null;
    }
    parts.push(value);
  }
  const merged = new Uint8Array(total);
  let off = 0;
  for (const p of parts) merged.set(p, off), off += p.byteLength;
  return textDecoder.decode(merged);
};

// ==================== 5. 首包解析（协议解析） ====================

/** 解析协议头：Ver(1) + UUID(16) + OptLen(1) + Opt(N) + Cmd(1) + Port(2) + AddrType(1) + Addr(N) */
const parseProtocolChunk = (chunk) => {
  const len = chunk.length, result = { success: false, needMore: false, handshake: null, parsedRequest: null };
  if (len < 17) return (result.needMore = true), result;
  const uuidKey = getUuidBytes();
  let uuidDiff = 0;
  for (let i = 0; i < 16; i++) uuidDiff |= chunk[i + 1] ^ uuidKey[i];
  if (uuidDiff) return result;   // 恒时累计：与 safeEqual 口径一致，不因匹配位置早退
  if (len < 18) return (result.needMore = true), result;
  const offset = 19 + chunk[17];
  if (len < offset + 4) return (result.needMore = true), result;
  const addrType = chunk[offset + 2];
  const addrLen = addrType === 2 ? (offset + 3 < len ? chunk[offset + 3] : null) : addrType === 1 ? 4 : addrType === 3 ? 16 : -1;
  if (addrLen === null) return (result.needMore = true), result;
  if (addrLen > 0) {
    const addrOffset = addrType === 2 ? offset + 4 : offset + 3, dataOffset = addrOffset + addrLen;
    if (len < dataOffset) return (result.needMore = true), result;
    result.handshake = new Uint8Array([chunk[0], 0]);
    result.success = true;
    // cmd：0x01=TCP / 0x02=UDP / 0x03=MUX
    result.parsedRequest = { cmd: chunk[18 + chunk[17]], addrType, addrBytes: chunk.subarray(addrOffset, addrOffset + addrLen), dataOffset, port: (chunk[offset] << 8) | chunk[offset + 1] };
    return result;
  }
  return result;
};

// ==================== 6. 传输层（看门狗与管道） ====================

const MaxChunkLen = 64 * 1024;                          // 单次切片上限：64KB
const MaxQueuedBytes = 8 * 1024 * 1024;                 // 入站队列字节上限：8MB
const QueueSlots = 2048;                                // 入站环形队列槽位
const UpBufferLen = 32 * 1024;                          // 上行攒包缓冲：32KB
const PipeBufferLen = 512 * 1024;                       // 下行攒包缓冲：512KB
const PipeSafeLen = PipeBufferLen - MaxChunkLen;        // 下行出帧水位：攒过 ~448KB 即出帧
const PipeFlushMs = 2;                                  // 攒包出帧节奏（ms，上下行共用）
const FirstByteFloor = 10000, FirstByteCeil = 20000;    // 首字节看门狗阈值下/上限（ms）：出口首包 EMA × 4
const exitStats = new Map();                            // 出口首包延迟 EMA，喂看门狗自适应阈值

/** 记录出口首包延迟 EMA */
const recordFirstByte = (exitKey, ms) => {
  if (!exitKey) return;
  if (exitStats.size >= 256 && !exitStats.has(exitKey)) exitStats.delete(exitStats.keys().next().value);
  const s = exitStats.get(exitKey);
  exitStats.set(exitKey, { ema: s ? s.ema + (ms - s.ema) * 0.25 : ms });
};

/** 看门狗自适应阈值 */
const firstByteTimeout = (exitKey) => {
  const ema = exitKey ? exitStats.get(exitKey)?.ema : 0;
  return Math.min(Math.max(FirstByteFloor, (ema ?? 0) * 4), FirstByteCeil);
};

// ---------- 出口失败记忆（看门狗写入，拨号过滤读取） ----------
const ConnectTimeout = 1000, DirectDialRace = 2;   // TCP 建连超时（ms）/ 直连同端竞速连接数（主连 + 备胎，省子请求）

/** 带超时的 TCP 建连：超时即关闭半开 socket 并抛错 */
const connectWithTimeout = async (hostname, port) => {
  if (isBracketed(hostname) && hostname.endsWith(']')) hostname = hostname.slice(1, -1);
  const socket = connect({ hostname, port });
  let killer;
  try {
    await Promise.race([socket.opened, new Promise((_, reject) => { killer = setTimeout(() => reject(new Error('connect-timeout')), ConnectTimeout); })]);
    return socket;
  } catch (e) {
    try { socket.close()?.catch?.(() => { }); } catch { }
    throw e;
  } finally { clearTimeout(killer); }
};

// ---------- 候选连接 ----------
const ProxyFailTtl = 30 * 1000;   // 拨败记忆 TTL

const socks5Handshake = async (writer, reader, chain, targetPort) => {
  const enc = new TextEncoder();
  const auth = chain.username && chain.password;
  await writer.write(new Uint8Array(auth ? [5, 2, 0, 2] : [5, 1, 0]));
  let r = await reader.read();
  if (r.done || r.value.byteLength < 2) throw new Error();
  if (r.value[1] === 2) {
    if (!auth) throw new Error();
    const u = enc.encode(chain.username), p = enc.encode(chain.password);
    await writer.write(new Uint8Array([1, u.length, ...u, p.length, ...p]));
    r = await reader.read();
    if (r.done || r.value.byteLength < 2 || r.value[1] !== 0) throw new Error();
  } else if (r.value[1] !== 0) throw new Error();
  const host = enc.encode(chain.target);
  await writer.write(new Uint8Array([5, 1, 0, 3, host.length, ...host, targetPort >> 8, targetPort & 255]));
  r = await reader.read();
  if (r.done || r.value.byteLength < 2 || r.value[1] !== 0) throw new Error();
};

const httpConnectHandshake = async (writer, reader, chain, targetPort) => {
  const auth = chain.username && chain.password ? `Proxy-Authorization: Basic ${btoa(chain.username + ':' + chain.password)}\r\n` : '';
  await writer.write(new TextEncoder().encode(`CONNECT ${chain.target}:${targetPort} HTTP/1.1\r\nHost: ${chain.target}:${targetPort}\r\n${auth}\r\n`));
  let buf = new Uint8Array(0);
  for (; ;) {
    const r = await reader.read();
    if (r.done || !r.value) throw new Error();
    const merged = new Uint8Array(buf.length + r.value.byteLength);
    merged.set(buf), merged.set(r.value, buf.length);
    const idx = merged.findIndex((_, i) => i < merged.length - 3 && merged[i] === 13 && merged[i + 1] === 10 && merged[i + 2] === 13 && merged[i + 3] === 10);
    if (idx !== -1) {
      const status = /^HTTP\/\d\.\d\s+(\d{3})/.exec(new TextDecoder().decode(merged.subarray(0, idx + 4)));
      const code = status ? +status[1] : 0;
      if (code < 200 || code >= 300) throw new Error();
      return;
    }
    if (merged.length > 8192) throw new Error();
    buf = merged;
  }
};

const chainConnect = async (c, targetPort) => {
  const socket = await connectWithTimeout(c.host, c.port);
  try {
    const writer = socket.writable.getWriter(), reader = socket.readable.getReader();
    try {
      if (c.chain.type === 'socks5') await socks5Handshake(writer, reader, c.chain, targetPort);
      else await httpConnectHandshake(writer, reader, c.chain, targetPort);
      return { socket };
    } finally {
      try { writer.releaseLock(); } catch { }
      try { reader.releaseLock(); } catch { }
    }
  } catch (e) {
    try { socket.close()?.catch?.(() => { }); } catch { }
    throw e;
  }
};

const failedProxies = new Map();   // 看门狗周期自校正
const proxyFailKey = (c, port) => `${c.host}:${c.port ?? port}`;
const proxyFailedRecently = (key) => (failedProxies.get(key)?.until ?? 0) > Date.now();

/** 记录出口失败 */
const markProxyKey = (key, base = ProxyFailTtl) => {
  const prev = failedProxies.get(key);
  const strikes = prev && prev.until > Date.now() ? prev.strikes + 1 : 1;
  failedProxies.set(key, { until: Date.now() + Math.min(base * 2 ** (strikes - 1), BlackholeTtlMax), strikes });
  if (failedProxies.size > 256) for (const [k, v] of failedProxies) if (v.until <= Date.now()) failedProxies.delete(k); 
};
const markProxiesFailed = (candidates, port) => { for (const c of candidates) markProxyKey(proxyFailKey(c, port)); };

const BlackholeBase = 60 * 1000, BlackholeTtlMax = 10 * 60 * 1000;   // 黑洞黑名单起步/上限（ms）：连续失败时长翻倍

/** BYOB 下行管道：攒包出帧（2ms / 448KB 水位），首字节看门狗自适应断开 */
const manualPipe = async (state) => {
  const pipeStart = Date.now();   // 首包延迟采样起点
  let bufView = new Uint8Array(PipeBufferLen), spare = new ArrayBuffer(MaxChunkLen), offset = 0, timerId = null, pendingSend = null;
  let isReading = false, needsFlush = false, protect = false, sendError = null;
  const flush = () => {
    if (isReading) return (needsFlush = true);
    timerId && (clearTimeout(timerId), (timerId = null));
    if (offset > 0) {
      try {
        const sent = state.writable.send(bufView.subarray(0, offset));
        pendingSend = sent && typeof sent.catch === 'function' ? sent : null;
        pendingSend && pendingSend.catch((e) => (sendError ||= e));
      } catch (e) { sendError ||= e; }
      offset = 0;
    }
    needsFlush = false, protect = false;
  };

  const reader = state.tcpSocket.readable.getReader({ mode: 'byob' });

  // 首字节看门狗
  let firstByte = false;
  const stall = firstByteTimeout(state.exitKey);
  let stallTimer = setTimeout(() => {
    stallTimer = null;
    if (firstByte) return;
    try { reader.cancel().catch(() => { }); } catch { }
    state.close(), state.exitKey && markProxyKey(state.exitKey, BlackholeBase);
    console.log(`[看门狗] 出口 ${state.exitKey || '未知'} ${stall}ms 无首字节，断开并记失败`);
  }, stall);
  const clearStall = () => { if (stallTimer) (clearTimeout(stallTimer), (stallTimer = null)); };
  let done, value;
  try {
    while (true) {
      if (sendError) throw sendError;
      if (offset > 0 && protect) {
        ({ done, value } = await reader.read(new Uint8Array(spare, 0, MaxChunkLen)));
        if (!done && value) (bufView.set(value, offset), (spare = value.buffer));
      } else {
        isReading = offset > 0;
        ({ done, value } = await reader.read(new Uint8Array(bufView.buffer, offset, MaxChunkLen)));
        isReading = false;
        if (value) bufView = new Uint8Array(value.buffer);
      }
      if (done) break;
      const chunkLen = value?.byteLength || 0;
      if (!chunkLen) {
        needsFlush && flush();
        continue;
      }
      if (!firstByte) (firstByte = true), clearStall(), recordFirstByte(state.exitKey, Date.now() - pipeStart);
      offset += chunkLen;
      if (needsFlush) {
        flush();
        continue;
      }
      protect = chunkLen < MaxChunkLen;
      timerId ||= setTimeout(() => { timerId = null, flush(); }, PipeFlushMs);
      offset > PipeSafeLen && (await pendingSend, flush()); 
    }
  } catch {
    offset = 0, state.close();
  } finally {
    clearStall(), (timerId && (clearTimeout(timerId), (timerId = null))), (isReading = false), flush();
    if (sendError) state.close(); 
  }
};

/** 上行写手：小包攒 32KB / 2ms 出帧，超帧直通 */
const createBufferedTcpWriter = (tcpWriter, close) => {
  const buffer = new Uint8Array(UpBufferLen);
  let offset = 0, timerId = null, closed = false;
  const closeWriter = () => {
    if (closed) return;
    closed = true;
    timerId && (clearTimeout(timerId), (timerId = null));
    close?.();
  };
  const safeWrite = (data) => { try { tcpWriter.write(data).catch(() => closeWriter()); } catch { closeWriter(); } };
  const flush = () => {
    timerId && (clearTimeout(timerId), (timerId = null));
    if (!offset || closed) return;
    const len = offset;
    offset = 0, safeWrite(buffer.subarray(0, len));
  };
  return (chunk) => {
    if (closed) return;
    const data = chunk.constructor === Uint8Array ? chunk : new Uint8Array(chunk), len = data.byteLength;
    if (!len) return;
    if (len > UpBufferLen) return flush(), safeWrite(data);
    offset + len > UpBufferLen && flush();
    buffer.set(data, offset), offset += len;
    if (offset === UpBufferLen) flush();
    else timerId ||= setTimeout(flush, PipeFlushMs);
  };
};

/** 微任务环形队列 */
const createAsyncMicrotaskQueue = (consume, close) => {
  const queue = new Array(QueueSlots), mask = QueueSlots - 1;
  let head = 0, tail = 0, size = 0, queuedBytes = 0;
  let drainActive = false, closed = false, idleNotify = null;
  const closeQueue = () => {
    if (closed) return;
    closed = true;
    queue.fill(null), queuedBytes = 0;
    close?.();
    const notify = idleNotify;
    (idleNotify = null), notify?.();
  };
  const shift = () => {
    const chunk = queue[head];
    (queue[head] = null), (head = (head + 1) & mask), size--, (queuedBytes -= chunk.byteLength);
    return chunk;
  };
  const notifyIfIdle = () => {
    if (size === 0 && !drainActive && idleNotify) {
      const notify = idleNotify;
      (idleNotify = null), notify();
    }
  };
  const drainQueue = async () => {
    if (closed) return;
    try {
      while (size > 0 && !closed) await consume(shift());
    } catch { closeQueue(); } finally { (drainActive = false), notifyIfIdle(); }
  };
  const enqueue = (chunk) => {
    if (closed) return;
    chunk = chunk.constructor === Uint8Array ? chunk : new Uint8Array(chunk);
    if (size === QueueSlots || queuedBytes + chunk.byteLength > MaxQueuedBytes) return closeQueue();
    (queue[tail] = chunk), (tail = (tail + 1) & mask), size++, (queuedBytes += chunk.byteLength);
    if (!drainActive) (drainActive = true), queueMicrotask(drainQueue);
  };
  /** 队列已空时立即回调 */
  enqueue.onIdle = (cb) => {
    if (closed || (size === 0 && !drainActive)) return cb();
    idleNotify = cb;
  };
  enqueue.close = closeQueue;   // 提前终止 drain：会话关闭后的积压帧不再逐帧解析
  return enqueue;
};

// ==================== 7. 直连分流（建立连接） ====================

// ---------- 官方反代池：按本机出口 colo 拼官方代理域名，colo 子域失联回落裸域 ----------
const OfficialProxyBase = 'p' + 'r' + 'o' + 'x' + 'y' + '.' + 'z' + 'j' + 'c' + 'l' + 'o' + 'u' + 'd' + '.' + 'u' + 's' + '.' + 'c' + 'i';   // 官方反代裸域（拆字避明文）
const officialProxyHost = (colo) => (colo ? `${colo.toLowerCase()}.${OfficialProxyBase}` : OfficialProxyBase);
const TierSub = 0, TierBase = 1;   // 官方反代拨号层：0=colo 子域、1=裸域

// ---------- 三方反代池（SenflareLink，维护周期 3 小时/次） ----------
const SenflareLink = 'S' + 'e' + 'n' + 'f' + 'l' + 'a' + 'r' + 'e' + 'L' + 'i' + 'n' + 'k' + '.' + 'k' + 'd' + 'n' + 's' + '.' + 'f' + 'r';   // 反代池域名（拆字避明文）
const ProxyIPPool = 'HK TW JP KR SG IN GB FR DE NL SE FI PL RU CH LV US CA'.split(' ').map((region) => ({ domain: 'P' + 'r' + 'o' + 'x' + 'y' + '-' + region + '.' + SenflareLink, region }));

/** 出口列表按目标确定性乱序：同一目标永远先试同一个出口（会话粘住），不同目标顺序不同（流量摊匀） */
const stickyShuffle = (list, seedText) => {
  let seed = 0;
  for (let i = 0; i < seedText.length; i++) seed = (seed + seedText.charCodeAt(i)) | 0;
  const out = [...list];
  for (let i = out.length - 1, j; i > 0; i--) (seed = (seed * 1103515245 + 12345) & 0x7fffffff), (j = seed % (i + 1)), ([out[i], out[j]] = [out[j], out[i]]);   // 线性同余风格确定性乱序（仅保同输入同序）
  return out;
};

/** 解析上游链式条目值 [user:pass@]host[:port]（@ 取最后一个，剥尾部 /，XHTTP 客户端会自动追加） */
const parseUpstreamAddr = (value, type) => {
  const raw = String(value || '').trim().split('#')[0].replace(/\/+$/, '');
  if (/[\s?]/.test(raw)) return null;   // 空格破坏 HTTP 请求行、? 截断内联路径，凭据不支持
  const at = raw.lastIndexOf('@');
  const auth = at === -1 ? '' : raw.slice(0, at);
  const m = /^(\[[^\]]*\]|[^:]+)(?::(\d+))?$/.exec(at === -1 ? raw : raw.slice(at + 1));
  if (!m || !NodeHostRe.test(m[1])) return null;
  const colon = auth.indexOf(':');
  return { type, username: at === -1 ? '' : (colon === -1 ? auth : auth.slice(0, colon)), password: at === -1 ? '' : (colon === -1 ? '' : auth.slice(colon + 1)), host: m[1], port: m[2] ? +m[2] : (type === 'socks5' ? 1080 : 80) };
};

/** 解析上游链式代理条目 */
const parseUpstreamEntries = (src) => String(src || '')
  .split(/[\r\n,，、]+/)
  .map((s) => s.trim())
  .filter(Boolean)
  .map((s) => {
    const hash = s.indexOf('#');
    const line = hash === -1 ? s : s.slice(0, hash);
    const m = /^(socks5|http):\/\//i.exec(line);
    if (!m) return null;
    const e = parseUpstreamAddr(line.slice(m[0].length), m[1].toLowerCase());
    return e ? { ...e, name: hash === -1 ? '' : s.slice(hash + 1).trim() } : null;
  })
  .filter(Boolean);

/** 解析反代候选 */
const resolveProxyCandidates = async (conf, request, target) => {
  const mode = String(conf.ProxyIPMode || 'AUTO').toUpperCase(), region = request.cf?.country ?? '', colo = String(request.cf?.colo || '');

  // 链式代理开关：开启且上游有效时，出口整体切换为上游链式
  if (conf.ChainEnabled === true) {
    const list = parseUpstreamEntries(conf.Upstream);
    if (list.length) return stickyShuffle(list.map((e) => ({ host: e.host, port: e.port, via: e.host, chain: { ...e, target } })), target + String(conf.UUID ?? ''));
  }

  // OFFICIA
  if (mode === 'OFFICIAL') {
    const hosts = colo ? [[officialProxyHost(colo), TierSub], [officialProxyHost(null), TierBase]] : [[officialProxyHost(null), TierSub]];
    return hosts.map(([host, tier]) => ({ host, port: null, tier }));
  }

  // CUSTOM/LOCAL
  if (mode === 'CUSTOM' || mode === 'LOCAL') {
    const list = await resolvePoolEntries(mode === 'LOCAL' ? conf.LocalProxyIP : conf.ProxyIP, (conf.Cache ?? true) !== false);
    if (list.length) return stickyShuffle(list, target + String(conf.UUID ?? ''));
  }

  // 固定地区
  if (/^[A-Z]{2}$/.test(mode)) {
    const hit = ProxyIPPool.find((p) => p.region === mode);
    return hit ? [{ host: hit.domain, port: null }] : [];
  }

  // AUTO：只取同区池域名（层内竞速，全灭直接交给兜底反代）
  const picked = ProxyIPPool.filter((p) => p.region === region);
  return (await Promise.all(picked.map(async (p) =>
    (await resolveHostIps(p.domain)).map((e) => ({ host: e.host, port: e.port, via: p.domain }))
  ))).flat();
};

// ---------- 反代主机名 → IP 展开 ----------
const DnsTtl = 15 * 60 * 1000, DnsCacheMaxEntries = 256;   // 解析缓存 TTL / 最大条目
const dnsIpCache = new Map();

/** 判断主机名是否 IP 字面量（IPv4 点分十进制 / 方括号 IPv6），字面量免解析直接拨号 */
const isIpLiteral = (host) => isBracketed(host) || /^\d{1,3}(\.\d{1,3}){3}$/.test(host);

/** TXT 反代记录解析：按逗号/\010 转义/引号串边界拆分（不按空格拆，防内容被误切成假主机名），裸 IPv6 自动补括号，非法条目丢弃 */
const parseTxtProxies = (data) => String(data || '')
  .replace(/\\010/g, ',')
  .split(/[\r\n,，、]+|"\s*"/)
  .map((s) => s.trim().replace(/^"|"$/g, '').trim())
  .filter(Boolean)
  .map(parseHostPort)
  .filter((e) => e && NodeHostRe.test(e.host))
  .map((e) => ({ host: e.host, port: +e.port || 443 }));

/** DoH 查 TXT/A/AAAA：TXT 反代池优先，回落 A+AAAA，并发去重 */
const dnsInflight = new Map();
const resolveHostIps = (host) => {
  if (isIpLiteral(host)) return Promise.resolve([{ host, port: null }]);
  const hit = dnsIpCache.get(host);
  if (hit && Date.now() - hit.time < DnsTtl) return Promise.resolve(hit.entries);
  const pending = dnsInflight.get(host);
  if (pending) return pending;
  const p = (async () => {
    const query = (type) => fetch(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(host)}&type=${type}`, {
      headers: { accept: 'application/dns-json' }, signal: AbortSignal.timeout(3000),
    })
      .then((r) => (r.ok ? r.json() : null))
      .catch(() => null);
    const [txt, a, aaaa] = await Promise.all([query('TXT'), query('A'), query('AAAA')]);
    const txtEntries = (txt?.Answer ?? []).filter((r) => r.type === 16 && typeof r.data === 'string').flatMap((r) => parseTxtProxies(r.data)).slice(0, 4);
    const entries = txtEntries.length ? txtEntries : [
      ...(a?.Answer ?? []).filter((r) => r.type === 1 && typeof r.data === 'string').map((r) => ({ host: r.data, port: null })),
      ...(aaaa?.Answer ?? []).filter((r) => r.type === 28 && typeof r.data === 'string').map((r) => ({ host: r.data, port: null })),
    ].slice(0, 4);
    if (!entries.length) return hit ? hit.entries : [{ host, port: null }];
    if (dnsIpCache.size >= DnsCacheMaxEntries) dnsIpCache.delete(dnsIpCache.keys().next().value);
    return dnsIpCache.set(host, { entries, time: Date.now() }), entries;
  })();
  (dnsInflight.set(host, p)), p.then(() => dnsInflight.delete(host), () => dnsInflight.delete(host));
  return p;
};

// ---------- 远程出口池：CUSTOM/LOCAL 源支持 API 直链 ----------
const PoolTtl = 5 * 60 * 1000, PoolCacheMaxEntries = 50;   // 拉取缓存 TTL / 最大条目
const poolCache = new Map(), poolInflight = new Map();

/** base64 整段订阅体解码，非 base64 形态原样返回 */
const decodeSubBody = (text) => {
  const b64 = String(text || '').replace(/\s+/g, '');
  if (b64.length < 40 || b64.length % 4 === 1 || !/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) return text;
  try {
    const out = new TextDecoder().decode(Uint8Array.from(atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4)), (c) => c.charCodeAt(0)));
    return out.includes('://') ? out : text;
  } catch { return text; }
};

/** 出口源解析：直链去远端拉取（8s 超时），其余直接解析，缓存 5 分钟、并发去重，注释行与大小写重复条目过滤 */
const resolvePoolEntries = async (src, cacheOn = true) => {
  const raw = String(src || '').trim();
  if (!raw) return [];
  const now = Date.now();
  const cached = poolCache.get(raw);
  if (cacheOn && cached && now - cached.time < PoolTtl) return cached.list;
  const pending = poolInflight.get(raw);
  if (pending) return pending.then((list) => { if (cacheOn && list.length) poolCache.set(raw, { list, time: now }); return list; });   // 撞上去重的请求也按自己的 Cache 开关落缓存

  let remoteAllOk = true;
  const rawLines = raw.split(/[\r\n]+/).map((l) => l.trim()).filter(Boolean);
  const segments = [];
  for (const line of rawLines) {
    if (/^https?:\/\//i.test(line)) segments.push(line);
    else segments.push(...line.split(/[,，、]+/).map((s) => s.trim()).filter(Boolean));
  }
  const p = (async () => {
    const blocks = await Promise.all(
      segments.map(async (seg) => {
        if (!/^https?:\/\//i.test(seg)) return seg;
        try {
          const res = await fetch(seg, { signal: AbortSignal.timeout(8000) });
          if (!res?.ok) return (remoteAllOk = false), '';
          return decodeSubBody(await res.text());
        } catch { return (remoteAllOk = false), ''; }
      }),
    );
    const seen = new Set();
    return blocks
      .flatMap((block) => block.split(/[\r\n,，、]+/))
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#') && !l.startsWith('//'))
      .map(parseHostPort)
      .filter((e) => e && NodeHostRe.test(e.host))   // 主机合法性过滤，垃圾条目不进出站候选
      .filter((e) => {
        const k = e.host.toLowerCase() + ':' + e.port;
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });
  })();
  (poolInflight.set(raw, p)), p.then(() => poolInflight.delete(raw), () => poolInflight.delete(raw));
  const list = await p;
  if (cacheOn && remoteAllOk && list.length) {
    poolCache.set(raw, { list, time: now });
    if (poolCache.size > PoolCacheMaxEntries) poolCache.delete(poolCache.keys().next().value);
  }
  return list;
};

/** 连接日志：路由 | 目标 | 协议 | 出口 | 入口 | ASN */
const logConn = (request, route, entry) => {
  const cf = request?.cf || {};
  const exit = entry.host === entry.target ? '直连' : (entry.via && entry.via !== entry.host ? `${entry.host} ← 来自 ${entry.via}` : entry.host);
  const loc = [cf.colo, cf.country, cf.city].filter(Boolean).join(' / ') || '-';
  console.log(`[${route}] 目标 ${entry.target}:${entry.port} | ${cf.httpProtocol || '-'} | 出口 ${exit} | 入口 ${loc} | ASN ${cf.asn || '-'}`);
};


const ProxyDialBatch = 6;   // 每批并发连接数（对齐平台外连上限）

/** 候选竞速拨号：首包写给最快就绪的（链式候选含协议握手），写失败顺位换下一个 */
const raceDial = async (batch, targetPort, payload) => {
  const shut = (s) => { try { s.close()?.catch?.(() => { }); } catch { } };
  const pending = new Set();
  for (const c of batch) {
    const p = (c.chain ? chainConnect(c, targetPort) : connectWithTimeout(c.host, c.port ?? targetPort).then((socket) => ({ socket })))
      .then((r) => ({ ...r, host: c.host, cport: c.port, via: c.via, p }));
    pending.add(p), p.catch(() => pending.delete(p));
  }
  while (pending.size) {
    let first;
    try { first = await Promise.any(pending); } catch { break; }   // 这批全都没连上
    pending.delete(first.p);
    try {
      if (payload?.byteLength) {
        const writer = first.socket.writable.getWriter();
        try { await writer.write(payload); } finally { try { writer.releaseLock(); } catch { } }
      }
      for (const p of pending) p.then((r) => shut(r.socket)).catch(() => { });   // 落败者全部关闭，含此刻还没连上的
      return { socket: first.socket, host: first.host, cport: first.cport, via: first.via };
    } catch { shut(first.socket); }
  }
  throw new Error();
};

/** 逐批把整张候选表都试一遍，整批拨败记 30s 失败记忆（大池跨连接推进），失败返回 null */
const dialCandidates = async (candidates, targetPort, payload) => {
  for (let i = 0; i < candidates.length; i += ProxyDialBatch) {
    const batch = candidates.slice(i, i + ProxyDialBatch);
    try { return await raceDial(batch, targetPort, payload); } catch { markProxiesFailed(batch, targetPort); }
  }
  return null;
};

/** 建立连接 */
const establishTcpConnection = async (parsedRequest, request, payload) => {
  const port = parsedRequest.port, hostname = binaryAddrToString(parsedRequest.addrType, parsedRequest.addrBytes);

  // 内联出口：/proxyip= /pyip= /ip= 或 ?proxyip=
  const url = new URL(request.url);
  // 防呆设计：客户端可能对路径做 URL 编码（/ 变 %2F、= 变 %3D），解码后再匹配
  let pathname = url.pathname;
  try { pathname = decodeURIComponent(pathname); } catch { }
  const inlineRaw = (url.searchParams.get('proxyip') || url.searchParams.get('proxy') || pathname.match(/\/(?:proxyip|pyip|ip)[.=]([^\/?#\s]+)/i)?.[1] || '').replace(/\/+$/, '');
  const inlineParsed = inlineRaw ? parseHostPort(inlineRaw) : null, inlineExit = inlineParsed?.host || inlineRaw, inlineExitPort = inlineParsed?.port ?? null;
  // 路径内嵌链式：单连接锁定该上游，优先级最高
  let inlineChain = null;
  const mS5 = pathname.match(/\/socks5=([^?#]+)/i);
  if (mS5) inlineChain = parseUpstreamAddr(mS5[1].replace(/^socks5:\/\//i, ''), 'socks5');
  const mHt = !inlineChain && pathname.match(/\/http=([^?#]+)/i);
  if (mHt) inlineChain = parseUpstreamAddr(mHt[1].replace(/^https?:\/\//i, ''), 'http');
  const conf = await loadNodeConfig();
  const outbound = String(conf.Outbound || 'auto').trim().toLowerCase();   // 空串归 auto（与默认值空语义一致）
  const chainOn = conf.ChainEnabled === true && parseUpstreamEntries(conf.Upstream).length > 0;   // 链式开关：开启且上游有效
  const outboundLabel = { auto: '智能', global: '全局' }[outbound] || outbound;   // 出站模式中文标签
  const proxyModeLabel = { OFFICIAL: '官方反代', AUTO: '智能匹配', CUSTOM: '自定义出口', LOCAL: '在线优选' }[String(conf.ProxyIPMode || 'AUTO').toUpperCase()] || String(conf.ProxyIPMode || 'AUTO').toUpperCase();
  const proxyTag = (inlineChain || chainOn) ? '链式' : inlineExit ? '内联出口' : proxyModeLabel;
  const routeTag = `${outboundLabel} / ${proxyTag}`;   // 每条连接日志标明出站策略 + 出口类型
  const forceProxy = (outbound === 'global' && chainOn) || !!inlineChain;   // 全局+链式：全部流量走链式；全局未开链式与智能同为直连优先；路径内嵌链式恒跳过直连
  let tried = 0;

  // 候选预备与直连并行：直连失败时解析已就绪，冷目标省一次串行 DoH
  const prep = (inlineChain
    ? Promise.resolve([{ host: inlineChain.host, port: inlineChain.port, via: inlineChain.host, chain: { ...inlineChain, target: hostname } }])
    : inlineExit
      ? Promise.resolve([{ host: inlineExit, port: inlineExitPort }])
      : resolveProxyCandidates(conf, request, hostname)
  ).then(async (list) => {
    list = list.filter((c) => c?.host);
    if (list.length > 2) return list;
    const expanded = await Promise.all(list.map(async (c) =>
      c.chain ? [{ host: c.host, port: c.port, via: c.host, chain: c.chain }]   // 链式候选不预展开：上游主机交平台解析，端口已由条目给定
        : (await resolveHostIps(c.host)).map((e) => ({ host: e.host, port: e.port ?? c.port, via: c.host, tier: c.tier }))
    ));
    return expanded.flat();
  });

  // 一级：官方直连
  const directKey = `direct!${hostname}:${port}`;
  if (!forceProxy && !proxyFailedRecently(directKey)) {
    const direct = await raceDial(Array.from({ length: DirectDialRace }, () => ({ host: hostname, port })), port, payload).catch(() => null);
    if (direct) {
      logConn(request, `${outboundLabel} / 直连`, { target: hostname, port, host: direct.host });
      return { ...direct, exitKey: directKey };   // 直连黑洞记失败记忆（长 TTL），免反复白等看门狗
    }
    markProxyKey(directKey), tried++;   // 直连拨败：30s 内同目标跳过直连，省探测连接
  }

  // 二级：官方/三方反代(竞速)
  try {
    let candidates = await prep;
    const seen = new Set();
    candidates = candidates.filter((c) => !seen.has(`${c.host}:${c.port ?? port}`) && seen.add(`${c.host}:${c.port ?? port}`));
    if (candidates.length > 1) {
      const fresh = candidates.filter((c) => !proxyFailedRecently(proxyFailKey(c, port)));
      if (fresh.length) candidates = fresh;
    }
    candidates = candidates.slice(0, ProxyDialBatch * 2);   // 大池限额：单连接最多两批，配合逐批失败记忆跨连接推进
    tried += candidates.length;

    // 分层拨号
    const subLayer = [], baseLayer = [];
    for (const c of candidates) (c.tier === TierBase ? baseLayer : subLayer).push(c);
    const hit = (await dialCandidates(subLayer, port, payload)) ?? (baseLayer.length ? await dialCandidates(baseLayer, port, payload) : null);
    if (hit) {
      logConn(request, `${routeTag} → 命中`, { target: hostname, port, host: hit.host, via: hit.via });
      return { ...hit, exitKey: proxyFailKey({ host: hit.host, port: hit.cport }, port) };
    }
  } catch { }

  // 三级：兜底反代（仅智能分流保留）
  if (outbound === 'auto' && !inlineChain) {
    try {
      const fallback = parseHostPort(conf.ProxyIPMax);
      if (fallback?.host) {
        const batch = (await resolveHostIps(fallback.host)).map((e) => ({ host: e.host, port: e.port ?? fallback.port, via: fallback.host })).slice(0, ProxyDialBatch * 2);
        const usable = batch.filter((c) => !proxyFailedRecently(proxyFailKey(c, port))), tryBatch = usable.length ? usable : batch;
        tried += tryBatch.length;
        const hit = await dialCandidates(tryBatch, port, payload);
        if (hit) {
          logConn(request, `${routeTag} → 兜底命中`, { target: hostname, port, host: hit.host, via: hit.via });
          return { ...hit, exitKey: proxyFailKey({ host: hit.host, port: hit.cport }, port) };
        }
      }
    } catch { }
  }
  logConn(request, `${routeTag} → 全部失败`, { target: hostname, port, host: `全部失败（${tried} 个节点均无法连接）` });
  return null;
};

// ==================== 8. DoH 劫持（53 端口） ====================

/** DoH 默认端点：配置 auto 的展开（双端点竞速），与前端面板「双端点竞速」选项语义对应 */
const DohEndpoints = ['https://cloudflare-dns.com/dns-query', 'https://dns.google/dns-query'];

/** DoH 端点：合法 URL 单端点直用，否则默认双端点 */
const getDohEndpoints = async () => {
  const v = String((await loadNodeConfig()).Doh ?? '').trim();
  return /^https?:\/\//i.test(v) ? [v] : DohEndpoints;
};

// DoH 应答缓存（键 = 去 ID 报文解码串，TTL 固定）
const DohCacheMaxEntries = 256, DohTtlMs = 60 * 1000;
const dohCache = new Map();

/** 缓存命中应答 */
const cachedDohAnswer = (entry, dnsQuery) => {
  const out = new Uint8Array(new Uint8Array(entry.data));
  out[0] = dnsQuery[0], out[1] = dnsQuery[1];
  return out.buffer;
};

/** DoH 单端点请求：应答连同所用端点一并返回，竞速后记住赢家 */
const fetchDoh = async (endpoint, dnsQuery) => {
  const r = await fetch(endpoint, { method: 'POST', headers: { 'content-type': 'application/dns-message' }, body: dnsQuery, signal: AbortSignal.timeout(5000) });
  if (!r.ok) throw new Error();
  return { resp: await r.arrayBuffer(), endpoint };
};

/** DNS 查询转 DoH：缓存 → 并发去重 → 粘性端点单发、失败全端点竞速（5s 超时）→ 失效时用过期缓存兜底 */
const dohInflight = new Map();
let dohPreferred = null;   // 粘性 DoH 端点：上次竞速赢家
const textDecoderLatin1 = new TextDecoder('latin1'); 
const dohQuery = async (dnsQuery) => {
  const key = textDecoderLatin1.decode(dnsQuery.subarray(2)); 
  const hit = dohCache.get(key);
  if (hit && Date.now() < hit.expires) {
    dohCache.delete(key), dohCache.set(key, hit);
    return cachedDohAnswer(hit, dnsQuery);
  }
  const pending = dohInflight.get(key);
  if (pending) return pending.then((entry) => cachedDohAnswer(entry, dnsQuery));
  const p = (async () => {
    const endpoints = await getDohEndpoints();
    const race = () => Promise.any(endpoints.map((e) => fetchDoh(e, dnsQuery)));
    let resp;
    try {
      // 粘性：优先单发上次赢家省一个子请求，失败升级全端点竞速，单端点配置保持原样
      const winner = dohPreferred && endpoints.length > 1 && endpoints.includes(dohPreferred)
        ? await fetchDoh(dohPreferred, dnsQuery).catch(() => race())
        : await race();
      resp = winner.resp;
      dohPreferred = winner.endpoint;
    } catch (e) {
      const stale = dohCache.get(key);
      if (stale) {
        dohCache.delete(key), dohCache.set(key, stale);
        stale.expires = Date.now() + 10 * 1000;
        return stale;
      }
      throw e;
    }
    const entry = { data: resp, expires: Date.now() + DohTtlMs };
    dohCache.set(key, entry);
    if (dohCache.size > DohCacheMaxEntries) dohCache.delete(dohCache.keys().next().value);
    return entry;
  })();
  (dohInflight.set(key, p)), p.then(() => dohInflight.delete(key), () => dohInflight.delete(key));
  return p.then((entry) => cachedDohAnswer(entry, dnsQuery));
};

/** DNS 回包封装：查询转 DoH 应答并加 2 字节大端长度帧（TCP-DNS / UDP-DNS 共用） */
const dohResolve = async (dnsQuery) => {
  const body = new Uint8Array(await dohQuery(dnsQuery)), out = new Uint8Array(2 + body.byteLength);
  out[0] = body.byteLength >> 8, out[1] = body.byteLength & 0xff, out.set(body, 2);
  return out;
};

/** 长度前缀分帧（2 字节大端）：帧内查询并行转 DoH，0 长度帧即断 */
const feedFrames = async (chunk, state, remainKey) => {
  if (!chunk?.byteLength) return;
  const remain = state[remainKey];
  let buf = chunk;
  if (remain?.length) (buf = new Uint8Array(remain.length + chunk.length)).set(remain), buf.set(chunk, remain.length);
  let off = 0;
  const answers = [];
  while (buf.length - off >= 2) {
    const len = (buf[off] << 8) | buf[off + 1];
    if (!len) return (state[remainKey] = null), state.close(); 
    if (buf.length - off < 2 + len) break;
    answers.push(dohResolve(buf.subarray(off + 2, off + 2 + len)).then((data) => state.writable.send(data)).catch(() => { }));
    off += 2 + len;
  }
  if (off < buf.length && buf.length - off > 65537) return (state[remainKey] = null), state.close();
  state[remainKey] = off < buf.length ? buf.slice(off) : null;
  await Promise.all(answers);
};

/** UDP-DNS 入口：帧内为裸 DNS 报文 */
const feedUdpDns = (chunk, state) => feedFrames(chunk, state, 'udpRemain');

const DnsIdleTimeout = 5 * 60 * 1000;

/** TCP-DNS 会话：单连接多查询，空闲 5 分钟发 1000 关闭 */
const feedTcpDns = async (chunk, state) => {
  state.dnsIdleTimer && clearTimeout(state.dnsIdleTimer);
  state.dnsIdleTimer = setTimeout(() => ((state.dnsIdleTimer = null), state.close()), DnsIdleTimeout);   // 空闲发 1000 关闭
  return feedFrames(chunk, state, 'dnsRemain');
};

// ==================== 9. 会话管理与入口 ====================

/** 会话分派：已建连补写 TCP，53 端口转 DoH 劫持，TCP 首包解析建连后挂上下行管道 */
const handleSession = async (chunk, state, request) => {
  if (state.tcpWriter) return state.tcpWriter(chunk);
  if (state.tcpDns) return feedTcpDns(chunk, state);
  if (state.udpDns) return feedUdpDns(chunk, state);
  state.needMore = false;
  if (state.pendingHeader) {
    const merged = new Uint8Array(state.pendingHeader.length + chunk.length);
    merged.set(state.pendingHeader, 0), merged.set(chunk, state.pendingHeader.length);
    state.pendingHeader = null;
    chunk = merged;
  }
  const parsed = parseProtocolChunk(chunk);
  if (!parsed.success) {
    // 仅 WS 路径留存残帧（XHTTP 由调用方缓冲），鉴权失败：直接断开
    if (parsed.needMore) {
      state.needMore = true;
      if (!state.xwebPipeTo) {
        if (chunk.length > MaxChunkLen) return state.close();   // 残帧合并超 64KB：协议外流量（慢滴探测），断
        state.pendingHeader = chunk.slice();
      }
      return;
    }
    return state.close();
  }
  const parsedRequest = parsed.parsedRequest, payload = chunk.subarray(parsedRequest.dataOffset);

  // 53 端口：TCP/UDP 转 DoH 劫持（先回成功握手）
  if (parsedRequest.port === 53 && (parsedRequest.cmd === 1 || parsedRequest.cmd === 2)) {
    if (parsed.handshake) await state.writable.send(parsed.handshake);
    if (parsedRequest.cmd === 1) return (state.tcpDns = true), feedTcpDns(payload, state);
    return (state.udpDns = true), feedUdpDns(payload, state);
  }

  // 其他 UDP/MUX：不支持，只回挡板不回成功握手（避免「先成功后异常」的矛盾应答）
  if (parsedRequest.cmd !== 1) {
    if (!state.unsupported) state.unsupported = true, await state.writable.send(new Uint8Array([chunk[0], 0x01, 0x00]));   // 挡板：同会话只回一次
    return;
  }

  if (parsed.handshake) await state.writable.send(parsed.handshake);

  // 首包由 establishTcpConnection 写入
  const tcpResult = await establishTcpConnection(parsedRequest, request, payload);
  if (!tcpResult) return state.close();   // 建连全灭：静默回收
  state.tcpSocket = tcpResult.socket, state.exitKey = tcpResult.exitKey;   // 黑洞看门狗触发时记失败记忆
  if (state.xwebPipeTo) return;   // XHTTP：上行由调用方接管
  state.tcpWriter = createBufferedTcpWriter(state.tcpSocket.writable.getWriter(), state.close);   // 上行小包攒帧
  manualPipe(state).finally(() => state.close());   // 下行结束（EOF/异常/看门狗）即关会话
};

// ---------- 会话入口：WebSocket / XHTTP ----------

/** 会话资源收尾：清 DNS 空闲定时器、关出站 TCP */
const releaseSession = (state) => {
  state.dnsIdleTimer && (clearTimeout(state.dnsIdleTimer), (state.dnsIdleTimer = null));
  try { state.tcpSocket?.close(); } catch { }
};

/** WebSocket 会话入口：解析早数据（sec-websocket-protocol / Referer 两通道），建会话状态并接管消息流 */
const handleWebSocketConn = async (webSocket, request, confReady) => {
  const hostHeader = request.headers.get('host') || '', referer = request.headers.get('Referer');
  let earlyDataHeader = request.headers.get('sec-websocket-protocol');
  if (!earlyDataHeader && referer && hostHeader) {
    try {
      const refUrl = new URL(referer);
      if (refUrl.host === hostHeader) earlyDataHeader = (refUrl.pathname + refUrl.search).replace(/^\/+/, '') || null;
    } catch { }
  }
  let earlyData = null;
  if (earlyDataHeader) {
    try { earlyData = Uint8Array.fromBase64(earlyDataHeader, { alphabet: 'base64url', lastChunkHandling: 'loose' }); } catch { }   // 畸形 early-data 直接丢弃
  }
  const state = { upQueue: null, tcpWriter: null, tcpSocket: null, udpRemain: null, udpDns: null, tcpDns: null, dnsRemain: null, dnsIdleTimer: null, exitKey: null, writable: webSocket };
  let closing = false;
  const close = () => {
    if (closing) return;
    closing = true;
    try { webSocket.close(1000); } catch { }
    state.upQueue?.close?.();
    state.upQueue ? state.upQueue.onIdle(() => releaseSession(state)) : releaseSession(state);
  };
  state.close = close;
  const processingQueue = createAsyncMicrotaskQueue((chunk) => confReady.then(() => handleSession(chunk, state, request)), close);   // 监听器保持同步挂载，握手包在配置就绪后才解析
  state.upQueue = processingQueue;
  if (earlyData) processingQueue(earlyData);
  webSocket.addEventListener('message', (event) => {
    if (typeof event.data === 'string') return close();
    (state.tcpWriter || processingQueue)(event.data);   // 握手后消息直写 TCP，不再过队列
  });
  webSocket.addEventListener('error', () => close()), webSocket.addEventListener('close', () => close());
};

/** XHTTP 响应头：grpc-status 塞 header 系伪装 workaround（Workers 无 trailers） */
const XwebHeaders = { 'Content-Type': 'application/octet-stream', 'grpc-status': '0', 'X-Accel-Buffering': 'no', 'Cache-Control': 'no-store' };

/** XHTTP 首字节看门狗：竞速首个下行块，timeout=黑洞 / null=EOF */
const xwebFirstByte = async (socket, stall) => {
  const startedAt = Date.now(), tcpReader = socket.readable.getReader(), firstRead = tcpReader.read();
  firstRead.catch(() => { });   // 竞速败者拒绝兜底
  let watchdog;
  const first = await Promise.race([
    firstRead.finally(() => clearTimeout(watchdog)),
    new Promise((resolve) => { watchdog = setTimeout(resolve, stall); }),
  ]).catch(() => null);
  if (!first?.value?.byteLength) {
    try { tcpReader.cancel().catch(() => { }); } catch { }
    try { tcpReader.releaseLock(); } catch { }
    return first === undefined ? 'timeout' : null;   // 仅静默超时判黑洞
  }
  return { tcpReader, first: first.value, elapsed: Date.now() - startedAt };
};

/** XHTTP 会话入口：BYOB 拼首包建连，上行 pipeTo 直通，下行 1MB 桥回响应 */
const handleXwebPost = async (request, confReady) => {
  if (!request.body) return new Response(null, { status: 400 });
  const state = { tcpSocket: null, needMore: false, xwebPipeTo: true, udpRemain: null, udpDns: null, tcpDns: null, dnsRemain: null, dnsIdleTimer: null, exitKey: null };
  const bridge = new IdentityTransformStream({ highWaterMark: 1024 * 1024 }), responseWriter = bridge.writable.getWriter();   // 1MB 高水位：平滑下行突发，防背压抖动
  let xwebBuffer = new ArrayBuffer(MaxChunkLen), used = 0;
  let closing = false;
  const close = () => {
    if (closing) return;
    closing = true;
    releaseSession(state);
    if (state.xwebPipeTo) responseWriter.close().catch(() => { });
  };
  state.close = close, state.writable = { send(chunk) { if (chunk?.byteLength) return responseWriter.write(chunk); } };
  const reader = request.body.getReader({ mode: 'byob' });
  (async () => {
    await confReady;   // 协议解析前等配置就绪（UUID 可能来自 D1）

    // 首包阶段：手动拼读到建连成功
    while (!state.tcpSocket) {
      const readLen = used === 0 ? 16 * 1024 : MaxChunkLen - used;
      if (readLen <= 0) return close();   // 攒满 64KB 仍未解出握手：协议外流量断开
      const { done, value } = await reader.read(new Uint8Array(xwebBuffer, used, readLen));
      if (done) return close();
      xwebBuffer = value.buffer, used += value.byteLength;
      state.needMore = false;
      await handleSession(new Uint8Array(xwebBuffer, 0, used), state, request);
      if (closing) return;   // 建连全灭或无效包已关会话：停止读取，等运行时回收
      if (!state.needMore) used = 0;   // 解析完成即重置
    }

    // 建连成功：上行剩余裸流 pipeTo（xwebPipeTo 仅作 handleSession 分派标记）
    reader.releaseLock();
    request.body.pipeTo(state.tcpSocket.writable).catch(close);
    const got = await xwebFirstByte(state.tcpSocket, firstByteTimeout(state.exitKey));
    if (got === 'timeout') return state.exitKey && markProxyKey(state.exitKey, BlackholeBase), close();   // 黑洞出口记入失败记忆（指数退避）
    if (!got) return close();
    recordFirstByte(state.exitKey, got.elapsed);
    await state.writable.send(got.first); 
    try { got.tcpReader.releaseLock(); } catch { }
    state.xwebPipeTo = false, responseWriter.releaseLock();
    state.tcpSocket.readable.pipeTo(bridge.writable).catch(close);
  })().catch(close);
  return new Response(bridge.readable, { headers: XwebHeaders });
};

// ==================== 10. 首页伪装反代 ====================

const FakeUrl = 'https://www.xinhuanet.com/';   // 首页伪装固定目标（非代理请求反代到 FakeUrl）
const FakeRewriteMax = 2 * 1024 * 1024;   // 伪装页文本改写上限
const FakePassHeaders = ['user-agent', 'accept', 'accept-language', 'content-type'];
/** 首页伪装反代 */
const handleFakePage = async (request, ctx) => {
  const url = new URL(request.url), cacheKey = url.origin + url.pathname + url.search, cache = globalThis.caches?.default;
  if (cache && request.method === 'GET') {
    try {
      const hit = await cache.match(cacheKey);
      if (hit) return hit;
    } catch { }
  }
  try {
    const fakeURL = new URL(FakeUrl), headers = new Headers();
    for (const h of FakePassHeaders) {
      const v = request.headers.get(h);
      v && headers.set(h, v);
    }
    headers.set('Referer', fakeURL.origin), headers.set('Origin', fakeURL.origin), headers.set('Accept-Encoding', 'identity');
    const response = await fetch(fakeURL.origin + url.pathname + url.search, { method: request.method, headers, body: request.body, signal: AbortSignal.timeout(8000) });
    const contentType = response.headers.get('content-type') || '';
    if (/text|javascript|json|xml/.test(contentType)) {
      const lenHeader = response.headers.get('content-length'), len = lenHeader == null ? NaN : Number(lenHeader);
      const outHeaders = new Headers(response.headers);   // Headers 构造保留同名头（多条 Set-Cookie 不丢）
      outHeaders.set('Cache-Control', 'no-store');

      // 长度可靠且 ≤2MB 的文本进内存改写，其余流式透传
      if (!Number.isFinite(len) || len > FakeRewriteMax) return new Response(response.body, { status: response.status, headers: outHeaders });
      outHeaders.delete('content-encoding');
      outHeaders.delete('content-length');
      const content = (await response.text()).replaceAll(fakeURL.host, url.host), out = new Response(content, { status: response.status, headers: outHeaders });

      // 成功 GET 文本页写回边缘缓存
      if (cache && request.method === 'GET' && response.status === 200 && !response.headers.has('set-cookie')) {
        try {
          const cachedCopy = out.clone();
          cachedCopy.headers.set('Cache-Control', 'public, max-age=3600'), cachedCopy.headers.delete('vary');
          ctx?.waitUntil(cache.put(cacheKey, cachedCopy).catch(() => { })); 
        } catch { }
      }
      return out;
    }
    return response;
  } catch { return new Response('Senflare Link\n客官，请走正门哦，不要再试探我啦~\n简睿 TG：https://t.me/Senflare', { status: 200, headers: { 'content-type': 'text/plain; charset=UTF-8' } }); }
};

// ==================== 11. 内部 API（配置推送 / 版本查询） ====================

/** 跨账号配置推送接收（POST /api/sync/receive-config X-Sync-Key 鉴权） */
const handleSyncConfig = async (request) => {
  const db = runtimeEnv?.Senflare;
  if (!safeEqual(request.headers.get('X-Sync-Key'), SyncKey)) return new Response('Not Found', { status: 404 });
  const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });
  if (!db) return json({ error: '未绑定 D1，无法接收配置' }, 503);

  // 推送体硬上限 64KB，chunked 绕过 content-length 亦不放过
  const raw = await readCappedBody(request.body, 65536);
  if (raw === null) return json({ error: '推送体过大' }, 413);
  let body;
  try { body = JSON.parse(raw); } catch { return json({ error: '参数错误' }, 400); }
  const entries = Object.entries(body && typeof body === 'object' ? body : {}).filter(([k, v]) => ConfigKeys.includes(k) && ['string', 'boolean', 'number'].includes(typeof v));
  if (!entries.length) return json({ error: '无有效配置项' }, 400);
  const enc = (v) => (typeof v === 'string' ? v : JSON.stringify(v));
  const upsert = 'INSERT INTO config (key, value, updatedAt) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updatedAt = excluded.updatedAt';
  const runBatch = () => {
    const now = Date.now();
    return db.batch(entries.map(([k, v]) => db.prepare(upsert).bind(k, enc(v), now)));
  };
  try { await runBatch(); } catch {

    // 缺表时补建一次再试
    try {
      await db.prepare('CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL, updatedAt INTEGER NOT NULL)').run();
      await runBatch();
    } catch { return json({ error: '写入失败' }, 500); }
  }
  nodeConf = null, nodeConfTime = 0, nodeConfFailUntil = 0;   // 立即失效缓存
  confGeneration++; 
  return json({ success: true, version: AdminVersion });
};

/** GET /api/version —— 版本查询（免鉴权） */
const apiVersion = () => new Response(JSON.stringify({ version: AdminVersion }), { headers: { 'content-type': 'application/json', 'access-control-allow-origin': '*' } });

// ==================== 12. 主入口与路由 ====================

export default {
  async fetch(request, env, ctx) {
    runtimeEnv = env;
    const u = new URL(request.url);

    // 配置推送接收（密钥不符 404）
    if (request.method === 'POST' && u.pathname === '/api/sync/receive-config') return handleSyncConfig(request);

    // 版本查询
    if (request.method === 'GET' && u.pathname === '/api/version') return apiVersion();

    // XHTTP（配置异步加载：响应先行，首次协议解析前再等它）
    const ct = (request.headers.get('content-type') || '').split(';')[0].trim();
    if (request.method === 'POST' && /^application\/grpc/.test(ct)) return handleXwebPost(request, loadNodeConfig());

    // WebSocket
    if ((request.headers.get('Upgrade') || '').toLowerCase() === 'websocket') {
      const confReady = loadNodeConfig();
      const { 0: clientSocket, 1: webSocket } = new WebSocketPair();
      webSocket.binaryType = 'arraybuffer';
      webSocket.accept({ allowHalfOpen: true });
      handleWebSocketConn(webSocket, request, confReady);
      return new Response(null, { status: 101, webSocket: clientSocket, headers: { 'Sec-WebSocket-Extensions': '' } });
    }

    // 其余请求：转发至伪装目标 FakeUrl
    return handleFakePage(request, ctx);
  },
};
