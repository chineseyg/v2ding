import { connect } from 'cloudflare:sockets';

// ==================== 配置区域 ====================
const 默认UUID = '92cf180e-9dcd-4657-b189-be21c79a13ec';
// =================================================

function UUID字符串转字节(uuidStr) {
	const hex = uuidStr.replace(/-/g, '');
	const bytes = new Uint8Array(16);
	for (let i = 0; i < 16; i++) {
		bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
	}
	return bytes;
}

export default {
	async fetch(访问请求, env) {
		if (访问请求.headers.get('Upgrade') !== 'websocket') {
			return new Response('代理服务运行中 | WebSocket Ready', { status: 200 });
		}
		const url = new URL(访问请求.url);
		// 反代来源优先级：?ip= 查询参数 > 路径 /proxyip=（面板 fixed 模式写入）> 兜底反代
		const 反代IP = url.searchParams.get('ip')
			|| decodeURIComponent(url.pathname.match(/\/(?:proxyip|pyip|ip)[.=]([^/#?]+)/i)?.[1] || '')
			|| 'ProxyIP.Oracle.CMLiussss.net';
		const 连接UUID = url.searchParams.get('uuid') || (env?.UUID) || 默认UUID;
		return await 升级WS请求(反代IP, 连接UUID);
	},
};

async function 升级WS请求(反代IP, 连接UUID) {
	const [客户端, WS接口] = Object.values(new WebSocketPair());
	WS接口.accept();
	WS接口.binaryType = 'arraybuffer';
	WS接口.send(new Uint8Array([0, 0]));
	启动传输管道(WS接口, 反代IP, 连接UUID);
	return new Response(null, { status: 101, webSocket: 客户端 });
}

async function 启动传输管道(WS接口, 反代IP, 连接UUID) {
	let TCP接口;
	let 传输数据;
	let 已建立 = false;
	// Promise链队列，消息严格串行，零ReadableStream开销
	let 队列 = Promise.resolve();
	const 当前期望UUID = UUID字符串转字节(连接UUID);

	WS接口.addEventListener('message', (event) => {
		队列 = 队列.then(async () => {
			const 消息数据 = event.data;
			if (已建立) {
				await 传输数据.write(消息数据);
			} else {
				const 结果 = await 解析VL标头(消息数据, 当前期望UUID);
				if (!结果) return;
				const { 写入初始数据, tcp连接 } = 结果;

				TCP接口 = tcp连接;
				传输数据 = TCP接口.writable.getWriter();
				if (写入初始数据.byteLength > 0) {
					await 传输数据.write(写入初始数据);
				}
				已建立 = true;

				TCP接口.readable.pipeTo(
					new WritableStream({ write(chunk) { WS接口.send(chunk); } }),
				).catch(() => {});
			}
		}).catch(() => {});
	});

	WS接口.addEventListener('close', () => { try { TCP接口?.close(); } catch {} });
	WS接口.addEventListener('error', () => { try { TCP接口?.close(); } catch {} });

	async function 解析VL标头(VL数据, 验证UUID) {
		const 视图 = new DataView(VL数据);
		const 字节 = new Uint8Array(VL数据);

		for (let i = 0; i < 16; i++) {
			if (字节[1 + i] !== 验证UUID[i]) {
				WS接口.close(1008, 'Invalid UUID');
				return null;
			}
		}

		const 获取数据定位 = 字节[17];
		const 提取端口索引 = 18 + 获取数据定位 + 1;
		const 访问端口 = 视图.getUint16(提取端口索引);
		const 提取地址索引 = 提取端口索引 + 2;
		const 识别地址类型 = 字节[提取地址索引];
		let 地址长度 = 0;
		let 访问地址 = '';
		let 地址信息索引 = 提取地址索引 + 1;

		switch (识别地址类型) {
			case 1:
				地址长度 = 4;
				访问地址 = `${字节[地址信息索引]}.${字节[地址信息索引 + 1]}.${字节[地址信息索引 + 2]}.${字节[地址信息索引 + 3]}`;
				break;
			case 2:
				地址长度 = 字节[地址信息索引];
				地址信息索引 += 1;
				访问地址 = new TextDecoder().decode(new Uint8Array(VL数据, 地址信息索引, 地址长度));
				break;
			case 3:
				地址长度 = 16;
				const v6 = [];
				for (let i = 0; i < 8; i++) {
					v6.push(视图.getUint16(地址信息索引 + i * 2).toString(16));
				}
				访问地址 = v6.join(':');
				break;
			default:
				return null;
		}

		// VLESS UDP（cmd=2，含 MUX）本节点无 UDP 中继：立即断开让客户端快速回退 TCP，避免 QUIC 黑洞
		if (字节[提取端口索引 - 1] !== 1) {
			WS接口.close();
			return null;
		}

		let tcp连接;
		try {
			tcp连接 = connect({ hostname: 访问地址, port: 访问端口 });
			await tcp连接.opened;
		} catch {
			const [反代IP地址, 反代IP端口] = 反代IP.split(':');
			tcp连接 = connect({ hostname: 反代IP地址, port: Number(反代IP端口) || 443 });
			await tcp连接.opened;
		}

		return { 写入初始数据: VL数据.slice(地址信息索引 + 地址长度), tcp连接 };
	}
}