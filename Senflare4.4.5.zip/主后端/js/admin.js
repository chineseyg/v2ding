// 控制台品牌信息
console.log("%c Senflare Link", "color:#fff;font-weight:700;background:linear-gradient(270deg,#986fee,#8695e6,#68b7dd,#18d7d3);padding:8px 15px;border-radius:15px");
console.log("%c Powered by 简睿 | TG @Senflare", "color:#FFD700;background:linear-gradient(135deg,#0a0a0a,#1a1a1a,#0a0a0a);padding:8px 15px;font-weight:700;border-radius:15px;text-shadow:0 0 10px rgba(255, 215, 0)");

/**
 * Senflare Link Lite — Admin API 层
 * 统一 fetch 封装：Bearer 令牌 / 401 自动跳登录 / 业务错误 Toast / HTML 转义
 * 页面经主后端同域反代，API 恒为同源相对路径，无需任何基址配置
 */
(function () {
  var TOKEN_KEY = 'sf_lite_token';
  var LOGIN_TIME_KEY = 'sf_lite_login_time';
  var SESSION_MS = 7 * 24 * 60 * 60 * 1000;   // 前端宽松上限（服务端默认 24h、安全设置可配 1-168h），过期判定以服务端 401 为准


  function getToken() {
    try { return localStorage.getItem(TOKEN_KEY) || ''; } catch (e) { return ''; }
  }
  function setToken(t) {
    try {
      if (t) {
        localStorage.setItem(TOKEN_KEY, t);
        localStorage.setItem(LOGIN_TIME_KEY, String(Date.now()));
      } else {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(LOGIN_TIME_KEY);
      }
    } catch (e) {}
  }
  /** 登录态是否已过期（无令牌 / 超过 7 天） */
  function loginExpired() {
    var t = 0;
    try { t = parseInt(localStorage.getItem(LOGIN_TIME_KEY) || '0', 10); } catch (e) {}
    return !getToken() || !t || Date.now() - t > SESSION_MS;
  }

  // 全局 Toast：唯一实现（admin-ui/login-ui 经 window.showToast 复用，两页均有 #toast 元素）
  function toast(msg, isError) {
    var t = document.getElementById('toast');
    if (!t || !msg) return;
    t.textContent = msg;
    t.classList.toggle('error', !!isError);
    t.style.opacity = '';          // 清掉遗留内联 opacity，避免压住 .show 类
    t.style.visibility = '';
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.classList.remove('show'); }, 3000);
  }
  window.showToast = toast;

  /**
   * 基础调用：返回解析后的 JSON；401 清令牌跳登录页并返回 null；
   * 网络异常 Toast 并返回 null
   */
  async function apiCall(path, options) {
    options = options || {};
    options.headers = Object.assign({}, options.headers, { Authorization: 'Bearer ' + getToken() });
    if (options.body && !options.headers['Content-Type']) options.headers['Content-Type'] = 'application/json';
    var res;
    try {
      res = await fetch(path, options);
    } catch (e) {
      toast('网络请求失败：' + e.message, true);
      return null;
    }
    if (res.status === 401) {
      setToken('');
      // 登录接口的 401 = 账号或密码错误：读出错误体提示用户，而不是当作会话过期静默处理
      var body = null;
      try { body = await res.json(); } catch (e) {}
      if (path === '/api/login') {
        toast((body && body.error) || '登录失败', true);
        return null;
      }
      if (!/\/login$/.test(location.pathname)) location.replace('/login');
      return null;
    }
    var txt = await res.text();
    try { return JSON.parse(txt); } catch (e) {
      // 非 JSON 响应（Worker 异常页 / 网关错误页）：把状态码与片段透出，否则部署侧只会看到笼统的「网络请求失败」
      console.warn('[api] 非 JSON 响应', res.status, path);
      toast('接口异常 HTTP ' + res.status + (txt ? '：' + txt.replace(/<[^>]*>/g, ' ').trim().slice(0, 120) : ''), true);
      return null;
    }
  }

  /** 业务封装：后端 {error} 统一弹 Toast 后返回 null，调用方判空兜底 */
  async function call(path, options) {
    var data = await apiCall(path, options);
    if (data && data.error) {
      toast(data.error, true);
      return null;
    }
    // 显式 status 非 ok（如 {status:'error'}）视为失败；无 status 字段的响应（登录 {token}、用量 {success}、状态对象）一律放行
    if (data && typeof data === 'object' && data.status != null && data.status !== 'ok') {
      toast((data.message || '数据拉取失败'), true);
      return null;
    }
    return data;
  }

  // ---------- 业务端点 ----------

  async function login(username, password) {
    return call('/api/login', { method: 'POST', body: JSON.stringify({ username: username, password: password }) });
  }

  var getConfig = function () { return call('/api/config'); };
  var saveConfig = function (payload) {
    return call('/api/config', { method: 'POST', body: JSON.stringify(payload || {}) });
  };
  var getNodeList = function () { return call('/api/nodelist'); };
  var getStatus = function () { return call('/api/status'); };

  // 凭据走 POST body：避免 Global API Key / Token 出现在 URL 查询串（会被访问日志与
  // observability 持久化捕获）
  var getUsage = function (q) {
    return call('/api/usage', { method: 'POST', body: JSON.stringify(q || {}) });
  };
  var cfGet = function () { return call('/api/cfaccounts'); };
  var cfPost = function (payload) {
    return call('/api/cfaccounts', { method: 'POST', body: JSON.stringify(payload || {}) });
  };
  // 部署编排：走 apiCall 不在统一层 toast——逐账号成败由部署弹窗的执行日志呈现
  var deploy = function (payload) { return apiCall('/api/deploy', { method: 'POST', body: JSON.stringify(payload || {}) }); };

  window.LiteAPI = {
    setToken: setToken,
    loginExpired: loginExpired,
    call: call,
    login: login,
    getConfig: getConfig,
    saveConfig: saveConfig,
    getNodeList: getNodeList,
    getStatus: getStatus,
    getUsage: getUsage,
    cfGet: cfGet,
    cfPost: cfPost,
    deploy: deploy
  };

  // ============================================================
  // 业务逻辑层（LiteCore）：地址解析 / 测速探测 / 本地状态 / 文案映射
  // 与 js/admin-ui.js 的分工：本层只「算与取」，DOM 渲染与事件交互全在 admin-ui.js。
  // 约束：无顶层副作用（本文件同时被 /login 页引用，加载即执行的逻辑不放这里）。
  // ============================================================

  // ---------- 通用工具 ----------
  // 地址、备注可能来自用户输入或远端直链内容，入 HTML 前必须转义
  function escHtml(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function fmtNum(n) {
    n = Number(n);
    if (Number.isNaN(n)) return '0';
    return n.toLocaleString();
  }
  // 分页页码窗口：视口自适应（≤768px 收窄到 3，≤1024px 收窄到 5，宽屏 7），两端补首尾页与省略号
  function pagerPages(p, total, max) {
    var m = Math.max(3, max || (window.innerWidth <= 768 ? 3 : window.innerWidth <= 1024 ? 5 : 7));
    var half = Math.floor(m / 2);
    var start = Math.max(1, Math.min(p - half, total - m + 1));
    var end = Math.min(total, start + m - 1);
    var win = [];
    for (var i = start; i <= end; i++) win.push(i);
    var out = [];
    if (win[0] > 1) out.push(1);
    if (win[0] > 2) out.push('...');
    for (var j = 0; j < win.length; j++) out.push(win[j]);
    if (win[win.length - 1] < total - 1) out.push('...');
    if (win[win.length - 1] < total) out.push(total);
    return out;
  }
  // 复制到剪贴板：无 clipboard API / 权限拒绝时走 execCommand 兜底，全部复制入口共用
  function copyText(text, okMsg) {
    var ok = function () { toast(okMsg || '已复制到剪贴板'); };
    var fallback = function () {
      var ta = document.createElement('textarea');
      ta.value = String(text == null ? '' : text);
      ta.style.cssText = 'position:fixed;top:-9999px;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy') ? ok() : toast('复制失败', true); }
      catch (e) { toast('复制失败', true); }
      ta.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok, fallback);
    else fallback();
  }
  // 下载文本文件（Blob → a.click → revoke），全部下载入口共用
  function downloadText(filename, text, okMsg, mime) {
    var blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    if (okMsg) toast(okMsg);
  }

  // ---------- 浏览器本地状态（测速结果 / 测速设置 / 配置草稿） ----------
  // 测速结果持久化：刷新不丢（损坏/缺失回落空表，可随时重测再生）
  var ST_STORE_KEY = 'sf_lite_stdata_v1';
  function stStoreRead() {
    try {
      var d = JSON.parse(localStorage.getItem(ST_STORE_KEY));
      if (d && Array.isArray(d.speed) && Array.isArray(d.proxy)) return d;
    } catch (e) {}
    return { speed: [], proxy: [] };
  }
  function stStoreWrite(data) {
    try { localStorage.setItem(ST_STORE_KEY, JSON.stringify(data)); } catch (e) {}
  }
  var ST_CFG_KEY = 'sf_lite_stcfg';
  var ST_CFG_DEFAULT = { port: '443', threads: 5, random: 3, max: 20, save: 10 };
  function stCfgRead() {
    try {
      var saved = JSON.parse(localStorage.getItem(ST_CFG_KEY) || '{}');
      return Object.assign({}, ST_CFG_DEFAULT, saved);
    } catch (e) { return Object.assign({}, ST_CFG_DEFAULT); }
  }
  function stCfgWrite(cfg) {
    try { localStorage.setItem(ST_CFG_KEY, JSON.stringify(cfg)); } catch (e) {}
  }
  // 机房地区缓存（优选/节点列表共用）：host → {region, colo, ts}，TTL 24h
  var ST_REGION_KEY = 'sf_lite_region_cache_v1';
  var ST_REGION_TTL = 24 * 60 * 60 * 1000;
  function regionCacheRead() {
    try {
      var d = JSON.parse(localStorage.getItem(ST_REGION_KEY));
      return d && typeof d === 'object' ? d : {};
    } catch (e) { return {}; }
  }
  function regionCacheClear() {
    try { localStorage.removeItem(ST_REGION_KEY); } catch (e) {}
  }
  function regionCacheWrite(cache) {
    try { localStorage.setItem(ST_REGION_KEY, JSON.stringify(cache)); } catch (e) {}
  }
  // 查 host 机房/注册地：缓存命中直接返回，否则并发查 trace 与 ipinfo
  function stLookupRegion(host, port) {
    var h = String(host || '').replace(/^\[|\]$/g, '');
    if (!h) return Promise.resolve({});
    var cache = regionCacheRead();
    var hit = cache[h];
    if (hit && Date.now() - hit.ts < ST_REGION_TTL) return Promise.resolve(hit);
    var traceUrl = 'https://' + (h.indexOf(':') !== -1 ? '[' + h + ']' : h) + ':' + (port || 443) + '/cdn-cgi/trace';
    var ipUrl = 'https://api.ipinfo.io/lite/' + encodeURIComponent(h) + '?token=2cb674df499388';
    // 并发：trace 取机房，ipinfo 取注册地
    return Promise.all([
      fetch(traceUrl, { signal: AbortSignal.timeout(5000), cache: 'no-store', referrerPolicy: 'no-referrer' })
        .then(function (res) {
          if (!res.ok) return {};
          return res.text().then(function (text) {
            var d = {};
            text.trim().split('\n').forEach(function (ln) {
              var kv = ln.split('=');
              if (kv[0] && kv[1]) d[kv[0].trim()] = kv[1].trim();
            });
            return { region: d.loc || '', colo: d.colo || '' };
          });
        })
        .catch(function () { return {}; }),
      fetch(ipUrl, { signal: AbortSignal.timeout(5000), cache: 'no-store' })
        .then(function (r) {
          if (!r.ok) return {};
          return r.json().then(function (d) {
            if (!d || !d.country_code) return {};
            return { region: d.country_code, colo: '' };
          });
        })
        .catch(function () { return {}; }),
    ]).then(function (parts) {
      var out = { region: parts[0].region || parts[1].region || '', colo: parts[0].colo || '', ts: Date.now() };
      if (out.region || out.colo) { cache[h] = out; regionCacheWrite(cache); }
      return out;
    });
  }
  // 节点配置草稿：未保存的修改（优先级高于服务端值），保存成功后清除；
  // 键带版本号隔离旧格式数据
  var CFG_DRAFT_KEY = 'sf_lite_cfg_draft_v2';
  function cfgDraftRead() {
    try { return JSON.parse(localStorage.getItem(CFG_DRAFT_KEY) || '{}'); } catch (e) { return {}; }
  }
  function cfgDraftWrite(obj) {
    try { localStorage.setItem(CFG_DRAFT_KEY, JSON.stringify(obj || {})); } catch (e) {}
  }
  function cfgDraftClear() {
    try { localStorage.removeItem(CFG_DRAFT_KEY); } catch (e) {}
  }

  // ---------- 地址解析（对齐主后端 parseNodeAddress / ipToHex） ----------
  function stParseAddr(raw) {
    var addr = String(raw == null ? '' : raw).trim();
    if (!addr || /^https?:\/\//i.test(addr)) return null;
    var m6 = addr.match(/^\[([0-9a-fA-F:]+)\](?::(\d+))?$/);
    if (m6) return { host: m6[1], port: m6[2] || '443', type: 'ipv6' };
    if ((addr.match(/:/g) || []).length > 1 && addr.indexOf('.') === -1) {
      return { host: addr, port: '443', type: 'ipv6' };
    }
    var lc = addr.lastIndexOf(':');
    if (lc > 0 && /^\d+$/.test(addr.slice(lc + 1))) {
      var h = addr.slice(0, lc);
      return { host: h, port: addr.slice(lc + 1), type: /^\d{1,3}(\.\d{1,3}){3}$/.test(h) ? 'ipv4' : 'domain' };
    }
    return { host: addr, port: '443', type: /^\d{1,3}(\.\d{1,3}){3}$/.test(addr) ? 'ipv4' : 'domain' };
  }
  // 拆 IP:端口（详情弹窗专用）：[IPv6]:端口 优先按括号解析；裸 IPv6 含多个冒号，
  // 不能按「最后一个冒号」切（否则 2606:4700::1 会被切成 host=2606:4700:/port=1）
  function stSplitAddr(addr) {
    var s = String(addr || '').trim();
    var m6 = s.match(/^\[([0-9a-fA-F:]+)\](?::(\d+))?$/);
    if (m6) return { ip: m6[1], port: m6[2] || '—' };
    var sep = s.lastIndexOf(':');
    if (sep > 0 && s.indexOf(':') === sep && /^\d+$/.test(s.slice(sep + 1))) {
      return { ip: s.slice(0, sep), port: s.slice(sep + 1) };
    }
    return { ip: s.replace(/^\[|\]$/g, ''), port: '—' };
  }
  // 节点列表项：/api/nodelist 的 {host,port,name} → 卡片数据模型
  function nlMapItem(it) {
    var host = String(it.host || ''), port = String(it.port || '443');
    var ipv6 = host.indexOf(':') !== -1;
    var addr = ipv6 ? '[' + host + ']:' + port : host + ':' + port;
    return { addr: addr, dataAddr: addr,
             name: it.name && it.name !== host ? String(it.name) : '',
             ipv6: ipv6, region: '', ms: null, ok: null, colo: '', tip: '', time: '' };
  }

  // ---------- Cloudflare 网段判定（官方列表无 CORS 头，只能本地内置比对） ----------
  var CF_V4 = ['173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
    '141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
    '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
    '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
    '1.1.1.0/24', '1.0.0.0/24'];
  var CF_V6 = ['2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
    '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32'];
  // 全程乘除不用位移：n << 24 在 >=128.0.0.0 处会翻成负数
  function ip4ToInt(s) {
    var p = String(s).split('.');
    if (p.length !== 4) return null;
    var n = 0;
    for (var i = 0; i < 4; i++) {
      if (!/^\d{1,3}$/.test(p[i]) || Number(p[i]) > 255) return null;
      n = n * 256 + Number(p[i]);
    }
    return n;
  }
  function ip6ToGroups(s) {
    var str = String(s).trim().toLowerCase();
    var tail = str.match(/:(\d{1,3}(?:\.\d{1,3}){3})$/);   // ::ffff:1.2.3.4 的 v4 尾巴先折成两组
    if (tail) {
      var v4 = ip4ToInt(tail[1]);
      if (v4 === null) return null;
      str = str.slice(0, -tail[1].length) + Math.floor(v4 / 65536).toString(16) + ':' + (v4 % 65536).toString(16);
    }
    var half = str.split('::');
    if (half.length > 2) return null;
    var head = half[0] ? half[0].split(':') : [];
    var rear = half.length === 2 ? (half[1] ? half[1].split(':') : []) : null;
    var g = [], i;
    for (i = 0; i < head.length; i++) g.push(parseInt(head[i], 16));
    if (rear !== null) {
      var fill = 8 - head.length - rear.length;
      if (fill < 1) return null;   // :: 至少代表一组零
      for (i = 0; i < fill; i++) g.push(0);
      for (i = 0; i < rear.length; i++) g.push(parseInt(rear[i], 16));
    }
    if (g.length !== 8) return null;
    for (i = 0; i < 8; i++) if (!(g[i] >= 0 && g[i] <= 65535)) return null;
    return g;
  }

  // ---------- Cloudflare 网段判定（官方列表无 CORS 头，只能本地内置比对） ----------
  var CF_V4 = ['173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
    '141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
    '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
    '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
    '1.1.1.0/24', '1.0.0.0/24'];
  var CF_V6 = ['2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
    '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32'];

  function stIsCfIp(host) {
    var h = String(host || '').replace(/^\[|\]$/g, ''), i, j;
    if (h.indexOf(':') !== -1) {
      var g = ip6ToGroups(h);
      if (!g) return false;
      for (i = 0; i < CF_V6.length; i++) {
        var pv = CF_V6[i].split('/'), pg = ip6ToGroups(pv[0]), len = Number(pv[1]), hit = true;
        if (!pg) continue;
        for (j = 0; j < len && hit; j += 16) {
          var bits = Math.min(16, len - j);
          var mask = 65536 - Math.pow(2, 16 - bits);   // 取高 bits 位：13 → 0xFFF8
          if ((g[j / 16] & mask) !== (pg[j / 16] & mask)) hit = false;
        }
        if (hit) return true;
      }
      return false;
    }
    var n = ip4ToInt(h);
    if (n === null) return false;
    for (i = 0; i < CF_V4.length; i++) {
      var q = CF_V4[i].split('/'), base = ip4ToInt(q[0]), div = Math.pow(2, 32 - Number(q[1]));
      if (base !== null && Math.floor(n / div) === Math.floor(base / div)) return true;
    }
    return false;
  }
  // 命中的前缀名（简写：补 .0.0 段），用于卡片/详情展示；非 CF 返回 ''
  function stCfCidr(host) {
    var h = String(host || '').replace(/^\[|\]$/g, '');
    if (h.indexOf(':') !== -1) {
      var g6 = ip6ToGroups(h);
      if (!g6) return '';
      for (var i = 0; i < CF_V6.length; i++) {
        var pv = CF_V6[i].split('/'), pg = ip6ToGroups(pv[0]), len = Number(pv[1]), hit = true;
        if (!pg) continue;
        for (var j = 0; j < len && hit; j += 16) {
          var bits = Math.min(16, len - j), mask = 65536 - Math.pow(2, 16 - bits);
          if ((g6[j / 16] & mask) !== (pg[j / 16] & mask)) hit = false;
        }
        if (hit) return CF_V6[i];
      }
      return '';
    }
    var n = ip4ToInt(h);
    if (n === null) return '';
    for (i = 0; i < CF_V4.length; i++) {
      var q = CF_V4[i].split('/'), base = ip4ToInt(q[0]), div = Math.pow(2, 32 - Number(q[1]));
      if (base !== null && Math.floor(n / div) === Math.floor(base / div)) {
        var o = String(q[0]).split('.');
        return [o[0], o[1], '0', '0'].join('.') + '/' + q[1];
      }
    }
    return '';
  }

  // ---------- 并发池（worker 定额；进度回调逐个上报） ----------
  function stRunPool(items, threads, taskFn, onProgress) {
    var total = items.length;
    threads = Math.max(1, Math.min(parseInt(threads, 10) || 1, total));
    var done = 0, next = 0;
    function worker() {
      if (next >= total) return Promise.resolve();
      var item = items[next++];
      return Promise.resolve().then(function () { return taskFn(item); }).then(function () {
        done++;
        if (onProgress) try { onProgress(done, total); } catch (e) {}
        return worker();
      });
    }
    var ws = [];
    for (var i = 0; i < threads; i++) ws.push(worker());
    return Promise.all(ws);
  }

  // ---------- 优选节点测速 ----------
  // 域名：直连 https://<域名>:<port>/cdn-cgi/trace 三连打点（证书合法，可直测 RTT）
  // 首次请求解析 trace 取 loc/colo，后两次经 Resource Timing 取纯网络延时取平均，单请求 6s 超时
  // 裸 IP（IPv4/IPv6）：纯前端探测，见 stProbeBareIp。check 接口属反代语义，仅反代页签使用
  var ST_IP_TIMEOUT = 3000;
  var ST_IP_FLOOR = 20;
  async function stProbeBareIp(host, port, isV6) {
    var url = 'https://' + (isV6 ? '[' + host + ']' : host) + ':' + port + '/cdn-cgi/trace';
    var got = [];
    for (var i = 0; i < 3; i++) {
      var t0 = performance.now(), timedOut = false;
      try {
        await fetch(url + '?_=' + Math.random(), {
          mode: 'no-cors', cache: 'no-store', referrerPolicy: 'no-referrer',
          signal: AbortSignal.timeout(ST_IP_TIMEOUT),
        });
      } catch (e) { timedOut = !!(e && e.name === 'TimeoutError'); }
      var ms = performance.now() - t0;
      if (timedOut) return { ok: false, ms: 0 };
      if (ms < ST_IP_FLOOR) return { ok: false, ms: 0 };   // 1ms 级返回是浏览器封禁端口或本地拒绝，握手根本没发生
      if (i > 0) got.push(ms);   // 首次含连接预热（实测 968 → 197），丢掉
    }
    return { ok: true, ms: Math.round((got[0] + got[1]) / 2) };
  }
  async function stTestNode(o, cfgPort) {
    var p = stParseAddr(o.addr);
    if (!p) { o.ok = false; return; }
    var port = cfgPort || p.port;
    o.ipv6 = p.type === 'ipv6';
    o.testPort = port;
    if (p.type !== 'domain') {
      o.cf = stIsCfIp(p.host);
      // 裸 IP → 纯前端探测（快速 reject = 存活，超时 = 黑洞）
      var pr = await stProbeBareIp(p.host, port, p.type === 'ipv6');
      if (!pr.ok) { o.ok = false; return; }
      o.ok = true;
      o.ms = pr.ms;
      if (o.cf) o.cfCidr = stCfCidr(p.host);   // CF 网段归属异步补
      // 优选 IP 一律补机房/注册地
      var rg = await stLookupRegion(p.host, port).catch(function () { return {}; });
      if (rg.region) o.region = rg.region;
      if (rg.colo) o.colo = rg.colo;
      return;
    }
    var base = 'https://' + p.host + ':' + port + '/cdn-cgi/trace';
    try {
      var times = [];
      for (var i = 0; i < 3; i++) {
        var url = base + '?_t=' + Date.now() + '&_r=' + i;
        var t0 = performance.now();
        var res = await fetch(url, { signal: AbortSignal.timeout(6000), cache: 'no-store' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var text = await res.text();
        var elapsed = performance.now() - t0;
        if (i === 0) {
          var d = {};
          text.trim().split('\n').forEach(function (ln) {
            var kv = ln.split('=');
            if (kv[0] && kv[1]) d[kv[0].trim()] = kv[1].trim();
          });
          o.region = d.loc || '';
          o.colo = d.colo || '';
        }
        if (i > 0) {
          var net = elapsed;
          try {
            var ent = performance.getEntriesByName(url, 'resource');
            if (ent.length) {
              var tm = ent[ent.length - 1];
              if (tm.requestStart > 0 && tm.responseStart > 0) net = tm.responseStart - tm.requestStart;
            }
          } catch (e) {}
          times.push(net);
        }
      }
      try { performance.clearResourceTimings(); } catch (e) {}   // 防资源缓冲打满（默认 250 条）后拿不到 timing
      o.ms = Math.round(times.reduce(function (a, b) { return a + b; }, 0) / Math.max(times.length, 1));
      o.ok = true;
    } catch (e) {
      o.ok = false;
    }
  }

  // ---------- 探测层：check API（仅反代语义）+ 并发去重 ----------
  // 反代检测端点（api.090227.xyz，返回 JSON 且带 ACAO:*）；服务端探测最长 ~30s，客户端须等足 30s
  // 同一地址并发去重共享一个 Promise；优选判定不经过本层
  var ST_CHECK_API = 'https://api.090227.xyz/check?proxyip=';
  var stProbeInflight = new Map();
  async function stProbeProxy(addr) {
    var inf = stProbeInflight.get(addr);
    if (inf) return inf;
    var req = (async function () {
      var rec = { ok: false, ms: 0, colo: '', portRemote: '', country: '', city: '', org: '', asn: '' };
      try {
        var res = await fetch(ST_CHECK_API + encodeURIComponent(addr), { signal: AbortSignal.timeout(30000), cache: 'no-store' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var data = await res.json();
        rec.ok = !!data.success;
        rec.ms = parseInt(data.responseTime, 10) || 0;
        rec.colo = data.colo || '';
        if (data.portRemote) rec.portRemote = String(data.portRemote);
        var pr = data.probe_results || {};
        var exit = (pr.ipv4 && pr.ipv4.exit) || (pr.ipv6 && pr.ipv6.exit) || {};
        rec.country = exit.country || '';
        rec.city = exit.city || '';
        rec.org = exit.asOrganization || exit.org || '';
        rec.asn = exit.asn ? 'AS' + exit.asn : '';
        // connect_ms 取双栈最快连通值（responseTime 缺失时兜底）
        [pr.ipv4, pr.ipv6].forEach(function (st) {
          var c = parseInt(st && st.connect_ms, 10);
          if (c > 0 && (!rec.ms || c < rec.ms)) rec.ms = c;
        });
      } catch (e) {}
      return rec;
    })();
    stProbeInflight.set(addr, req);
    try { return await req; } finally { stProbeInflight.delete(addr); }
  }
  async function stTestProxy(o) {
    var p = stParseAddr(o.addr);
    if (!p) { o.ok = false; return; }
    o.ipv6 = p.type === 'ipv6';
    var target = (p.type === 'ipv6' ? '[' + p.host + ']' : p.host) + ':' + p.port;
    var r = await stProbeProxy(target);
    if (r.ok) {
      o.ok = true;
      o.ms = r.ms;
      o.colo = r.colo;
      o.region = r.country || '';
      o.city = r.city || '';
      o.org = r.org || '';
      o.asn = r.asn || '';
      if (r.portRemote) o.remotePort = r.portRemote;
    } else {
      o.ok = false;
    }
  }

  // ---------- 数据来源解析：逐行 addr#备注 / 直链 URL(CORS) / 网段表达式 ----------
  function stIsIpv4Str(s) {
    var parts = s.split('.');
    return parts.length === 4 && parts.every(function (x) {
      var n = parseInt(x, 10);
      return !isNaN(n) && n >= 0 && n <= 255;
    });
  }
  function stExtract(text) {
    var clean = String(text == null ? '' : text).replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/gi, ' ');
    var out = [];
    var seen = {};
    var push = function (addr, name) {
      addr = addr.trim(); name = (name || '').trim();
      var low = addr.toLowerCase();
      if (!addr || seen[addr]) return;
      if (low.indexOf('example.') !== -1 || low.indexOf('localhost') !== -1) return;
      seen[addr] = 1;
      out.push({ addr: addr, name: name });
    };
    // 第一优先：IP/域名 # 备注 形式（优选榜单常见格式）
    (clean.match(/(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?#[^\s]+/g) || []).forEach(function (item) {
      var seg = item.split('#');
      var ipPart = seg[0].split(':')[0];
      if (stIsIpv4Str(ipPart)) push(seg[0], seg.slice(1).join('#'));
    });
    (clean.match(/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?::\d+)?#[^\s]+/g) || []).forEach(function (item) {
      var seg = item.split('#');
      if (seg[0].toLowerCase().lastIndexOf('www.', 0) !== 0) push(seg[0], seg.slice(1).join('#'));
    });
    if (!out.length) {
      (clean.match(/\b(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?\b/g) || []).forEach(function (ip) {
        if (stIsIpv4Str(ip.split(':')[0])) push(ip, '');
      });
    }
    if (!out.length) {
      (clean.match(/\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?::\d+)?\b/g) || []).forEach(function (dm) {
        if (dm.toLowerCase().lastIndexOf('www.', 0) !== 0) push(dm, '');
      });
    }
    return out;
  }

  // 网段表达式：a.b.*.0/24 # 第三段范围(单个/范围/逗号组合) # 运营商 → 每段随机 randomCount 个 IP
  function stParseSubnet(line, randomCount) {
    var out = [];
    var parts = line.split('#').map(function (s) { return s.trim(); });
    var m = (parts[0] || '').match(/^(\d{1,3})\.(\d{1,3})\.\*\.\d+\/24$/);
    if (!m) return out;
    var thirds = [];
    var hasRange = !!(parts[1] || '').trim();
    (parts[1] || '').split(',').forEach(function (r) {
      r = r.trim();
      if (!r) return;
      if (r.indexOf('-') !== -1) {
        var ab = r.split('-'), a = parseInt(ab[0], 10), b = parseInt(ab[1], 10);
        if (!isNaN(a) && !isNaN(b) && b >= a && b <= 255) for (var x = a; x <= b; x++) thirds.push(x);
      } else {
        var n = parseInt(r, 10);
        if (!isNaN(n) && n >= 0 && n <= 255) thirds.push(n);
      }
    });
    if (!thirds.length) {
      // 范围字段写了但全部无效：放弃该行（对齐主后端语义），不回退全量 1..255 盲扫
      if (hasRange) return out;
      for (var t = 1; t <= 255; t++) thirds.push(t);
    }
    thirds.forEach(function (third) {
      var used = {};
      for (var j = 0; j < randomCount && Object.keys(used).length < 254; j++) {
        var last;
        do { last = Math.floor(Math.random() * 254) + 1; } while (used[last]);
        used[last] = 1;
        out.push({ addr: m[1] + '.' + m[2] + '.' + third + '.' + last, isp: parts[2] || '' });
      }
    });
    return out;
  }

  // 汇总待测列表：网段展开 / 直链抓取 / 逐行解析，超出上限截断
  async function stBuildList(mode, content, randomCount, maxTest) {
    var lines = content.split(/[\r\n]+/).map(function (l) { return l.trim(); })
      .filter(function (l) { return l && l.charAt(0) !== '#' && l.slice(0, 2) !== '//'; });
    var list = [], seen = {};
    var add = function (raw, name, isp) {
      var addr = String(raw == null ? '' : raw).trim();
      if (!addr || seen[addr]) return;
      seen[addr] = 1;
      list.push({ addr: addr, name: name || '', isp: isp || '' });
    };
    if (mode === 'SUBNET' && !lines.some(function (l) { return /^https?:\/\//i.test(l); })) {
      lines.forEach(function (ln) {
        stParseSubnet(ln, randomCount).forEach(function (it) { add(it.addr, '', it.isp); });
      });
    } else {
      for (var li = 0; li < lines.length; li++) {
        var ln = lines[li];
        if (/^https?:\/\//i.test(ln)) {
          try {
            toast('正在获取直链内容...');
            var res = await fetch(ln, { cache: 'no-store' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            var extracted = stExtract(await res.text());
            if (!extracted.length) throw new Error('未解析到有效地址');
            extracted.forEach(function (it) { add(it.addr, it.name); });
          } catch (e) {
            toast('直链获取失败: ' + e.message + '（需支持 CORS，如 GitHub raw）', true);
          }
        } else {
          var seg = ln.split('#');
          add(seg[0], seg.slice(1).join('#').trim());
        }
      }
    }
    if (list.length > maxTest) {
      toast('地址数量已截断：' + list.length + ' → ' + maxTest);
      list = list.slice(0, maxTest);
    }
    return list;
  }

  // ---------- 文案映射（纯函数，卡片 / 详情 / 状态栏共用） ----------
  var ISP_CN = { Telecom: '电信', Mobile: '移动', Unicom: '联通', Three: '三网' };
  function stTimeHM(d) {
    var p2 = function (n) { return (n < 10 ? '0' : '') + n; };
    return p2(d.getHours()) + ':' + p2(d.getMinutes());
  }
  function stKindLabel(o, tab) {
    if (o.isp) return '网段优选 · ' + (ISP_CN[o.isp] || o.isp);
    var p = stParseAddr(o.addr) || {};
    return (tab === 'speed' ? '优选' : '反代') + (p.type === 'ipv6' ? 'IPv6' : p.type === 'domain' ? '域名' : 'IP');
  }
  // 卡片 title：时间 HH:MM · 机房 · 类型 · 点击查看详情
  function stTipOf(o, tab) {
    if (o.ok === false) return '时间 ' + o.time + ' · 测速超时 · 点击查看详情';
    var parts = ['时间 ' + o.time];
    if (o.colo) parts.push('机房 ' + o.colo);
    parts.push(stKindLabel(o, tab));
    return parts.join(' · ') + ' · 点击查看详情';
  }
  // 节点列表卡片 title（无详情提示，备注名替代类型）
  function nlTipOf(o) {
    if (o.ok === false) return '时间 ' + o.time + ' · 测速超时';
    var parts = ['时间 ' + o.time];
    if (o.colo) parts.push('机房 ' + o.colo);
    if (o.name) parts.push(o.name);
    return parts.join(' · ');
  }
  // 卡片展示地址：未自带端口的地址补显示实际测试端口（测速设置指定 > 地址自带 > 默认 443）
  function stDisplayAddr(o) {
    var raw = String(o.addr || '');
    var p = stParseAddr(raw);
    if (!p) return raw;
    var hasPort = p.type === 'ipv6' ? /\]:\d+$/.test(raw) : /:\d+$/.test(raw);   // 原始串是否自带端口（不能问 parser：它会把缺省当 443）
    var eff = String(o.testPort || (hasPort ? p.port : (stCfgRead().port || p.port)));
    if (hasPort && eff === String(p.port)) return raw;   // 自带端口且未被测速设置覆盖：原样展示
    return (p.type === 'ipv6' ? '[' + p.host + ']' : p.host) + ':' + eff;
  }
  function proxyModeLabel(m) {
    m = String(m || 'Auto').trim();
    var up = m.toUpperCase();
    if (up === 'AUTO') return '智能匹配';
    if (up === 'OFFICIAL') return '官方匹配';
    if (up === 'CUSTOM') return '自定义';
    if (up === 'LOCAL') return '在线优选';
    if (/^[A-Z]{2}$/.test(up)) return '固定地区';
    return m;
  }
  function inboundLabel(v) {
    var k = String(v || 'preferred').toLowerCase();
    return k === 'proxy' ? '反代 IP' : '优选 IP';
  }
  // 日志时间：时间戳按 UTC+8 展示（与表头一致，不依赖浏览器本地时区）
  function fmtLogTime(ts) {
    var pad2 = function (n) { return (n < 10 ? '0' : '') + n; };
    var t8 = ts ? new Date(Number(ts) + 8 * 3600 * 1000) : null;
    if (!t8 || isNaN(t8.getTime())) return '-';
    return t8.getUTCFullYear() + '/' + (t8.getUTCMonth() + 1) + '/' + t8.getUTCDate() +
      ' ' + pad2(t8.getUTCHours()) + ':' + pad2(t8.getUTCMinutes()) + ':' + pad2(t8.getUTCSeconds());
  }

  // ---------- 网络检测：站点延迟采样 + 出口 IP 情报 ----------
  var LATENCY_TIMEOUT = 5000;
  /** 单次延迟采样：no-cors 取整程耗时，超时/失败返回 -1 */
  async function testLatency(site) {
    var start = Date.now();
    try {
      var controller = new AbortController();
      var timeoutId = setTimeout(function () { controller.abort(); }, LATENCY_TIMEOUT);
      await fetch(site.url + '?t=' + Date.now(), { method: 'GET', cache: 'no-store', mode: 'no-cors', referrerPolicy: 'no-referrer', signal: controller.signal });
      clearTimeout(timeoutId);
      return Date.now() - start;
    } catch (e) { return -1; }
  }
  function latencyColor(l) {
    if (l === -1) return '#9ca3af';
    if (l <= 49) return '#22c55e';
    if (l <= 99) return '#84cc16';
    if (l <= 149) return '#eab308';
    if (l <= 199) return '#f97316';
    return '#ef4444';
  }
  function calcAbuseScore(company, asn, flags) {
    flags = flags || {};
    var c = parseFloat(company) || 0, a = parseFloat(asn) || 0;
    var base = ((c + a) / 2) * 5;
    var risks = [flags.is_crawler, flags.is_proxy, flags.is_vpn, flags.is_tor, flags.is_abuser, flags.is_bogon];
    base += risks.filter(Boolean).length * 0.15;
    var hit = risks.filter(Boolean).length;
    return (c === 0 && a === 0 && hit === 0) ? null : base;
  }
  /** 滥用评分归一化：上游可能给数字、字符串或 {fraction,...} 对象，统一为可解析字符串或 null */
  function fmtAbuserScore(v) {
    if (v == null || v === '' || v === '未知') return null;
    if (typeof v === 'number' && isFinite(v)) return String(v);
    if (typeof v === 'object' && v.fraction != null && isFinite(v.fraction)) return String(v.fraction);
    if (typeof v === 'string') return v;
    return null;
  }
  function abuseScoreBadge(score) {
    if (score === null) return { cls: 'badge-info', text: '未知' };
    var pct = score * 100;
    var level = '极度纯净', cls = 'badge-verylow';
    if (pct >= 100) { level = '极度危险'; cls = 'badge-critical'; }
    else if (pct >= 20) { level = '高风险'; cls = 'badge-high'; }
    else if (pct >= 5) { level = '轻微风险'; cls = 'badge-elevated'; }
    else if (pct >= 0.25) { level = '纯净'; cls = 'badge-low'; }
    return { cls: cls, text: pct.toFixed(2) + '% ' + level };
  }

  /** 取本机出口 IP：三家接口按序回落，命中带 * 掩码的继续下一家 */
  async function fetchOutboundIp() {
    var apis = [
      { url: 'https://api.ipapi.is', parser: function (d) { return d.ip; } },
      { url: 'https://api-v3.speedtest.cn/ip', parser: function (d) { return d.data && d.data.ip; } },
      { url: 'https://myip.ipip.net/json', parser: function (d) { return d.data && d.data.ip; } }
    ];
    var ip = null;
    for (var i = 0; i < apis.length; i++) {
      try {
        var res = await fetch(apis[i].url + '?t=' + Date.now(), { cache: 'no-store', signal: AbortSignal.timeout(5000) });
        if (res.ok) {
          ip = apis[i].parser(await res.json());
          if (ip && ip.indexOf('*') === -1) break;
        }
      } catch (e) {}
    }
    return ip;
  }
  /** 常见出口国家名 → ISO 码：扁平响应只有国家名没有码，RDAP 限流时兜底点亮国旗 */
  var CountryNameCode = {
    'japan': 'JP', 'united states': 'US', 'united kingdom': 'GB', 'south korea': 'KR', 'hong kong': 'HK',
    'taiwan': 'TW', 'singapore': 'SG', 'germany': 'DE', 'france': 'FR', 'netherlands': 'NL',
    'canada': 'CA', 'australia': 'AU', 'russia': 'RU', 'india': 'IN', 'brazil': 'BR',
    'turkey': 'TR', 'malaysia': 'MY', 'thailand': 'TH', 'vietnam': 'VN', 'philippines': 'PH',
    'indonesia': 'ID', 'spain': 'ES', 'italy': 'IT', 'poland': 'PL', 'sweden': 'SE',
    'switzerland': 'CH', 'ukraine': 'UA', 'united arab emirates': 'AE', 'argentina': 'AR',
    'mexico': 'MX', 'south africa': 'ZA', 'china': 'CN', 'macau': 'MO', 'kazakhstan': 'KZ'
  };
  /** IP 情报接口清单：逐家回落，各自把响应归一化为统一结构（无效返回 null） */
  function ipDetailApis(ip) {
    return [
      { name: 'ipapi.is', url: 'https://api.ipapi.is/?ip=' + ip, parser: function (d) {
          // 免费查询端点（?ip=）返回扁平结构：asn/company 是「AS13335 Cloudflare, Inc.」式字符串、位置在顶层；
          // 嵌套结构（location/asn 为对象）出现在根端点。解析前先判形，两种都要吃
          if (!d || !d.ip) return null;
          if (typeof d.asn === 'string' || typeof d.company === 'string') {
            var asnText = String(d.asn || '').trim();
            var asnNum = (asnText.match(/^AS(\d+)/i) || [])[1] || '';
            var asnOrg = asnText.replace(/^AS\d+\s*/i, '');
            var cc = d.country_code || CountryNameCode[String(d.country || '').toLowerCase()] || '';
            return {
              ip: d.ip,
              rir: d.rir || '',
              is_crawler: !!d.is_crawler, is_proxy: !!d.is_proxy, is_vpn: !!d.is_vpn,
              is_tor: !!d.is_tor, is_abuser: !!d.is_abuser, is_bogon: !!d.is_bogon,
              company: { name: typeof d.company === 'string' ? d.company : (d.company && d.company.name) || '', domain: '', type: '', network: '', abuser_score: null },
              asn: { asn: asnNum, org: asnOrg, route: '', type: '', country: cc, abuser_score: null },
              location: { country: d.country || '', country_code: cc, city: d.city || '', state: d.region || '', zip: d.zipcode || '', latitude: d.lat, longitude: d.lon, timezone: d.timezone || '', local_time: '' }
            };
          }
          // 嵌套结构：防限流空壳——必须同时有 ip 与（位置或 ASN）才算有效，否则回落下一家
          if (!d.location && !d.asn) return null;
          return {
            ip: d.ip,
            rir: d.rir || '',
            is_crawler: !!d.is_crawler, is_proxy: !!d.is_proxy, is_vpn: !!d.is_vpn,
            is_tor: !!d.is_tor, is_abuser: !!d.is_abuser, is_bogon: !!d.is_bogon,
            company: { name: (d.company && d.company.name) || '', domain: (d.company && d.company.domain) || '', type: (d.company && d.company.type) || '', network: (d.company && d.company.network) || '', abuser_score: d.company ? d.company.abuser_score : null },
            asn: { asn: (d.asn && d.asn.asn) || '', org: (d.asn && d.asn.org) || '', route: (d.asn && d.asn.route) || '', type: (d.asn && d.asn.type) || '', country: (d.asn && d.asn.country) || '', abuser_score: d.asn ? d.asn.abuser_score : null },
            location: d.location ? { country: d.location.country, country_code: d.location.country_code, city: d.location.city, state: d.location.state, zip: d.location.zipcode, latitude: d.location.latitude, longitude: d.location.longitude, timezone: d.location.timezone, local_time: d.location.localtime } : null
          };
      } },
      { name: '090227', url: 'https://api.090227.xyz/api/ipsb?ip=' + encodeURIComponent(ip), parser: function (d) {
          // 国内可达的兜底源（同 admin.devtools）；无国家码也无 ASN 视为无效，继续回落
          if (!d || (!d.country_code && !d.asn)) return null;
          return {
            ip: ip,
            rir: '',
            company: { name: d.isp || d.as_name || '', domain: '', type: 'isp', abuser_score: null },
            asn: { asn: d.asn || '', org: d.as_name || '', country: d.country_code || '', abuser_score: null },
            location: { country: d.country || '', country_code: d.country_code || '', city: d.city || '', state: d.region || '', timezone: '' }
          };
      } },
      { name: 'ipwho.is', url: 'https://ipwho.is/' + ip, parser: function (d) {
          if (!d || d.success === false || !d.ip) return null;
          return {
            ip: d.ip,
            rir: '',
            company: { name: (d.connection && d.connection.isp) || '', domain: (d.connection && d.connection.domain) || '', type: 'isp', abuser_score: null },
            asn: { asn: (d.connection && d.connection.asn) || '', org: (d.connection && d.connection.org) || '', country: d.country_code || '', abuser_score: null },
            location: { country: d.country, country_code: d.country_code, city: d.city, state: d.region, zip: d.postal, latitude: d.latitude, longitude: d.longitude, timezone: d.timezone && d.timezone.id }
          };
      } },
      { name: 'ipapi.co', url: 'https://ipapi.co/' + ip + '/json/', parser: function (d) {
        return {
          ip: d.ip,
          rir: (d.org || '').indexOf('APNIC') !== -1 ? 'APNIC' : ((d.org || '').indexOf('RIPE') !== -1 ? 'RIPE' : 'ARIN'),
          company: { name: d.org || '-', type: d.asn ? 'isp' : 'unknown', abuser_score: '未知' },
          location: { country: d.country_name || '-', country_code: d.country_code || '-', city: d.city || '-', state: d.region || '-', timezone: d.timezone || '-' },
          asn: { asn: (d.asn || '').replace('AS', '') || '-', org: d.org || '-', type: 'isp', abuser_score: '未知' }
        };
      } },
      { name: 'zxinc', url: 'https://ip.zxinc.org/api.php?type=json&ip=' + ip, parser: function (d) {
        return d.code === 0 ? {
          ip: ip,
          rir: 'APNIC',
          company: { name: (d.data && d.data.isp) || '-', type: 'isp', abuser_score: '未知' },
          location: { country: (d.data && d.data.country) || '中国', country_code: 'CN', city: (d.data && d.data.local) || '-', state: '-', timezone: 'Asia/Shanghai' },
          asn: { asn: '-', org: (d.data && d.data.isp) || '-', type: 'isp', abuser_score: '未知' }
        } : null;
      } }
    ];
  }

  /**
   * 查询 IP 的完整情报：缺省取本机出口 IP；情报接口逐家回落 → RDAP 补齐 RIR/国家。
   * 失败抛错（调用方负责提示），成功返回归一化后的 detail 对象。
   */
  async function queryIpDetail(askIp) {
    var ip = askIp || await fetchOutboundIp();
    if (!ip) throw new Error('无法获取 IP');
    var apis = ipDetailApis(ip);
    var detail = null;
    for (var j = 0; j < apis.length; j++) {
      try {
        var r2 = await fetch(apis[j].url, { cache: 'no-store', signal: AbortSignal.timeout(5000) });
        if (!r2.ok) continue;
        var cand = apis[j].parser(await r2.json());
        // 完整性校验：至少要有位置或 ASN，防「只有 IP 的空壳」顶掉后续可用接口
        if (cand && cand.ip && (cand.location || cand.asn)) { detail = cand; break; }
      } catch (e) {}
    }
    if (!detail) throw new Error('查询失败');
    // 数据补齐：轻量接口（如 ipwho.is）不带 RIR/国家时，走 RDAP 注册目录兜底
    // （rdap.org 免费免钥、自动重定向到对应 RIR；按自引用链接识别归属注册机构）
    if (!detail.rir || !detail.location || !detail.location.country) {
      try {
        var rdap = await fetch('https://rdap.org/ip/' + ip, { signal: AbortSignal.timeout(6000) })
          .then(function (r) { return r.ok ? r.json() : null; })
          .catch(function () { return null; });
        if (rdap) {
          if (!detail.rir) {
            var hrefs = JSON.stringify(rdap.links || []).toLowerCase() + ' ' + String(rdap.handle || '').toLowerCase();
            var rirs = ['afrinic', 'apnic', 'lacnic', 'ripencc', 'arin'];   // 顺序敏感：arin 必须在 afrinic 之后判
            for (var k = 0; k < rirs.length; k++) {
              if (hrefs.indexOf(rirs[k]) !== -1) { detail.rir = rirs[k].toUpperCase(); break; }
            }
          }
          if (rdap.country) {
            detail.location = detail.location || {};
            if (!detail.location.country) detail.location.country = rdap.country;
            if (!detail.location.country_code) detail.location.country_code = rdap.country;
          }
        }
      } catch (e) {}
    }
    return detail;
  }

  // ---------- 网络检测：出口 IP 探测（国内/国外/CloudFlare/墙外，源清单参考 admin.devtools） ----------
  var EXIT_PROBE_TIMEOUT = 6000;
  /** 出口探测专用 fetch：统一超时/防缓存/防引用，自动加 _t 时间戳 */
  function exitFetch(url, options) {
    var sep = url.indexOf('?') === -1 ? '?' : '&';
    var opts = Object.assign({ cache: 'no-store', referrerPolicy: 'no-referrer', signal: AbortSignal.timeout(EXIT_PROBE_TIMEOUT) }, options || {});
    return fetch(url + sep + '_t=' + Date.now(), opts);
  }
  /** JSONP 探测：无 CORS 的国内接口用 script 标签取数，超时/失败自动清回调防泄漏 */
  function jsonpProbe(url, callbackParam, pick) {
    return new Promise(function (resolve, reject) {
      var name = '__exitProbe' + Date.now() + Math.floor(Math.random() * 1e6);
      var script = document.createElement('script');
      var timer = setTimeout(function () { cleanup(); reject(new Error('jsonp timeout: ' + url)); }, EXIT_PROBE_TIMEOUT);
      function cleanup() {
        clearTimeout(timer);
        if (script && script.parentNode) script.parentNode.removeChild(script);
        try { delete window[name]; } catch (e) { window[name] = undefined; }
      }
      window[name] = function (payload) {
        cleanup();
        var ip = String((pick && pick(payload)) || '').trim();
        if (!ip) { reject(new Error('jsonp missing ip: ' + url)); return; }
        resolve(ip);
      };
      script.src = url + (url.indexOf('?') === -1 ? '?' : '&') + callbackParam + '=' + name;
      script.onerror = function () { cleanup(); reject(new Error('jsonp failed: ' + url)); };
      document.head.appendChild(script);
    });
  }
  /** 并发跑多个探测任务取最快成功的一个，结束后取消其余（防连接堆积） */
  function raceProbe(makeTasks) {
    var tasks = makeTasks();
    return Promise.any(tasks.map(function (t) { return t.promise; })).finally(function () {
      tasks.forEach(function (t) { if (t.cancel) t.cancel(); });
    });
  }
  /** 国内出口：国内服务看到的本机 IP。HEAD 响应头直读优先，全挂再 JSONP 兜底 */
  async function probeDomesticExit() {
    try {
      return await raceProbe(function () {
        return [
          { name: '字节跳动', url: 'https://perfops2.byte-test.com/500b-bench.jpg', ipHeader: 'X-Request-Ip' },
          { name: '网易科技', url: 'https://necaptcha.nosdn.127.net/ab7f4275c1744aa28e0a8f3a1c58c532.png', ipHeader: 'cdn-user-ip' }
        ].map(function (s) {
          var controller = new AbortController();
          return {
            cancel: function () { controller.abort(); },
            promise: exitFetch(s.url, { method: 'HEAD', signal: controller.signal }).then(function (res) {
              if (!res.ok) throw new Error('HTTP ' + res.status);
              var ip = String(res.headers.get(s.ipHeader) || '').trim();
              if (!ip) throw new Error('missing ' + s.ipHeader);
              return { ip: ip, provider: s.name };
            })
          };
        });
      });
    } catch (e) {}
    return raceProbe(function () {
      return [
        { name: '腾讯新闻', url: 'https://r.inews.qq.com/api/ip2city?otype=jsonp', callbackParam: 'callback', pick: function (d) { return d.ip; } },
        { name: '太平洋科技', url: 'https://whois.pconline.com.cn/ipJson.jsp', callbackParam: 'callback', pick: function (d) { return d.ip; } },
        { name: '阿里巴巴', url: 'https://' + Date.now() + '.dns-detect.alicdn.com/api/detect/DescribeDNSLookup', callbackParam: 'cb', pick: function (d) { return d.content && d.content.localIp; } }
      ].map(function (s) {
        return { promise: jsonpProbe(s.url, s.callbackParam, s.pick).then(function (ip) { return { ip: ip, provider: s.name }; }) };
      });
    });
  }
  /** 国外出口：未被封的国外站点看到的本机 IP，双源并发取最快 */
  function probeOverseasExit() {
    return raceProbe(function () {
      return [
        { url: 'https://api.ipapi.is', pick: function (d) { return d.ip; } },
        { url: 'https://api.cmliussss.net/api/ipinfo', pick: function (d) { return d.ip; } }
      ].map(function (s) {
        var controller = new AbortController();
        return {
          cancel: function () { controller.abort(); },
          promise: exitFetch(s.url, { signal: controller.signal }).then(function (res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.json().then(function (d) {
              var ip = String((s.pick(d)) || '').trim();
              if (!ip) throw new Error('missing ip: ' + s.url);
              return { ip: ip };
            });
          })
        };
      });
    });
  }
  /** CloudFlare 落地：经 CF CDN 的 v4/v6 双出口并发探测，v4 优先展示 */
  async function probeCfExit() {
    var results = await Promise.allSettled(['https://ipv4.090227.xyz', 'https://ipv6.090227.xyz'].map(function (url) {
      return exitFetch(url).then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json().then(function (d) {
          var ip = String((d && d.ip) || '').trim();
          if (!ip) throw new Error('missing cf ip');
          return { ip: ip, v6: url.indexOf('ipv6') !== -1 };
        });
      });
    }));
    var entries = [];
    results.forEach(function (r) { if (r.status === 'fulfilled') entries.push(r.value); });
    if (!entries.length) throw new Error('cf exit all failed');
    entries.sort(function (a, b) { return (a.v6 === b.v6) ? 0 : (a.v6 ? 1 : -1); });   // v4 在前
    return { ip: entries[0].ip };
  }
  /** 墙外出口：谷歌(JSONP) + 推特(X.com CF trace) 双源并发全保留（allSettled 不取消慢源），供卡片切换来源（同 admin.devtools） */
  async function probeWallExit() {
    var sources = [
      { provider: '谷歌(Google)', make: function () {
          return jsonpProbe('https://jsonp-ip.appspot.com/?_t=' + Date.now(), 'callback', function (d) { return d && d.ip; })
            .then(function (ip) { return { provider: '谷歌(Google)', ip: ip }; });
      } },
      { provider: '推特(X.com)', make: function () {
          return exitFetch('https://help.x.com/cdn-cgi/trace').then(function (res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.text().then(function (text) {
              var line = text.split('\n').find(function (l) { return l.indexOf('ip=') === 0; });
              var ip = line ? line.slice(3).trim() : '';
              if (!ip || ip === '0.0.0.0') throw new Error('wall exit invalid ip');
              return { provider: '推特(X.com)', ip: ip };
            });
          });
      } }
    ];
    var results = await Promise.allSettled(sources.map(function (s) { return s.make(); }));
    var first = null;
    for (var i = 0; i < results.length; i++) {
      if (results[i].status === 'fulfilled') { first = results[i].value; break; }   // 谷歌优先，其次推特
    }
    if (!first) throw new Error('wall exit all failed');
    return { ip: first.ip };
  }
  /** 情报详情 → 卡片位置行「Narita · Cloudflare, Inc.」（城市 · 组织；缺城市用国家名兜底，无组织用 AS 号） */
  function exitLocLine(d) {
    var loc = (d && d.location) || {};
    var asn = (d && d.asn && d.asn.asn) ? 'AS' + String(d.asn.asn).replace(/^AS/i, '') : '';
    var org = ((d && d.asn && d.asn.org) || (d && d.company && d.company.name) || '');
    var place = (loc.city || loc.country || '');
    var line = [place.trim(), (org || asn)].filter(Boolean).join(' · ');
    return line || '未知';
  }

  window.LiteCore = {
    // 通用工具
    escHtml: escHtml,
    fmtNum: fmtNum,
    pagerPages: pagerPages,
    copyText: copyText,
    downloadText: downloadText,
    // 本地状态
    stStoreRead: stStoreRead,
    stStoreWrite: stStoreWrite,
    stCfgRead: stCfgRead,
    stCfgWrite: stCfgWrite,
    regionCacheClear: regionCacheClear,
    stLookupRegion: stLookupRegion,
    cfgDraftRead: cfgDraftRead,
    cfgDraftWrite: cfgDraftWrite,
    cfgDraftClear: cfgDraftClear,
    // 地址解析
    stParseAddr: stParseAddr,
    stSplitAddr: stSplitAddr,
    nlMapItem: nlMapItem,
    stBuildList: stBuildList,
    // 测速探测
    stRunPool: stRunPool,
    stTestNode: stTestNode,
    stTestProxy: stTestProxy,
    // 文案映射
    stTimeHM: stTimeHM,
    stKindLabel: stKindLabel,
    stTipOf: stTipOf,
    nlTipOf: nlTipOf,
    stDisplayAddr: stDisplayAddr,
    proxyModeLabel: proxyModeLabel,
    inboundLabel: inboundLabel,
    fmtLogTime: fmtLogTime,
    // 网络检测 / IP 情报
    testLatency: testLatency,
    latencyColor: latencyColor,
    queryIpDetail: queryIpDetail,
    probeDomesticExit: probeDomesticExit,
    probeOverseasExit: probeOverseasExit,
    probeCfExit: probeCfExit,
    probeWallExit: probeWallExit,
    exitLocLine: exitLocLine,
    calcAbuseScore: calcAbuseScore,
    fmtAbuserScore: fmtAbuserScore,
    abuseScoreBadge: abuseScoreBadge
  };
})();
