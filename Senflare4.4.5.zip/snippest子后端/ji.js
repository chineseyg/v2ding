import { connect } from 'cloudflare:sockets';

const uuid = '0824d218-0d00-428d-93c4-17c0a41574ed';   // UUID 验证
const builtinProxies = atob('MTcyLjcxLjIxOC4yMywxNjIuMTU4LjE3Ni42MywxNjIuMTU4LjExNC4yMjgsMTcyLjcxLjIxNS4xNTcsMTcyLjY5LjEzNS4xNzA=').split(','); // base64压缩：5个官方反代IP

const uuidBytes = Uint8Array.from(uuid.replace(/-/g, '').match(/../g), h => parseInt(h, 16));
const decoder = new TextDecoder();

const addrToString = (type, b) => {
    if (type === 2) return decoder.decode(b);
    if (type === 1) return `${b[0]}.${b[1]}.${b[2]}.${b[3]}`;
    let s = '';
    for (let i = 0; i < 16; i += 2) s += ((b[i] << 8) | b[i + 1]).toString(16) + ':';
    return `[${s.slice(0, -1)}]`;
};

// 解析 VLESS 首包：完整返回请求；不完整 {needMore}；UUID 校验失败返回 null
const parseVLESS = (c) => {
    if (c.length < 17) return { needMore: true };
    for (let i = 0; i < 16; i++) if (c[i + 1] !== uuidBytes[i]) return null;
    if (c.length < 18) return { needMore: true };
    const p = 19 + c[17];
    if (c.length < p + 3) return { needMore: true };
    if (c[p - 1] !== 1) return null;   // 仅支持 VLESS TCP（cmd=1）；UDP 请求立即拒绝，避免 QUIC 黑洞
    const type = c[p + 2];
    if (type < 1 || type > 3) return null;
    const addrLen = type === 2 ? c[p + 3] : type === 1 ? 4 : 16;
    const addrStart = type === 2 ? p + 4 : p + 3;
    const dataOffset = addrStart + addrLen;
    if (c.length < dataOffset) return { needMore: true };
    return { host: addrToString(type, c.subarray(addrStart, dataOffset)), port: (c[p] << 8) | c[p + 1], payload: c.subarray(dataOffset) };
};

const b64ToBytes = (s) => {
    s = s.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    return Uint8Array.from(atob(s), ch => ch.charCodeAt(0));
};

// 连接策略：① Workers 直连 ②路径第三方反代(固定落地) ③内置官方IP(随机跳)
async function openTcp(host, port, proxyAddr) {
    const targets = [[host, port]];
    if (proxyAddr) {
        const i = proxyAddr.lastIndexOf(':');
        targets.push(i > 0 ? [proxyAddr.slice(0, i), +proxyAddr.slice(i + 1) || port] : [proxyAddr, port]);
    }
    for (const ip of builtinProxies.slice().sort(() => Math.random() - 0.5)) targets.push([ip, port]);
    for (const [hostname, p] of targets) {
        try {
            const socket = connect({ hostname, port: p });
            await socket.opened;
            return socket;
        } catch {}
    }
    throw new Error('all connect attempts failed');
}

async function handleSession(ws, request, proxyAddr) {
    const state = { socket: null, writer: null, handshaking: false, pending: [] };
    const close = () => {
        try { state.socket?.close(); } catch {}
        try { ws.close(); } catch {}
    };
    let buffer = new Uint8Array(0);
    /** @type {Promise<any>} */
    let chain = Promise.resolve();

    const handleChunk = (chunk) => {
        if (state.socket) { state.writer.write(chunk).catch(() => close()); return; }   // 已建隧道→转发
        if (state.handshaking) { state.pending.push(chunk); return; }                     // 已解析待连接→缓存
        const merged = new Uint8Array(buffer.length + chunk.length);
        if (buffer.length) merged.set(buffer);
        merged.set(chunk, buffer.length);
        const req = parseVLESS(merged);
        if (!req) return close();                                       // UUID 错误
        if (req.needMore) { buffer = merged; return; }                  // 数据不完整，缓存并等待
        state.handshaking = true;
        openTcp(req.host, req.port, proxyAddr).then(socket => {
            state.socket = socket;
            state.writer = socket.writable.getWriter();
            ws.send(new Uint8Array([0, 0]));                            // VLESS 响应头
            const flush = (c) => c && c.length && state.writer.write(c).catch(() => {});
            flush(req.payload);                                          // 首包附带数据
            while (state.pending.length) flush(state.pending.shift());  // 连接期间缓存的数据
            socket.readable.pipeTo(new WritableStream({ write: (d) => ws.send(d) })).then(() => ws.close()).catch(close);
        }).catch(() => close());
    };

    const early = request.headers.get('sec-websocket-protocol');        // 0-RTT 早数据
    if (early) chain = chain.then(() => handleChunk(b64ToBytes(early))).catch(close);
    ws.addEventListener('message', (e) => { chain = chain.then(() => handleChunk(new Uint8Array(e.data))).catch(close); });
    ws.addEventListener('error', close);
}

export default {
    async fetch(request) {
        if (request.headers.get('Upgrade')?.toLowerCase() !== 'websocket')
            return new Response('Hello, world!', { status: 200 });
        const { 0: client, 1: server } = new WebSocketPair();
        server.accept();
        server.binaryType = 'arraybuffer';
        // 路径反代：/IP  /IP:端口  /ip=IP  /proxy=IP  或 ?ip= / ?proxy=；留空仅用内置IP
        const url = new URL(request.url);
        let proxyAddr = url.pathname.length > 1 ? decodeURIComponent(url.pathname.slice(1)) : '';
        proxyAddr = proxyAddr.replace(/^(ip|proxy)=/i, '') || url.searchParams.get('ip') || url.searchParams.get('proxy') || '';
        proxyAddr = proxyAddr.split('/')[0] || null;
        handleSession(server, request, proxyAddr);
        return new Response(null, { status: 101, webSocket: client });
    }
};