/**
 * Senflare Link Lite — Admin UI（渲染与交互层）
 * 分层：接口与业务逻辑全在 js/admin.js（LiteAPI / LiteCore），本文件只做 DOM 与事件，
 * 主题（明暗切换 + 调色盘）整体在 js/theme.js
 */
(function () {
  var VIEWS = ['dashboard', 'nodes', 'nodelist', 'security', 'logs', 'advanced', 'about'];

  // ============ 逻辑层引用（js/admin.js → window.LiteCore） ============
  var Core = window.LiteCore || {};
  var escHtml = Core.escHtml, cfFmt = Core.fmtNum, pagerPages = Core.pagerPages;
  var copyText = Core.copyText, downloadText = Core.downloadText;
  var stStoreRead = Core.stStoreRead, stStoreWrite = Core.stStoreWrite, stCfgRead = Core.stCfgRead;
  var cfgDraftRead = Core.cfgDraftRead, cfgDraftClear = Core.cfgDraftClear;
  var stParseAddr = Core.stParseAddr, stSplitAddr = Core.stSplitAddr, nlMapItem = Core.nlMapItem;
  var stBuildList = Core.stBuildList, stRunPool = Core.stRunPool;
  var stTestNode = Core.stTestNode, stTestProxy = Core.stTestProxy;
  var stTimeHM = Core.stTimeHM, stKindLabel = Core.stKindLabel, stTipOf = Core.stTipOf;
  var nlTipOf = Core.nlTipOf, stDisplayAddr = Core.stDisplayAddr;
  var proxyModeLabel = Core.proxyModeLabel, inboundLabel = Core.inboundLabel;
  var testLatency = Core.testLatency, getLatencyColor = Core.latencyColor;
  var calcAbuseScore = Core.calcAbuseScore, fmtAbuserScore = Core.fmtAbuserScore, getAbuseScoreBadge = Core.abuseScoreBadge;

  // ============ 侧边栏 / 卡片 / Toast / 导航 ============
  var FOLD_CHEVRON = {
    up: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>',
    down: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>'
  };
  function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    if (!sidebar) return;
    if (window.innerWidth <= 768) {
      sidebar.classList.toggle('show');
      if (overlay) overlay.classList.toggle('show');
    } else {
      sidebar.classList.toggle('expanded');
    }
  }
  function toggleCard(btn) {
    var card = btn.closest('.card');
    if (!card) return;
    var body = card.querySelector('.card-body');
    if (!body) return;
    var hidden = body.style.display === 'none';
    body.style.display = hidden ? 'block' : 'none';
    btn.innerHTML = hidden ? FOLD_CHEVRON.up : FOLD_CHEVRON.down;   // 展开态向上箭头，折叠态向下（复用 dock 折叠图标）
  }
  var showToast = window.showToast;   // Toast 唯一实现在 admin.js，此处仅别名引用
  // 节点配置：未保存守卫（草稿非空即有修改）
  function cfgHasUnsaved() {
    var d = cfgDraftRead();
    for (var k in d) { if (Object.prototype.hasOwnProperty.call(d, k)) return true; }
    return false;
  }
  function cfgViewActive() {
    var s = document.querySelector('#view-nodes .nodes-subview[data-sub="config"]');
    return !!(s && s.style.display === 'block');
  }
  function doSwitchTab(tab, el) {
    var mainTab = tab;
    if (tab === 'nodes-list') mainTab = 'nodelist';           // 节点列表 = 独立视图
    else if (tab.indexOf('nodes-') === 0) mainTab = 'nodes';
    document.querySelectorAll('.nav-item').forEach(function (a) { a.classList.remove('active'); });
    if (el) el.classList.add('active');
    else {
      var sel = document.querySelector('.nav-item[data-tab="' + tab + '"]') || document.querySelector('.nav-item[data-tab="' + mainTab + '"]');
      if (sel) sel.classList.add('active');
    }
    try { localStorage.setItem('sf_lite_tab', tab); } catch (e) {}   // 记住当前 tab，刷新后保持
    if (window.innerWidth <= 768) {
      var sidebar = document.getElementById('sidebar');
      var overlay = document.querySelector('.sidebar-overlay');
      if (sidebar && sidebar.classList.contains('show')) {
        sidebar.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
      }
    }
    VIEWS.forEach(function (v) {
      var view = document.getElementById('view-' + v);
      if (view) view.style.display = (v === mainTab) ? 'block' : 'none';
    });
    if (mainTab === 'nodes') {
      var sub = tab.indexOf('nodes-') === 0 ? tab.replace('nodes-', '') : 'config';
      document.querySelectorAll('.nodes-subview').forEach(function (s) {
        s.style.display = (s.getAttribute('data-sub') === sub) ? 'block' : 'none';
      });
    }
    // 悬浮操作按钮（保存/恢复默认）仅在节点配置子视图显示
    var cfgFab = document.getElementById('cfgFab');
    if (cfgFab) {
      var fabSub = tab.indexOf('nodes-') === 0 ? tab.replace('nodes-', '') : 'config';
      cfgFab.classList.toggle('show', mainTab === 'nodes' && fabSub === 'config');
    }
    if (mainTab === 'nodelist') fillNodeList();             // 节点列表：/api/nodelist 按配置解析真实来源
    else if (mainTab === 'nodes' && sub === 'speedtest') fillSpeedTest();   // 在线优选（进入子视图后再渲染，保证列宽度量准确）
    else if (mainTab === 'nodes' && sub === 'subscription') fillSubUrl();   // 切回订阅页时按最新配置刷新已生成的链接
    else if (mainTab === 'nodes' && sub === 'config') loadCfgForm(true);
    else if (mainTab === 'nodes' && sub === 'backend') ensureCfLoaded(true);    // 后端配置：每次进入强制拉取 CF 账号（跨页/跨标签改动即时可见）
    else if (mainTab === 'dashboard') { dashboardLoad(); ensureNetCheck(); ensureNetExit(); }   // 数据看板：运行状态 + 用量环 + 网络检测（首次进入触发）
    else if (mainTab === 'advanced') { fillSystemBar(); loadCfgForm(); }   // 高级设置：系统状态栏 + 首页伪装等 data-cfg 回填
    else if (mainTab === 'security') fillSecurity();                        // 安全设置：账号/登录安全/限流/黑名单回填
    else if (mainTab === 'logs') fillLogs();                                // 系统日志：拉取并渲染操作日志
    var content = document.querySelector('.content');
    if (content) content.scrollTo(0, 0);
  }
  // 未保存守卫：离开节点配置页时弹窗询问「保存并离开 / 直接离开」，保存失败则留在本页提示
  function requestLeaveNodesConfig(go) {
    var staying = go.tab === 'nodes' || go.tab === 'nodes-config';
    if (staying || !cfgViewActive() || !cfgHasUnsaved()) { doSwitchTab(go.tab, go.el); return; }
    window.__showConfirm('节点配置有未保存的修改，是否保存后再离开？',
      async function () {                                  // 「保存并离开」
        await window.__saveCfg();
        if (cfgHasUnsaved()) {                             // 草稿仍在 = 保存失败：留下，可改选直接离开
          showToast('保存失败：请检查后端连接，或选择「直接离开」放弃修改', true);
          return;
        }
        doSwitchTab(go.tab, go.el);
      },
      '未保存的修改',
      { okText: '保存并离开', cancelText: '直接离开',
        onDiscard: function () { cfgDraftClear(); doSwitchTab(go.tab, go.el); } });
  }
  function switchTab(tab, el) { requestLeaveNodesConfig({ tab: tab, el: el }); }

  // ============ 节点/反代配置：模式下拉 ↔ 编辑框显隐联动（UI-only） ============
  // 预设模式隐藏编辑框，仅 CUSTOM/LOCAL 显示
  // data-cfg 键名对应 ConfigKeys
  function cfgModeLink(mode, customSel, localTa) {
    var m = String(mode || '').toUpperCase();
    var main = document.querySelector('[data-cfg="' + customSel + '"]');
    var local = document.querySelector('[data-cfg="' + localTa + '"]');
    var isCustom = m === 'CUSTOM';
    var isLocal = m === 'LOCAL';
    if (main) main.style.display = isCustom ? '' : 'none';
    if (local) local.style.display = isLocal ? '' : 'none';
  }
  window.__cfgIPMode = function (mode) { cfgModeLink(mode, 'IP', 'LocalIP'); };
  window.__cfgProxyIPMode = function (mode) { cfgModeLink(mode, 'ProxyIP', 'LocalProxyIP'); syncFixedOutbound(); };
  // 链式代理开关 ↔ 上游出口编辑框显隐
  window.__cfgChainToggle = function (on) {
    var ta = document.querySelector('[data-cfg="Upstream"]');
    if (ta) ta.style.display = on ? '' : 'none';
  };

  // Fixed 反代只在 CUSTOM/LOCAL 下生效：置灰并隐藏其他模式
  var FIXED_LOCKABLE = ['CUSTOM', 'LOCAL'];
  function syncFixedOutbound() {
    var ob = document.querySelector('[data-cfg="Outbound"]');
    var pm = document.querySelector('[data-cfg="ProxyIPMode"]');
    var hint = document.getElementById('outbound-fixed-hint');
    if (!ob || !pm) return;
    var fixed = String(ob.value || '').toLowerCase() === 'fixed';

    Array.prototype.forEach.call(pm.options, function (o) {
      var lock = fixed && FIXED_LOCKABLE.indexOf(o.value.toUpperCase()) === -1;
      o.disabled = lock;
      o.style.display = lock ? 'none' : '';
    });
    // 同步已增强的 ms-panel 下拉选项显隐
    var ms = pm.nextElementSibling;
    if (ms && ms.classList && ms.classList.contains('ms')) {
      Array.prototype.forEach.call(pm.options, function (o) {
        var opt = ms.querySelector('.ms-opt[data-val="' + o.value + '"]');
        if (opt) opt.style.display = o.style.display || '';
      });
    }

    if (!fixed) { if (hint) hint.style.display = 'none'; return; }

    // 当前选中项已被置灰 → 回落到 CUSTOM 并提示发生了切换
    var cur = String(pm.value || '').toUpperCase();
    if (FIXED_LOCKABLE.indexOf(cur) === -1) {
      pm.value = 'CUSTOM';
      cfgModeLink('CUSTOM', 'ProxyIP', 'LocalProxyIP');
      syncMsTrigger(pm);
      if (!CFG_FILLING) cfgDraftSave(pm);
      if (hint) { hint.textContent = 'Fixed 固定反代仅支持「自定义 / 在线优选」出口，已自动切换为自定义模式。'; hint.style.display = ''; }
      return;
    }

    // 合法模式但出口列表为空 → 提示无可用出口（不静默保存空列表）；链式出口非空时出口走上游，跳过反代池校验
    var upTa = document.querySelector('[data-cfg="Upstream"]');
    if (upTa && String(upTa.value || '').trim()) { if (hint) hint.style.display = 'none'; return; }
    var listEl = document.querySelector('[data-cfg="' + (cur === 'LOCAL' ? 'LocalProxyIP' : 'ProxyIP') + '"]');
    var empty = !listEl || !String(listEl.value || '').trim();
    if (hint) {
      if (empty) { hint.textContent = '反代 IP 列表为空，Fixed 将无可用出口，请填入需要落地的 IP:端口。'; hint.style.display = ''; }
      else hint.style.display = 'none';
    }
  }
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (!t || !t.dataset || !t.dataset.cfg) return;
    if (t.dataset.cfg === 'Outbound') syncFixedOutbound();
  });
  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t && t.dataset && (t.dataset.cfg === 'ProxyIP' || t.dataset.cfg === 'LocalProxyIP')) syncFixedOutbound();
  });
  // 「预设下拉 + 自定义输入」通用联动：选中 自定义… 时展开配套输入框
  document.addEventListener('change', function (e) {
    var s = e.target;
    if (!s || !s.matches || !s.matches('select[data-custom-target]')) return;
    var inp = document.getElementById(s.getAttribute('data-custom-target'));
    if (inp) inp.style.display = s.value === 'custom' ? '' : 'none';
  });
  // ALPN 风险确认：每次切到显式值都弹（回填中的合成 change 不触发；取消一键回退默认）
  document.addEventListener('change', function (e) {
    var s = e.target;
    if (!s || !s.matches || !s.matches('select[data-cfg="Alpn"]') || CFG_FILLING || !s.value) return;
    window.__showConfirm(
      '是否切换 ALPN？设置不当可能导致节点与您的客户端或网络环境不兼容，从而导致节点无法连接。如果您不确定该选项的含义与影响，建议保持默认「自动协商」，由客户端自行处理',
      function () { },   // 确定保持当前选择
      'ALPN 风险提示',
      { danger: true,
        onDiscard: function () { s.value = ''; cfgDraftSave(s); s.dispatchEvent(new Event('change', { bubbles: true })); } });
  });

  // ============ 节点配置：服务端配置（/api/config）+ 本地未保存编辑 ============
  // 数据流：回填（草稿优先）→ 保存写 D1 清草稿
  function cfgDraftSave(el) {
    if (!el.dataset.cfg) return;
    var d = cfgDraftRead();
    d[el.dataset.cfg] = el.type === 'checkbox' ? el.checked : el.value;
    Core.cfgDraftWrite(d);
  }
  // 编辑即暂存：未保存的修改记入本地草稿（优先级高于服务端值），保存成功后清除，
  // CFG_FILLING = 表单回填中，合成 change 不计草稿
  var CFG_FILLING = false;
  document.addEventListener('input', function (e) {
    var t = e.target;
    if (CFG_FILLING) return;
    if (t && t.dataset && t.dataset.cfg && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) cfgDraftSave(t);
  });
  try { localStorage.removeItem('sf_lite_cfg_draft_v1'); } catch (e) {}   // 清理遗留旧版草稿键
  var CFG_SERVER = null;        // 最近一次 /api/config 结果（订阅页取 SubPath 等复用）
  var CFG_LOADING = false;
  var CFG_WAITERS = [];
  function ensureCfgLoaded(force) {
    if (!window.LiteAPI) return Promise.resolve(null);   // 纯静态预览：跳过
    if (CFG_SERVER && !force) return Promise.resolve(CFG_SERVER);
    if (CFG_LOADING) return new Promise(function (res) { CFG_WAITERS.push(res); });
    CFG_LOADING = true;
    return LiteAPI.getConfig().then(function (c) {
      CFG_LOADING = false;
      if (c) CFG_SERVER = c;
      CFG_WAITERS.splice(0).forEach(function (w) { w(CFG_SERVER); });
      return CFG_SERVER;
    });
  }
  // 单个控件按「草稿 > 服务端」填值，下拉值不在预设选项时落到配套自定义输入框
  function fillCfgControl(el, srv, draft) {
    var k = el.dataset.cfg;
    var hasDraft = Object.prototype.hasOwnProperty.call(draft, k);
    if (!hasDraft && !(k in srv)) return;
    var v = hasDraft ? draft[k] : srv[k];
    if (el.type === 'checkbox') { el.checked = v === true || v === 'true'; return; }
    var sv = String(v == null ? '' : v);
    if (el.tagName === 'SELECT') {
      // 大小写不敏感匹配：NodeDefaults 里 IPMode='Custom'/ProxyIPMode='Auto'，
      // 而下拉选项值是大写 CUSTOM/AUTO——严格相等会误判为「自定义值」落进自定义输入框
      var up = sv.toUpperCase();
      var hitOpt = null;
      Array.prototype.forEach.call(el.options, function (o) {
        if (!hitOpt && o.value.toUpperCase() === up) hitOpt = o;
      });
      if (hitOpt) {
        el.value = hitOpt.value;
      } else if (sv) {
        var cust = document.getElementById(el.getAttribute('data-custom-target') || '');
        if (cust) { cust.value = sv; el.value = 'custom'; }
      }
      el.dispatchEvent(new Event('change', { bubbles: true }));   // 触发 LOCAL 显隐 / 自定义输入显隐 / ms 文案联动
    } else {
      el.value = sv;
    }
  }
  async function loadCfgForm(force) {
    var srv = await ensureCfgLoaded(force);
    if (!srv) return;
    var draft = cfgDraftRead();
    CFG_FILLING = true;                       // 回填产生的合成 change 不计入用户编辑
    try {
      document.querySelectorAll('select[data-cfg]').forEach(function (el) { fillCfgControl(el, srv, draft); });
      document.querySelectorAll('input[data-cfg],textarea[data-cfg]').forEach(function (el) { fillCfgControl(el, srv, draft); });
      var chainCb = document.querySelector('[data-cfg="ChainEnabled"]');
      if (chainCb) __cfgChainToggle(chainCb.checked);   // 回填后同步上游编辑框显隐（checkbox 回填不派发 change）
    } finally { CFG_FILLING = false; }
  }
  // 收集全部 data-cfg 控件，选中「自定义」的下拉用配套输入框的实际值覆盖
  function collectCfgPayload() {
    var payload = {};
    document.querySelectorAll('[data-cfg]').forEach(function (el) {
      if (el.disabled) return;
      // 伪装两键（FakePage/FakeUrl）由高级设置页专属按钮 __saveFakePage 保存：
      // 高级设置未打开过时这两个控件是 DOM 默认值（关/空），悬浮保存若一并收集会把刚开启的伪装覆写回关闭
      if (el.dataset.cfg === 'FakePage' || el.dataset.cfg === 'FakeUrl') return;
      payload[el.dataset.cfg] = el.type === 'checkbox' ? el.checked : String(el.value).trim();
    });
    document.querySelectorAll('select[data-cfg][data-custom-target]').forEach(function (sel) {
      if (sel.disabled || sel.value !== 'custom') return;
      var cust = document.getElementById(sel.getAttribute('data-custom-target'));
      if (cust && String(cust.value).trim()) payload[sel.dataset.cfg] = String(cust.value).trim();
    });
    return payload;
  }
  // 整体写入 D1（服务端白名单过滤）
  window.__saveCfg = async function () {
    if (!window.LiteAPI) { showToast('后端未接入', true); return; }
    var r = await LiteAPI.saveConfig(collectCfgPayload());
    if (!r) { showToast('保存失败：后端未返回结果（请检查登录态与后端连接）', true); return; }
    cfgDraftClear();
    CFG_SERVER = null;                       // 下次进入重新拉取，保证展示与库内一致
    DASH_STATUS = null;                      // 看板状态含订阅域名等配置快照，保存后同步失效
    if (r.message) showToast(r.message); else { showToast('配置已保存'); }
  };
  // 仅保存 FakePage/FakeUrl，避免误存其他视图草稿
  window.__saveFakePage = async function () {
    if (!window.LiteAPI) { showToast('后端未接入', true); return; }
    var fp = document.querySelector('[data-cfg="FakePage"]');
    var fu = document.querySelector('[data-cfg="FakeUrl"]');
    if (!fp || !fu) return;
    var r = await LiteAPI.saveConfig({ FakePage: fp.checked, FakeUrl: String(fu.value).trim() });
    if (!r) { showToast('保存失败：后端未返回结果（请检查登录态与后端连接）', true); return; }
    CFG_SERVER = null;                       // 下次进入重新拉取，保证展示与库内一致
    if (r.message) showToast(r.message); else { showToast('配置已保存'); }
  };
  // ms 触发器文本与选中态跟随 select 值同步
  function syncMsTrigger(sel) {
    var box = sel.nextElementSibling;
    if (!box || !box.classList.contains('ms')) return;
    var o = sel.options[sel.selectedIndex];
    var v = box.querySelector('.ms-value');
    if (v && o) v.textContent = o.textContent;
    box.querySelectorAll('.ms-opt.single').forEach(function (opt) {
      opt.classList.toggle('active', opt.dataset.val === sel.value);
    });
  }
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (!t || !t.dataset || !t.dataset.cfg || t.tagName !== 'SELECT') return;
    if (!CFG_FILLING) cfgDraftSave(t);   // 回填中的合成 change 只做 UI 同步，不计入用户编辑
    syncMsTrigger(t);
  });
  // 清空 D1 白名单键并清本地草稿
  window.__resetCfgDraft = async function () {
    if (!window.LiteAPI) { cfgDraftClear(); location.reload(); return; }
    if (!(await themeConfirm('确定恢复默认配置？将清除 D1 中保存的全部节点/反代配置。', '恢复默认配置', { danger: true }))) return;
    var r = await LiteAPI.saveConfig({ RESET: true });
    if (!r) return;
    cfgDraftClear();
    CFG_SERVER = null;
    showToast('已恢复默认配置');
    setTimeout(function () { location.reload(); }, 800);
  };

  // ============ 节点订阅 ============
  // 订阅格式参数（全本地生成）
  var SUB_FMTS = {
    auto:    '',                // 自适应：Worker 按 UA 检测客户端
    b64:     '?b64',            // base64 订阅链接（V2ray 系）
    clash:   '?clash',          // Mihomo
    singbox: '?singbox',
    loon:    '?loon',           // Loon
    quanx:   '?target=quanx'    // Quantumult X
  };
  var subFmt = '';
  var subCred = 'uuid';       // 订阅凭证 tab：uuid | key（未设密钥时 key 侧回落 UUID 链接）
  // 订阅根地址：/api/status 下发，静态预览回落「域名+配置路径」
  function subUrlAsync() {
    if (window.LiteAPI) {
      return LiteAPI.getStatus().then(function (s) {
        return { base: (s && s.subUrl) || '', key: (s && s.subKeyUrl) || '' };
      });
    }
    return ensureCfgLoaded().then(function (srv) {
      if (!location.origin || location.origin === 'null') return { base: '', key: '' };
      var d = cfgDraftRead() || {};
      var raw = Object.prototype.hasOwnProperty.call(d, 'SubPath')
        ? d.SubPath
        : (srv && srv.SubPath != null ? srv.SubPath : '');
      var p = '/' + String(raw == null ? '' : raw).trim().replace(/^\/+|\/+$/g, '');
      if (p === '/') p = '/links';
      return { base: location.origin + p, key: '' };
    });
  }
  // 切换订阅凭证 tab（UUID / 密钥）：已生成过链接时立即按新凭证重取
  function switchSubCred(cred) {
    subCred = cred === 'key' ? 'key' : 'uuid';
    document.querySelectorAll('.sub-cred-group [data-cred]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-cred') === subCred);
    });
    fillSubUrl();
  };
  function generateSub(type) {
    if (!SUB_FMTS.hasOwnProperty(type)) type = 'auto';
    subFmt = type;
    document.querySelectorAll('.sub-format-group [data-fmt]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-fmt') === type);
    });
    var grp = document.getElementById('sub-result-group');
    if (grp) grp.style.display = 'block';
    hideSubQR();
    fillSubUrl();
  }
  // 组装并刷新当前展示链接：点按钮生成与切回订阅页共用（ 每次都取最新配置 ）
  function fillSubUrl() {
    if (!subFmt) return;
    subUrlAsync().then(function (u) {
      var inp = document.getElementById('generated-sub-url');
      if (!inp) return;
      if (!u.base) { showToast('本地文件预览无法生成订阅链接，请部署后使用', true); return; }
      var next = (subCred === 'key' && u.key ? u.key : u.base) + SUB_FMTS[subFmt];
      if (inp.value && inp.value !== next) hideSubQR();   // 链接已变化：旧扫码作废，收起防止扫到失效链接
      inp.value = next;
    });
  }
  function copySubUrl() {
    var inp = document.getElementById('generated-sub-url');
    if (!inp || !inp.value) { showToast('请先生成订阅链接', true); return; }
    copyText(inp.value, '订阅链接已复制到剪贴板');
  }
  function toggleSubQR() {
    var box = document.getElementById('qrcode-container');
    if (!box) return;
    if (box.style.display === 'flex') { hideSubQR(); return; }         // 再点一次收起
    var inp = document.getElementById('generated-sub-url');
    if (!inp || !inp.value) { showToast('请先生成订阅链接', true); return; }
    if (typeof QRCode === 'undefined') { showToast('扫码组件未加载', true); return; }
    box.innerHTML = '';
    box.style.display = 'flex';
    new QRCode(box, { text: inp.value, width: 180, height: 180, colorLight: 'transparent', correctLevel: QRCode.CorrectLevel.M });
  }
  function hideSubQR() {
    var box = document.getElementById('qrcode-container');
    if (box) { box.style.display = ''; box.innerHTML = ''; }           // 清空内联样式回落 CSS display:none
  }

  // ============ 原生 select 全局替换为 ms-panel 自建下拉（禁止浏览器默认样式接管） ============
  var MS_CARET = '<svg class="ms-caret" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"></path></svg>';
  // 毛玻璃卡片各自成层叠上下文：展开下拉时给宿主卡片临时抬层，收起后撤掉
  function syncCardLift() {
    document.querySelectorAll('.card.ms-open-card').forEach(function (c) {
      if (!c.querySelector('.ms.open')) c.classList.remove('ms-open-card');
    });
  }
  function enhanceSelects(scope) {
    (scope || document).querySelectorAll('select:not([data-ms])').forEach(function (sel) {
      sel.setAttribute('data-ms', '1');
      sel.classList.add('hidden');
      var box = document.createElement('div');
      box.className = 'ms';
      var value = document.createElement('span');
      value.className = 'ms-value';
      var trigger = document.createElement('button');
      trigger.type = 'button';
      trigger.className = 'ms-trigger ui-field';
      if (sel.disabled) trigger.disabled = true;
      trigger.appendChild(value);
      trigger.insertAdjacentHTML('beforeend', MS_CARET);
      var list = document.createElement('div');
      list.className = 'ms-list';
      Array.prototype.forEach.call(sel.options, function (o) {
        var opt = document.createElement('div');
        opt.className = 'ms-opt single';
        opt.dataset.val = o.value;
        opt.textContent = o.textContent.trim();
        opt.style.display = o.style.display || '';   // 镜像原生 option 的显隐（Fixed 联动隐藏非 CUSTOM/LOCAL）
        opt.onclick = function () {
          sel.value = o.value;
          sync();
          closePanel();
          sel.dispatchEvent(new Event('change', { bubbles: true }));   // 需冒泡：文档级自定义输入联动依赖它
        };
        list.appendChild(opt);
      });
      var panel = document.createElement('div');
      panel.className = 'ms-panel';
      panel.appendChild(list);
      box.appendChild(trigger);
      box.appendChild(panel);
      function sync() {
        var o = sel.options[sel.selectedIndex];
        value.textContent = o ? o.textContent : '';
        list.querySelectorAll('.ms-opt.single').forEach(function (opt) {
          opt.classList.toggle('active', opt.dataset.val === sel.value);
        });
      }
      function openPanel() {
        document.querySelectorAll('.ms.open').forEach(function (m) { if (m !== box) m.classList.remove('open'); });
        // 空间不足向上展开（以最近裁剪祖先为界）
        box.classList.remove('dropup');
        panel.style.display = 'block';
        var ph = panel.offsetHeight;
        panel.style.display = '';
        var tb = trigger.getBoundingClientRect().bottom, tt = trigger.getBoundingClientRect().top;
        var limB = innerHeight, limT = 0;
        for (var anc = box.parentElement; anc && anc !== document.documentElement; anc = anc.parentElement) {
          var cs = getComputedStyle(anc);
          if (cs.overflowY === 'visible' && !anc.classList.contains('modal-content')) continue;
          var r = anc.getBoundingClientRect();
          if (r.bottom < limB) limB = r.bottom;
          if (r.top > limT) limT = r.top;
        }
        var below = limB - tb, above = tt - limT;
        if (below < ph + 12 && above > ph + 12) box.classList.add('dropup');
        box.classList.add('open');
        var hostCard = box.closest('.card');
        if (hostCard) hostCard.classList.add('ms-open-card');   // 展开期间宿主卡片抬层
        syncCardLift();
      }
      function closePanel() { box.classList.remove('open'); syncCardLift(); }
      trigger.onclick = function () { box.classList.contains('open') ? closePanel() : openPanel(); };
      sel.addEventListener('change', sync);
      sel.after(box);
      sync();
    });
  }
  document.addEventListener('click', function (e) {
    document.querySelectorAll('.ms.open').forEach(function (m) {
      if (!m.contains(e.target)) m.classList.remove('open');
    });
    syncCardLift();
  }, true);   // 捕获阶段：弹窗内容层 stopPropagation 也能触发外点关闭
  enhanceSelects();

  // 会话信息：侧边栏用户名显示为当前登录账号（/api/session）
  if (window.LiteAPI && !LiteAPI.loginExpired()) {
    LiteAPI.call('/api/session').then(function (s) {
      if (!s || !s.username) return;
      var el = document.getElementById('sidebarUsername');
      if (el) el.textContent = s.username;
    });
  }

  // 登录问候：按上海时区弹出，点击任意区域关闭
  window.__showGreeting = function () {
    try {
      var lt = parseInt(localStorage.getItem('sf_lite_login_time') || '0', 10);
      if (!lt || Date.now() - lt > 60 * 1000) return;
      var hour = new Date(Date.now() + 8 * 3600 * 1000).getUTCHours();   // 上海固定 UTC+8 无夏令时：加 8 小时取 UTC 小时即为上海钟点
      var pool = hour >= 23 || hour < 5 ? [
          '夜深啦，主人，早点休息🌙',
          '夜深啦，主人，枕头都想你了，回来躺平～',
          '夜深啦，主人，被窝暖好了，快睡吧～',
          '夜深啦，主人，星月都睡了，你也睡吧🌙',
          '夜深啦，主人，别熬啦，明天见～'
        ]
        : hour >= 18 ? [
          '晚上好，主人，欢迎回来👏',
          '晚上好，主人，今天辛苦啦！',
          '晚上好，主人，别熬太晚哦！',
          '晚上好，主人，夜色真美，慢慢来🌙',
          '晚上好，主人，放松一下～'
        ]
        : hour >= 14 ? [
          '下午好，主人，欢迎回来👏',
          '下午好，主人，喝杯茶歇会儿☕',
          '下午好，主人，来杯咖啡提提神☕',
          '下午好，主人，伸个懒腰吧～',
          '下午好，主人，起来走一走～'
        ]
        : hour >= 11 ? [
          '中午好，主人，欢迎回来👏',
          '中午好，主人，记得吃午饭哦！',
          '中午好，主人，午休片刻更精神',
          '中午好，主人，今天午饭吃什么？',
          '中午好，主人，干饭时间到～'
        ]
        : [
          '早上好，主人，欢迎回来👏',
          '早上好，主人，新的一天加油！',
          '早上好，主人，今天也元气满满！',
          '早上好，主人，记得吃早餐哦～',
          '早上好，主人，好运已到账，请查收✨'
        ];
      var pick = pool[Math.floor(Math.random() * pool.length)];
      var m = document.createElement('div');
      m.className = 'st-check-modal show';
      m.innerHTML = '<div class="st-check-box" style="width:min(380px,92vw);padding:32px 28px;text-align:center;cursor:pointer">' +
        '<div style="font-size:1.25rem;font-weight:700">' + pick + '</div>' +
      '</div>';
      m.onclick = function () { m.remove(); };
      document.body.appendChild(m);
    } catch (e) {}
  };
  window.__showGreeting();

  // ============ 节点列表（双 dock，数据来自 /api/nodelist 按配置解析） ============
  var PIN_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 21s6-4.35 6-10a6 6 0 1 0-12 0c0 5.65 6 10 6 10z"/><circle cx="12" cy="11" r="2.5"/></svg>';
  var BOLT_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></svg>';
  // ns+idx 同给时挂单卡测速回调
  // showName=false：反代节点不展示备注名（节点列表 proxy 页）
  function nodeCardHtml(o, ns, idx, showName) {
    var c = /^[A-Za-z]{2}$/.test(o.region || '') ? o.region.toLowerCase() : '';
    var pingAttr = (ns && idx != null && o.ok !== false && o.ms == null)
      ? ' onclick="' + ns + 'PingOne(' + idx + ')"' : '';
    return '<div class="node-card"' + (o.tip ? ' title="' + escHtml(o.tip) + '"' : '') + (o.dataAddr ? ' data-addr="' + escHtml(o.dataAddr) + '"' : '') + '>' +
      (c ? '<img class="node-flag-img" src="https://flagcdn.com/w80/' + (c === 'uk' ? 'gb' : c) + '.png" width="44" height="32" alt="' + escHtml(o.region) + '" loading="lazy">' : '') +
      '<div class="node-info">' +
        '<div class="node-ip">' + escHtml(o.addr) + '</div>' +
        '<div class="node-meta">' +
          (o.region ? '<span class="meta-chip">' + PIN_SVG + '<span>' + escHtml(o.region) + '</span></span>' : '') +
          '<span class="meta-stack ' + (o.ipv6 ? 'ipv6' : 'ipv4') + '">' + (o.ipv6 ? 'IPv6' : 'IPv4') + '</span>' +
        '</div>' +
      '</div>' +
      (o.ok === false
        ? '<button class="node-test fail"><span class="ms-text">超时</span></button>'
        : o.ms != null
          ? '<button class="node-test ' + (o.ms < 150 ? 'ok' : o.ms < 300 ? 'mid' : 'warn') + '"><span class="ms-text">' + o.ms + 'ms</span></button>'
          : '<button class="node-test" title="测速"' + pingAttr + '>' + BOLT_SVG + '</button>') +
      '</div>';
  }
  // ============ 节点列表真实数据：/api/nodelist 按当前 Inbound/IPMode/ProxyIPMode 解析配置源 ============
  var NL_ITEMS = { speed: [], proxy: [], loaded: false, loading: false, failed: false };
  // 每页行数：按容器宽度实算每行列数 × 行数 = 每页卡片数（默认 2 行，可选 4/6 行）
  var NL_ROWS = [2, 4, 6];
  var NL_STATE = { tab: 'speed', page: { speed: 1, proxy: 1 }, rows: 2 };
  function nlCols() {
    // 度量当前可见网格，折叠时两网格均隐藏，回退到所在卡片的宽度
    var g = document.getElementById('nl-' + NL_STATE.tab);
    var w = 0;
    if (g && g.clientWidth > 0) {
      w = g.clientWidth - 36;                        // 减去 .node-grid 左右 padding 18×2
    } else if (g) {
      var card = g.closest('.card');
      w = (card ? card.clientWidth : 600) - 36;
    }
    return Math.max(1, Math.floor((w + 14) / (300 + 14)));  // 与 minmax(300px)/gap:14 同参
  }
  async function fillNodeList() {
    if (!window.LiteAPI || NL_ITEMS.loaded || NL_ITEMS.loading) { if (!NL_ITEMS.loading) nlRender(); return; }
    NL_ITEMS.loading = true;
    ['speed', 'proxy'].forEach(function (t) {
      var g = document.getElementById('nl-' + t);
      if (g && !g.childElementCount) g.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:var(--text-muted,#94a3b8);padding:30px 0;font-size:.85rem">正在按当前配置解析节点来源…</div>';
    });
    var d = await LiteAPI.getNodeList();
    NL_ITEMS.loading = false;
    if (!d) { NL_ITEMS.failed = true; nlRender(); return; }   // 失败态提示，下次进入视图自动重试
    NL_ITEMS.failed = false;
    NL_ITEMS.speed = (d.preferred || []).map(nlMapItem);
    NL_ITEMS.proxy = (d.proxy || []).map(nlMapItem);
    NL_ITEMS.loaded = true;
    NL_STATE.page.speed = 1; NL_STATE.page.proxy = 1;
    nlRender();
    // 首屏自动测速当前页（仅首次加载执行一次）
    if (!NL_ITEMS.autotested) {
      NL_ITEMS.autotested = true;
      window.__nlTestPage();
    }
  }
  // 统一渲染：两个列表（优选/反代）走同一套切片+分页逻辑，分页栏跟随当前 tab
  function nlRender() {
    var size = Math.max(1, nlCols() * NL_STATE.rows);   // 每页 = 每行列数 × 行数
    ['speed', 'proxy'].forEach(function (t) {
      var grid = document.getElementById('nl-' + t);
      if (!grid) return;
      var items = NL_ITEMS[t];
      var totalPages = Math.max(1, Math.ceil(items.length / size));
      var p = Math.min(NL_STATE.page[t], totalPages);
      NL_STATE.page[t] = p;
      grid.innerHTML = items.length
        ? items.slice((p - 1) * size, p * size).map(function (o, i) {
            return nodeCardHtml(o, '__nl', (p - 1) * size + i, t !== 'proxy');   // 反代页不显示备注名，idx 为全列表绝对下标
          }).join('')
        : '<div style="grid-column:1/-1;text-align:center;color:var(--text-muted,#94a3b8);padding:30px 0;font-size:.85rem">' +
          (NL_ITEMS.loaded ? '该来源未解析到节点，请检查「节点配置」的 IP 模式与来源'
            : NL_ITEMS.failed ? '加载失败，切换菜单后自动重试' : '加载中…') + '</div>';
    });
    var cEl = document.getElementById('nlCount');
    if (cEl) cEl.textContent = NL_ITEMS[NL_STATE.tab].length;
    var row = document.getElementById('nlPagerRow');
    if (!row) return;
    var tab = NL_STATE.tab;
    var totalPages = Math.max(1, Math.ceil(NL_ITEMS[tab].length / size));
    var p = NL_STATE.page[tab];
    // 与在线优选同规则：数据不超过两行卡片时分页栏整体隐藏
    if (!nlHasMultiRowData()) {
      row.innerHTML = '';
      var footEl = document.getElementById('nlFoot');
      if (footEl) footEl.hidden = true;
      return;
    }
    var footShow = document.getElementById('nlFoot');
    if (footShow) footShow.hidden = false;
    var chevL = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>';
    var chevR = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
    var html = '<button type="button" title="上一页"' + (p <= 1 ? ' disabled' : ' onclick="window.__nlGo(' + (p - 1) + ')"') + '>' + chevL + '</button>';
    pagerPages(p, totalPages).forEach(function (pg) {
      html += pg === '...'
        ? '<span class="page-ellipsis">…</span>'
        : '<button type="button"' + (pg === p ? ' class="active"' : ' onclick="window.__nlGo(' + pg + ')"') + '>' + pg + '</button>';
    });
    html += '<button type="button" title="下一页"' + (p >= totalPages ? ' disabled' : ' onclick="window.__nlGo(' + (p + 1) + ')"') + '>' + chevR + '</button>';
    html += '<span class="jump-box"><span class="jump-label">跳转</span><input id="nlJump" type="number" min="1" max="' + totalPages + '" placeholder="页码" value="' + p + '"><span class="jump-label">页</span></span>';
    // 每页行数下拉（复用 ms-panel 样式）
    html += '<div class="ms" id="ms-nlsize" style="min-width:96px">' +
      '<button type="button" class="ms-trigger ui-field" style="height:34px;" onclick="window.__nlSizeToggle(event)">' +
      '<span class="ms-value">' + size + ' 条/页</span>' +
      '<svg class="ms-caret" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>' +
      '<div class="ms-panel"><div class="ms-list">' +
      NL_ROWS.map(function (r) {
        var n = Math.max(1, nlCols() * r);
        return '<div class="ms-opt single' + (r === NL_STATE.rows ? ' active' : '') + '" onclick="window.__nlRows(' + r + ')"><span>' + n + ' 条/页</span></div>';
      }).join('') +
      '</div></div></div>';
    row.innerHTML = html;
    var inp = document.getElementById('nlJump');
    if (inp) inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { var v = parseInt(inp.value, 10); if (v >= 1 && v <= totalPages && v !== p) window.__nlGo(v); }
    });
  }
  window.__nlGo = function (p) {
    NL_STATE.page[NL_STATE.tab] = p;
    nlRender();
    window.__nlAutoTestSlice();
  };
  window.__nlSizeToggle = function (e) {
    e.stopPropagation();
    var ms = document.getElementById('ms-nlsize');
    if (ms) ms.classList.toggle('open');
  };
  window.__nlRows = function (r) {
    NL_STATE.rows = r;
    NL_STATE.page.speed = 1; NL_STATE.page.proxy = 1;
    nlRender();
  };
  // ---------- 节点列表：单卡测速 / 全部测速 / 复制 / 下载（探测与打点函数来自 LiteCore） ----------
  var NL_TESTING = false;
  // ipinfo.io 免费端点（CORS 全开）
  var IPINFO_LITE = 'https://api.ipinfo.io/lite/{ip}?token=2cb674df499388';
  // CF 网段 IP 的归属/ASN/注册地：非阻塞补全（第三方失败静默，不影响测速主流程）
  async function nlAttachInfo(o) {
    // 取裸 IP（ipinfo 不带端口）
    var raw = String(o.addr || '').trim();
    var m6 = raw.match(/^\[([0-9a-fA-F:]+)\]/);
    var host = m6 ? m6[1] : raw.split(':')[0];
    try {
      var res = await fetch(IPINFO_LITE.replace('{ip}', encodeURIComponent(host)), {
        signal: AbortSignal.timeout(6000),
        cache: 'no-store',
      });
      if (!res.ok) return;
      var d = await res.json();
      if (!d || !d.asn) return;
      if (d.country_code) o.region = d.country_code;
      if (d.country) o.org = o.org || d.country;
      var asn = String(d.asn || '').replace(/^AS/, '');
      o.asn = 'AS' + asn + (o.cfCidr ? ' · ' + o.cfCidr : '');
      o.tip = nlTipOf(o);
    } catch (e) {}
  }
  // 统一测速入口：按当前 tab 测单节点，随后补机房/注册地与 CF 归属
  async function nlRunTest(o, cfg) {
    if (NL_STATE.tab === 'speed') await stTestNode(o, cfg.port);
    else await stTestProxy(o);
    o.time = stTimeHM(new Date());
    o.tip = nlTipOf(o);
    // 优选补机房/注册地，反代 country 由 check API 自带
    if (NL_STATE.tab === 'speed' && !o.region) {
      var host = String(o.addr || '').replace(/^\[([0-9a-fA-F:]+)\]/, '$1').split(':')[0];
      var rg = await Core.stLookupRegion(host, cfg.port).catch(function () { return {}; });
      if (rg.region) o.region = rg.region;
      if (rg.colo) o.colo = rg.colo;
    }
    if (o.cf && o.cfCidr) await nlAttachInfo(o);   // CF 网段归属信息补全后再渲染，国旗/ASN 立刻可见
  }
  window.__nlTestAll = async function () {
    if (!window.LiteAPI || NL_TESTING) return;
    var tab = NL_STATE.tab;
    var list = NL_ITEMS[tab];
    if (!list.length) { showToast('当前列表为空', true); return; }
    NL_TESTING = true;
    var cEl = document.getElementById('nlCount');
    var cfg = stCfgRead();
    await stRunPool(list, tab === 'proxy' ? Math.min(cfg.threads, 5) : cfg.threads, function (o) {
      return nlRunTest(o, cfg);   // 统一测速 + 补全
    }, function (done, total) { if (cEl) cEl.textContent = done + '/' + total; });
    Core.regionCacheClear();   // 整体测速结束：清空机房地区缓存，防 localStorage 长期膨胀
    list.sort(function (a, b) {
      var av = a.ok ? a.ms : Infinity, bv = b.ok ? b.ms : Infinity;
      return av === bv ? 0 : av - bv;   // 可用在前按延时升序，超时沉底
    });
    NL_STATE.page[tab] = 1;
    nlRender();
    NL_TESTING = false;
    var okCount = list.filter(function (o) { return o.ok; }).length;
    showToast(okCount
      ? '测速完成：可用 ' + okCount + '/' + list.length + '，最快 ' + list[0].addr + ' (' + list[0].ms + 'ms)'
      : '测速完成：' + list.length + ' 个全部超时');
  };
  function nlCurPageItems() {
    var size = Math.max(1, nlCols() * NL_STATE.rows);
    var tab = NL_STATE.tab;
    var totalPages = Math.max(1, Math.ceil(NL_ITEMS[tab].length / size));
    var p = Math.min(NL_STATE.page[tab], totalPages);
    return NL_ITEMS[tab].slice((p - 1) * size, p * size);
  }
  window.__nlAutoTestSlice = async function () {
    if (!window.LiteAPI || NL_TESTING) return;
    var tab = NL_STATE.tab;
    var size = Math.max(1, nlCols() * NL_STATE.rows);
    var items = NL_ITEMS[tab];
    var p = Math.min(NL_STATE.page[tab], Math.max(1, Math.ceil(items.length / size)));
    var slice = items.slice((p - 1) * size, p * size);
    var list = slice.filter(function (o) { return o.ok !== false && o.ms == null; });
    if (!list.length) return;
    var cfg = stCfgRead();
    NL_TESTING = true;
    var cEl = document.getElementById('nlCount');
    await stRunPool(list, tab === 'proxy' ? Math.min(cfg.threads, 5) : cfg.threads, function (o) {
      return nlRunTest(o, cfg);   // 统一测速 + 补全
    }, function (done, total) { if (cEl) cEl.textContent = done + '/' + total; });
    NL_TESTING = false;
    nlRender();
  };
  // 只测当前页（不整池轰炸）
  window.__nlTestPage = async function () {
    if (!window.LiteAPI || NL_TESTING) return;
    var tab = NL_STATE.tab;
    var items = nlCurPageItems();
    if (!items.length) return;
    var cfg = stCfgRead();
    NL_TESTING = true;
    var cEl = document.getElementById('nlCount');
    await stRunPool(items, tab === 'proxy' ? Math.min(cfg.threads, 5) : cfg.threads, function (o) {
      return nlRunTest(o, cfg);   // 统一测速 + 补全
    }, function (done, total) { if (cEl) cEl.textContent = done + '/' + total; });
    NL_TESTING = false;
    nlRender();
  };
  window.__nlCopyPage = function () {
    var items = nlCurPageItems();
    if (!items.length) { showToast('当前页没有数据', true); return; }
    copyText(items.map(function (o) { return o.addr; }).join('\n'), '已复制当前页 ' + items.length + ' 个');
  };
  window.__nlDownloadPage = function () {
    var items = nlCurPageItems();
    if (!items.length) { showToast('当前页没有数据', true); return; }
    downloadText('senflare-lite-nodes-' + NL_STATE.tab + '-page' + NL_STATE.page[NL_STATE.tab] + '.txt',
      items.map(function (o) { return o.addr; }).join('\n'), '已下载当前页 ' + items.length + ' 个');
  };
  // 视口宽度变化 → 每行列数变化 → 重算每页条数并重渲染
  var nlResizeT;
  window.addEventListener('resize', function () {
    clearTimeout(nlResizeT);
    nlResizeT = setTimeout(function () {
      var v = document.getElementById('view-nodelist');
      if (v && v.style.display !== 'none') nlRender();
    }, 150);
  });
  function switchNodeListTab(name) {
    NL_STATE.tab = name;
    document.querySelectorAll('.src-btn[data-nl]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-nl') === name);
    });
    nlRender();       // 当前 tab 走同一套分页渲染
    nlApplyView();    // 可见性统一由状态驱动（tab + 折叠）
    var items = nlCurPageItems();
    if (items.some(function (o) { return o.ms == null; })) window.__nlTestPage();
  }
  // 可见性唯一入口：哪个网格显示、分页是否隐藏，全部由 NL_STATE.tab + 折叠态决定
  // 与在线优选同规则：数据超过两行卡片（2 × 当前行列数）才显示分页栏，与折叠逻辑叠加
  function nlHasMultiRowData() {
    return NL_ITEMS[NL_STATE.tab].length > nlCols() * 2;
  }
  function nlApplyView() {
    var foldedEl = document.getElementById('nlFoldBtn');
    var folded = !!(foldedEl && foldedEl.dataset.folded === '1');
    ['speed', 'proxy'].forEach(function (t) {
      var g = document.getElementById('nl-' + t);
      if (g) g.style.display = (!folded && t === NL_STATE.tab) ? 'grid' : 'none';
    });
    var pager = document.getElementById('nlFoot');
    if (pager) pager.hidden = folded || !nlHasMultiRowData();
  }
  // 折叠/展开节点列表（与反代节点页同语义：展开态显示向上箭头，收起后显示向下箭头）
  function toggleNodeListFold(btn) {
    if (!btn) return;
    var folded = btn.dataset.folded !== '1';      // 目标态：当前未折叠 → 即将折叠
    btn.dataset.folded = folded ? '1' : '';
    btn.innerHTML = folded ? FOLD_CHEVRON.down : FOLD_CHEVRON.up;
    nlApplyView();
  }

  // ============ 在线优选（真实测速：优选走 /cdn-cgi/trace 三连打点，反代走 check API 探测） ============
  // 探测/解析核心在 LiteCore（js/admin.js），本节只做卡片渲染、分页与交互
  var ST_TITLES = { speed: '优选节点', proxy: '优选反代' };
  var ST_DATA = stStoreRead();   // 测速结果本地持久化：刷新不丢，可随时重测再生

  // 按容器宽度实算每页卡片数
  var ST_ROWS = [2, 4, 6];
  var ST_STATE = { tab: 'speed', page: { speed: 1, proxy: 1 }, rows: 2 };
  function stCols() {
    // 度量当前可见网格，折叠时两网格均隐藏，回退到所在卡片的宽度
    var g = document.getElementById('st-' + ST_STATE.tab);
    var w = 0;
    if (g && g.clientWidth > 0) {
      w = g.clientWidth - 36;                        // 减去 .node-grid 左右 padding 18×2
    } else if (g) {
      var card = g.closest('.card');
      w = (card ? card.clientWidth : 600) - 36;
    }
    return Math.max(1, Math.floor((w + 14) / (300 + 14)));  // 与 minmax(300px)/gap:14 同参
  }
  function fillSpeedTest() {
    if (document.getElementById('st-speed') && document.getElementById('st-speed').childElementCount) return;
    stRender();
  }
  // 统一渲染：两个列表（优选/反代）走同一套切片+分页逻辑，分页栏跟随当前 tab
  function stRender() {
    var size = Math.max(1, stCols() * ST_STATE.rows);   // 每页 = 每行列数 × 行数
    ['speed', 'proxy'].forEach(function (t) {
      var grid = document.getElementById('st-' + t);
      if (!grid) return;
      var items = ST_DATA[t];
      var totalPages = Math.max(1, Math.ceil(items.length / size));
      var p = Math.min(ST_STATE.page[t], totalPages);
      ST_STATE.page[t] = p;
      grid.innerHTML = items.length
        ? items.slice((p - 1) * size, p * size).map(function (o) {
            // data-addr 始终用原始地址（测速打点/详情定位），展示地址补端口、未测卡提示可点详情
            return nodeCardHtml(Object.assign({}, o, { dataAddr: o.addr, addr: stDisplayAddr(o), tip: o.tip || '点击查看详情' }));
          }).join('')
        : '<div style="grid-column:1/-1;text-align:center;color:var(--text-muted,#94a3b8);padding:30px 0;font-size:.85rem">暂无数据 · 填入数据来源后点击「开始测速」</div>';
    });
    var c = document.getElementById('stCount');
    if (c) c.textContent = ST_DATA[ST_STATE.tab].length;
    var tt = document.getElementById('stTitleTxt');
    if (tt) tt.textContent = ST_TITLES[ST_STATE.tab];
    var row = document.getElementById('stPagerRow');
    if (!row) return;
    var tab = ST_STATE.tab;
    var totalPages = Math.max(1, Math.ceil(ST_DATA[tab].length / size));
    var p = ST_STATE.page[tab];
    // 数据不超过两行卡片时分页栏整体隐藏（单屏放得下，无需翻页/跳转/条数控件）
    if (!stHasMultiRowData()) {
      row.innerHTML = '';
      var footEl = document.getElementById('stFoot');
      if (footEl) footEl.hidden = true;
      return;
    }
    var footShow = document.getElementById('stFoot');
    if (footShow) footShow.hidden = false;
    var chevL = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>';
    var chevR = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
    var html = '<button type="button" title="上一页"' + (p <= 1 ? ' disabled' : ' onclick="window.__stGo(' + (p - 1) + ')"') + '>' + chevL + '</button>';
    pagerPages(p, totalPages).forEach(function (pg) {
      html += pg === '...'
        ? '<span class="page-ellipsis">…</span>'
        : '<button type="button"' + (pg === p ? ' class="active"' : ' onclick="window.__stGo(' + pg + ')"') + '>' + pg + '</button>';
    });
    html += '<button type="button" title="下一页"' + (p >= totalPages ? ' disabled' : ' onclick="window.__stGo(' + (p + 1) + ')"') + '>' + chevR + '</button>';
    html += '<span class="jump-box"><span class="jump-label">跳转</span><input id="stJump" type="number" min="1" max="' + totalPages + '" placeholder="页码" value="' + p + '"><span class="jump-label">页</span></span>';
    // 每页行数下拉（复用 ms-panel 样式）
    html += '<div class="ms" id="ms-stsize" style="min-width:96px">' +
      '<button type="button" class="ms-trigger ui-field" style="height:34px;" onclick="window.__stSizeToggle(event)">' +
      '<span class="ms-value">' + size + ' 条/页</span>' +
      '<svg class="ms-caret" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>' +
      '<div class="ms-panel"><div class="ms-list">' +
      ST_ROWS.map(function (r) {
        var n = Math.max(1, stCols() * r);
        return '<div class="ms-opt single' + (r === ST_STATE.rows ? ' active' : '') + '" onclick="window.__stRows(' + r + ')"><span>' + n + ' 条/页</span></div>';
      }).join('') +
      '</div></div></div>';
    row.innerHTML = html;
    var inp = document.getElementById('stJump');
    if (inp) inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { var v = parseInt(inp.value, 10); if (v >= 1 && v <= totalPages && v !== p) window.__stGo(v); }
    });
  }
  window.__stGo = function (p) {
    ST_STATE.page[ST_STATE.tab] = p;
    stRender();
    var size = Math.max(1, stCols() * ST_STATE.rows);
    var items = ST_DATA[ST_STATE.tab];
    var slice = items.slice((p - 1) * size, p * size);
    var list = slice.filter(function (o) { return o.ok !== false && o.ms == null; });
    if (!list.length) return;
    var tab = ST_STATE.tab;
    var cfg = stCfgRead();
    stRunning = true;
    stRunPool(list, tab === 'proxy' ? Math.min(cfg.threads, 5) : cfg.threads, async function (o) {
      if (tab === 'speed') await stTestNode(o, cfg.port);
      else await stTestProxy(o);
      o.time = stTimeHM(new Date());
      o.tip = stTipOf(o, tab);
      stPatchCard(o, tab);
    }, function (done, total) {
      var cEl = document.getElementById('stCount');
      if (cEl) cEl.textContent = done + '/' + total;
    }).then(function () {
      stStoreWrite(ST_DATA);
      stRunning = false;
      stRender();
    });
  };
  window.__stSizeToggle = function (e) {
    e.stopPropagation();
    var ms = document.getElementById('ms-stsize');
    if (ms) ms.classList.toggle('open');
  };
  window.__stRows = function (r) {
    ST_STATE.rows = r;
    ST_STATE.page.speed = 1; ST_STATE.page.proxy = 1;
    stRender();
  };
  // 数据来源模式切换（自定义 / 网段优选）：各模式内容分缓存，误切模式不丢已填内容
  var ST_SRC_CACHE = {};
  var stSrcMode = null;
  window.__stMode = function (v) {
    var ta = document.getElementById('stSourceEditor');
    if (!ta) return;
    var curTab = ST_STATE.tab;
    if (stSrcMode !== null) ST_SRC_CACHE[curTab + ':' + stSrcMode] = ta.value;
    stSrcMode = v;
    var key = curTab + ':' + v;
    var cached = ST_SRC_CACHE[key];
    var isProxy = curTab === 'proxy';
    if (cached != null && cached !== '') ta.value = cached;
    else if (v === 'SUBNET') {
      ta.value = isProxy
        ? ''
        : '104.16.*.0/24 # 32-47 # Three\n104.17.*.0/24 # 25,30,110 # Mobile\n172.64.*.0/24 # 32-38,144-159 # Telecom\n162.159.*.0/24 # 1-27,48-62 # Telecom';
    } else ta.value = '';
    if (v === 'SUBNET') {
      ta.placeholder = isProxy
        ? '每行一个直链 URL 或网段表达式'
        : '每行一个网段表达式：a.b.*.0/24 # 第三段范围 # 运营商（范围与运营商可省略）';
    } else ta.placeholder = '每行一个 IP/域名，或填入直链 URL';
    __stSyncSubnetWrap();
  };
  // 折叠/展开数据来源编辑器
  window.__stEditorToggle = function () {
    var w = document.getElementById('stEditorWrap');
    if (w) w.style.display = w.style.display === 'none' ? '' : 'none';
  };
  // 测速设置弹窗：打开（读取本地设置回填）/ 关闭 / 保存（读写走 LiteCore.stCfg*）
  function __stSyncSubnetWrap() {
    var modeEl = document.getElementById('stSourceMode');
    var wrap = document.getElementById('stCfgSubnetWrap');
    if (wrap) wrap.style.display = (modeEl && modeEl.value === 'SUBNET') ? 'block' : 'none';
  }
  window.__stCfgOpen = function () {
    var m = document.getElementById('stCfgModal');
    if (!m) return;
    var c = stCfgRead();
    document.getElementById('stCfgPort').value = c.port;
    document.getElementById('stCfgThreads').value = c.threads;
    document.getElementById('stCfgRandom').value = c.random;
    document.getElementById('stCfgMax').value = c.max;
    document.getElementById('stCfgSave').value = c.save;
    __stSyncSubnetWrap();
    m.classList.add('show');
  };
  window.__stCfgClose = function () {
    var m = document.getElementById('stCfgModal');
    if (m) m.classList.remove('show');
  };
  window.__stCfgSave = function () {
    var cfg = {
      port: document.getElementById('stCfgPort').value,
      threads: Math.max(1, parseInt(document.getElementById('stCfgThreads').value, 10) || 5),
      random: Math.max(1, parseInt(document.getElementById('stCfgRandom').value, 10) || 3),
      max: Math.max(1, parseInt(document.getElementById('stCfgMax').value, 10) || 20),
      save: Math.max(1, parseInt(document.getElementById('stCfgSave').value, 10) || 10)
    };
    Core.stCfgWrite(cfg);
    showToast('测速设置已保存');
    __stCfgClose();
  };
  // 测速中逐卡实时打点（dataset 比对定位，不拼 CSS 选择器防注入）
  function stPatchCard(o, tab) {
    document.querySelectorAll('#st-' + tab + ' .node-card[data-addr]').forEach(function (card) {
      if (card.getAttribute('data-addr') !== o.addr) return;
      card.title = stTipOf(o, tab);
      var ipEl = card.querySelector('.node-ip');
      if (ipEl) ipEl.textContent = stDisplayAddr(o);   // 测出实际端口后同步展示地址
      var btn = card.querySelector('.node-test');
      if (!btn) return;
      if (o.ok === false) {
        btn.className = 'node-test fail';
        btn.innerHTML = '<span class="ms-text">超时</span>';
      } else {
        var cls = o.ms < 150 ? 'ok' : o.ms < 300 ? 'mid' : 'warn';
        btn.className = 'node-test ' + cls;
        btn.innerHTML = '<span class="ms-text">' + o.ms + 'ms</span>';
      }
    });
  }

  // ---------- 节点详情弹窗（取本地结果，两视图共用）
  var stDetailAddr = '';
  function stRowsHtml(rows) {
    return rows.map(function (r) {
      return '<div class="st-check-row"><span class="st-check-k">' + escHtml(r[0]) + '</span><span class="st-check-v">' + escHtml(r[1]) + '</span></div>';
    }).join('');
  }
  // 共享渲染：在线优选（ST_DATA）与节点列表（NL_ITEMS）都喂这个函数
  function openNodeDetail(o, tab, addr) {
    stDetailAddr = addr;
    var sp = stSplitAddr(addr);
    // 不展示延迟/测速时间等测速过程字段——卡片上的胶囊已是权威结果，弹窗只看节点属性
    var rows = [
      ['IP 地址', sp.ip],
      ['端口', o.testPort || sp.port],
      ['网络栈', o.ipv6 ? 'IPv6' : 'IPv4'],
      ['类型', stKindLabel(o, tab)],
    ];
    if (o.colo) rows.push(['CF 机房', o.colo]);
    if (o.cfCidr) rows.push(['CF 网段', o.cfCidr]);
    if (o.region) rows.push(['注册地', String(o.region).toUpperCase()]);   // 第三方 IP 情报返回的是注册归属，非落地机房
    if (o.city) rows.push(['城市', o.city]);
    if (o.org) rows.push(['运营组织', o.org]);
    if (o.asn) rows.push(['ASN', o.asn]);
    if (o.vantage) rows.push(['探测机房', o.vantage]);
    if (o.remotePort) rows.push(['远端端口', o.remotePort]);
    if (o.name) rows.push(['备注', o.name]);
    document.getElementById('stCheckBody').innerHTML = stRowsHtml(rows);
    document.getElementById('stCheckModal').classList.add('show');
  }
  window.__stDetailOpen = function (addr) {
    var o = null;
    (ST_DATA[ST_STATE.tab] || []).forEach(function (it) { if (it.addr === addr) o = it; });
    if (o) openNodeDetail(o, ST_STATE.tab, addr);
  };
  window.__nlDetailOpen = function (addr) {
    var o = null;
    (NL_ITEMS[NL_STATE.tab] || []).forEach(function (it) { if (it.addr === addr) o = it; });
    if (o) openNodeDetail(o, NL_STATE.tab, addr);
  };
  window.__stDetailClose = function () {
    var m = document.getElementById('stCheckModal');
    if (m) m.classList.remove('show');
  };
  window.__stDetailCopy = function () {
    if (!stDetailAddr) { showToast('暂无可复制节点', true); return; }
    copyText(stDetailAddr, '已复制当前节点');
  };
  // 卡片点击委托 → 详情，测速按钮放行
  ['speed', 'proxy'].forEach(function (t) {
    var g = document.getElementById('st-' + t);
    if (!g || g.dataset.detailBound) return;
    g.dataset.detailBound = '1';
    g.addEventListener('click', function (e) {
      if (e.target.closest('.node-test')) return;
      var card = e.target.closest('.node-card[data-addr]');
      if (card) window.__stDetailOpen(card.getAttribute('data-addr'));
    });
  });
  // 节点列表同款委托：卡片点击 → 详情（复用同一弹窗）
  ['speed', 'proxy'].forEach(function (t) {
    var g = document.getElementById('nl-' + t);
    if (!g || g.dataset.nlDetailBound) return;
    g.dataset.nlDetailBound = '1';
    g.addEventListener('click', function (e) {
      if (e.target.closest('.node-test')) return;
      var card = e.target.closest('.node-card[data-addr]');
      if (card) window.__nlDetailOpen(card.getAttribute('data-addr'));
    });
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') window.__stDetailClose(); });

  // ---------- 前 N 个有效地址写入在线优选并切 LOCAL
  // 重组 host:port，防自带端口拼出双端口
  // 只写 IP 数据，不切模式：模式（LOCAL 等）由用户在「节点配置」自行选择
  function stApplyToConfig(tab, validList, saveN) {
    var ta = document.querySelector('[data-cfg="' + (tab === 'speed' ? 'LocalIP' : 'LocalProxyIP') + '"]');
    if (!ta) return;
    var lines = [];
    for (var i = 0; i < validList.length && lines.length < saveN; i++) {
      var p = stParseAddr(validList[i].addr);
      if (!p) continue;
      var port = validList[i].remotePort || validList[i].testPort || p.port;
      lines.push(p.type === 'ipv6' ? '[' + p.host + ']:' + port : p.host + ':' + port);
    }
    if (!lines.length) return;
    ta.value = lines.join('\n');
    cfgDraftSave(ta);
    // 只写 LocalIP/LocalProxyIP，模式由用户自选
    if (!window.LiteAPI) return;
    var payload = {};
    payload[tab === 'speed' ? 'LocalIP' : 'LocalProxyIP'] = lines.join('\n');
    LiteAPI.saveConfig(payload).then(function (r) {
      if (r) {
        // 已落库的键从本地草稿中对账移除，否则未保存守卫会把这次应用误判为待保存修改
        var d = cfgDraftRead();
        delete d[ta.dataset.cfg];
        Core.cfgDraftWrite(d);
        CFG_SERVER = null;
        // 成功不另发 toast：调用方「已写入「节点配置」在线优选」已说明结果，避免连发两条
      }
      else showToast('服务器同步失败', true);
    });
  }

  // ---------- 复制 / 下载当前页 ----------
  function stCurPageItems() {
    var size = Math.max(1, stCols() * ST_STATE.rows);
    var tab = ST_STATE.tab;
    var totalPages = Math.max(1, Math.ceil(ST_DATA[tab].length / size));
    var p = Math.min(ST_STATE.page[tab], totalPages);
    return ST_DATA[tab].slice((p - 1) * size, p * size);
  }
  window.__stCopyPage = function () {
    var items = stCurPageItems();
    if (!items.length) { showToast('当前页没有数据', true); return; }
    copyText(items.map(function (o) { return o.addr; }).join('\n'), '已复制当前页 ' + items.length + ' 个');
  };
  window.__stDownloadPage = function () {
    var items = stCurPageItems();
    if (!items.length) { showToast('当前页没有数据', true); return; }
    downloadText('senflare-lite-' + ST_STATE.tab + '-page' + ST_STATE.page[ST_STATE.tab] + '.txt',
      items.map(function (o) { return o.addr; }).join('\n'), '已下载当前页 ' + items.length + ' 个');
  };

  // ---------- 开始测速主流程：解析来源 → 并发探测 → 实时打点 → 排序持久化 → 应用到配置 ----------
  var stRunning = false;
  window.__stTest = async function () {
    if (stRunning) return;
    var btn = document.getElementById('stTestBtn');
    var ta = document.getElementById('stSourceEditor');
    var modeEl = document.getElementById('stSourceMode');
    if (!btn || !ta || !modeEl) return;
    var content = ta.value.trim();
    if (!content) { showToast('请先填入数据来源', true); return; }
    var cfg = stCfgRead();
    var tab = ST_STATE.tab;
    stRunning = true;
    btn.disabled = true;
    btn.textContent = '解析来源...';
    var list = await stBuildList(modeEl.value, content, cfg.random, cfg.max);
    if (!list.length) {
      showToast('未找到有效的 IP', true);
      btn.textContent = '开始测速';
      btn.disabled = false;
      stRunning = false;
      return;
    }
    ST_DATA[tab] = list;
    ST_STATE.page[tab] = 1;
    stRender();
    showToast('开始测速 ' + list.length + ' 个' + (tab === 'speed' ? '优选节点' : '反代节点') + '...');
    var timeStr = stTimeHM(new Date());
    await stRunPool(list, tab === 'proxy' ? Math.min(cfg.threads, 5) : cfg.threads, async function (o) {
      if (tab === 'speed') await stTestNode(o, cfg.port);
      else await stTestProxy(o);
      o.time = timeStr;
      o.tip = stTipOf(o, tab);
      stPatchCard(o, tab);
    }, function (done, total) {
      btn.textContent = '测速中 ' + done + '/' + total;
    });
    // 全部完成后并发补 CF 网段归属
    await Promise.all(list.filter(function (o) { return o.cf && o.cfCidr; }).map(function (o) { return nlAttachInfo(o); }));
    Core.regionCacheClear();   // 整体测速结束：清空机房地区缓存，防 localStorage 长期膨胀（同批内已靠缓存去重）
    // 排序：可用在前按延时升序，超时沉底（两者相等或同为超时保持原序）
    list.sort(function (a, b) {
      var av = a.ok ? a.ms : Infinity;
      var bv = b.ok ? b.ms : Infinity;
      if (av === bv) return 0;
      return av - bv;
    });
    ST_DATA[tab] = list;
    ST_STATE.page[tab] = 1;
    stStoreWrite(ST_DATA);
    stRender();
    btn.textContent = '开始测速';
    btn.disabled = false;
    stRunning = false;
    var valid = list.filter(function (o) { return o.ok; });
    if (!valid.length) { showToast('测速完成，未发现可用地址', true); return; }
    stApplyToConfig(tab, valid, cfg.save);
    showToast('✅ 可用 ' + valid.length + '/' + list.length + '，最快 ' + valid[0].addr + ' (' + valid[0].ms + 'ms)，已写入「节点配置」在线优选');
  };
  // 数据来源下拉宽度自适应
  var __stFitSelect = function () {
    var sel = document.getElementById('stSourceMode');
    if (!sel) return;
    var probe = document.createElement('span');
    probe.style.cssText = 'position:absolute;left:-9999px;top:0;white-space:nowrap;';
    probe.style.font = getComputedStyle(sel).font;
    probe.textContent = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : '';
    document.body.appendChild(probe);
    sel.style.width = (probe.offsetWidth + 34) + 'px';   // 余量：内边距 + 原生箭头
    probe.remove();
  };
  (function () {
    var s = document.getElementById('stSourceMode');
    if (!s) return;
    __stFitSelect();
    s.addEventListener('change', __stFitSelect);
  })();
  // 视口宽度变化 → 每行列数变化 → 重算每页条数并重渲染（仅在在线优选可见时）
  var stResizeT;
  window.addEventListener('resize', function () {
    clearTimeout(stResizeT);
    stResizeT = setTimeout(function () {
      var v = document.querySelector('.nodes-subview[data-sub="speedtest"]');
      if (v && v.style.display !== 'none') stRender();
    }, 150);
  });
  function switchSpeedTab(name) {
    // 切 tab 保留各 tab 编辑框内容
    if (ST_STATE.tab !== name && stSrcMode !== null) {
      var ta0 = document.getElementById('stSourceEditor');
      if (ta0) ST_SRC_CACHE[ST_STATE.tab + ':' + stSrcMode] = ta0.value;
    }
    ST_STATE.tab = name;
    document.querySelectorAll('.src-btn[data-st]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-st') === name);
    });
    // 测速源模式下拉保持中性文案（不绑定特定服务商）
    var opt = document.querySelector('#stSourceMode option[value="SUBNET"]');
    if (opt) {
      opt.textContent = '网段优选';
      // 同步自建 ms 下拉的展示文字（若已增强）
      var sel = document.getElementById('stSourceMode');
      if (sel && sel.nextElementSibling && sel.nextElementSibling.classList.contains('ms')) {
        var msVal = sel.nextElementSibling.querySelector('.ms-value');
        if (msVal && sel.value === 'SUBNET') msVal.textContent = opt.textContent;
        sel.nextElementSibling.querySelectorAll('.ms-opt').forEach(function (o) {
          if (o.dataset.val === 'SUBNET') o.textContent = opt.textContent;
        });
      }
    }
    // 同步编辑框到新 tab 的缓存/默认值（仅当当前模式为 SUBNET 时需要区分占位符）
    if (stSrcMode !== null) {
      var ta1 = document.getElementById('stSourceEditor');
      if (ta1) {
        var k = name + ':' + stSrcMode;
        var cached = ST_SRC_CACHE[k];
        if (cached != null && cached !== '') ta1.value = cached;
        else if (stSrcMode === 'SUBNET') {
          var isProxy = name === 'proxy';
          ta1.value = isProxy
            ? ''
            : '104.16.*.0/24 # 32-47 # Three\n104.17.*.0/24 # 25,30,110 # Mobile\n172.64.*.0/24 # 32-38,144-159 # Telecom\n162.159.*.0/24 # 1-27,48-62 # Telecom';
          ta1.placeholder = isProxy
            ? '每行一个直链 URL 或网段表达式'
            : '每行一个网段表达式：a.b.*.0/24 # 第三段范围 # 运营商（范围与运营商可省略）';
        }
      }
    }
    stRender();       // 当前 tab 走同一套分页渲染
    stApplyView();    // 可见性统一由状态驱动（tab + 折叠）
  }
  // 可见性唯一入口：哪个网格显示、分页是否隐藏，全部由 ST_STATE.tab + 折叠态决定
  // 数据超过两行卡片（2 × 当前行列数）才需要分页栏，与折叠逻辑叠加判断
  function stHasMultiRowData() {
    return ST_DATA[ST_STATE.tab].length > stCols() * 2;
  }
  function stApplyView() {
    var foldedEl = document.getElementById('stFoldBtn');
    var folded = !!(foldedEl && foldedEl.dataset.folded === '1');
    ['speed', 'proxy'].forEach(function (t) {
      var g = document.getElementById('st-' + t);
      if (g) g.style.display = (!folded && t === ST_STATE.tab) ? 'grid' : 'none';
    });
    var pager = document.getElementById('stFoot');
    if (pager) pager.hidden = folded || !stHasMultiRowData();
  }
  // 折叠/展开结果列表（与节点列表折叠按钮同语义：目标态驱动，展开态显示向上箭头）
  function toggleStFold(btn) {
    if (!btn) return;
    var folded = btn.dataset.folded !== '1';      // 目标态：当前未折叠 → 即将折叠
    btn.dataset.folded = folded ? '1' : '';
    btn.innerHTML = folded ? FOLD_CHEVRON.down : FOLD_CHEVRON.up;
    stApplyView();
  }

  // ============ 后端配置（真实数据：/api/cfaccounts CRUD + /api/usage GraphQL 用量） ============
  var CF_ACCOUNTS = [], CF_ACTIVE_ID = null, CF_NO_D1 = false;
  var CF_LOADED = false, CF_LOADING = false;
  var CF_USAGE = {};                       // id → {used, workers, pages} 会话内缓存
  var CF_VERSIONS = {};                    // id → 子后端版本号会话内缓存（主后端代查）
  function cfById(id) { return CF_ACCOUNTS.find(function (a) { return a.id === id; }) || null; }
  // 卡片内图标（feather 线性风格）
  var CF_ICON_BOLT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></svg>';
  var CF_ICON_FILE = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>';
  var CF_ICON_SYNC = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>';
  var CF_ICON_EDIT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>';
  var CF_ICON_DEPLOY = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>';
  var CF_ICON_TRASH = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>';
  var CF_ICON_POWER = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>';

  async function ensureCfLoaded(force) {
    if (!window.LiteAPI || CF_LOADING) return;
    if (CF_LOADED && !force) return;
    CF_LOADING = true;
    var d = await LiteAPI.cfGet();
    CF_LOADING = false;
    if (!d) {
      // 加载失败：提示画进账号网格区域（toast 3 秒即逝，网格留空会让用户以为页面坏了）
      var grid = document.getElementById('cfAccountsGrid');
      if (grid) grid.innerHTML = '<div style="grid-column:1/-1;display:flex;align-items:center;justify-content:center;padding:56px 20px;color:var(--text-muted,#94a3b8);font-size:.88rem">Cloudflare 账号加载失败，请稍后重试</div>';
      showToast('Cloudflare 账号加载失败', true);
      return;
    }
    CF_ACCOUNTS = d.accounts || [];
    CF_ACTIVE_ID = d.activeId || (CF_ACCOUNTS[0] ? CF_ACCOUNTS[0].id : null);
    CF_NO_D1 = !!d.noD1;
    CF_LOADED = true;
    cfRender();
    // 静默拉取全量账号今日用量与子后端版本
    cfRefreshUsageAll(true);
    cfRefreshVersions();
  }
  // 直连接口取子后端版本，失败不占位
  function cfRefreshVersions() {
    CF_ACCOUNTS.forEach(function (a) {
      if (a.status === 'disabled') return;
      var ds = Array.isArray(a.syncDomains) ? a.syncDomains : [];
      var d = String(ds[0] || '').trim().replace(/\/+$/, '');
      if (!d) return;
      var ctrl = new AbortController();
      var timer = setTimeout(function () { ctrl.abort(); }, 8000);
      fetch((/^https?:\/\//i.test(d) ? d : 'https://' + d) + '/api/version', { signal: ctrl.signal })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) {
          clearTimeout(timer);
          if (j && typeof j.version === 'string') { CF_VERSIONS[a.id] = j.version; cfRender(); }
        })
        .catch(function (e) { clearTimeout(timer); console.warn('子后端版本获取失败: ' + d, e); });   // 不可达 / CORS 拦截 / 超时：不显示版本号
    });
  }
  // 查单账号今日用量，成功写缓存重绘
  async function cfRefreshUsage(a, silent) {
    if (!window.LiteAPI || !a) return null;
    var q = a.id ? { id: a.id } : (a.authType === 'globalKey'
      ? { Email: a.email, GlobalAPIKey: a.globalApiKey }
      : { APIToken: a.apiToken });
    if (!a.id && a.accountId) q.AccountID = a.accountId;
    var u = await LiteAPI.getUsage(q);
    if (u && u.success) {
      CF_USAGE[a.id] = { used: u.total, workers: u.workers, pages: u.pages };
      if (!silent) showToast('用量已刷新');
      cfRender();
      return CF_USAGE[a.id];
    }
    var failMsg = u && u.error ? u.error : '';   // 赋值须在 silent 判断外：静默刷新失败也要构造文案变量，否则下方崩溃
    if (!silent) showToast(failMsg.indexOf('凭证已失效') !== -1 ? '用量查询失败，' + failMsg : '用量查询失败：' + (failMsg || '未知错误'), true);
    return null;
  }
  window.__cfRefresh = function (id) {
    var a = cfById(id);
    if (a) cfRefreshUsage(a, false);
  };
  // 看板总览：全账号用量聚合
  var CF_USAGE_AGG = null;
  async function cfRefreshUsageAll(silent) {
    if (!window.LiteAPI || !CF_ACCOUNTS.length) return null;
    var active = CF_ACCOUNTS.filter(function (a) { return a.status !== 'disabled'; });   // 禁用账号不计入聚合、不发用量查询
    var totalQuota = active.reduce(function (t, a) { return t + (Number(a.quota) > 0 ? Number(a.quota) : 100000); }, 0);
    var usages = await Promise.all(active.map(function (a) { return cfRefreshUsage(a, true); }));   // 并行查询：看板刷新 ≈ 最慢单账号而非逐账号累加
    var pool = { used: 0, workers: 0, pages: 0 };
    for (var i = 0; i < usages.length; i++) {
      var u = usages[i];
      if (u) { pool.used += u.used; pool.workers += u.workers; pool.pages += u.pages; }   // 存入时已是绝对请求数，直接累加
    }
    if (totalQuota <= 0) return null;
    pool.used = Math.round(pool.used);
    pool.workers = Math.round(pool.workers);
    pool.pages = Math.round(pool.pages);
    CF_USAGE_AGG = pool;
    if (!silent) showToast('用量已刷新');
    cfRender();
    return pool;
  }
  // 整表持久化（新增/编辑全量覆盖）
  async function cfPersistAll() {
    if (!window.LiteAPI) return false;
    var r = await LiteAPI.cfPost({ accounts: CF_ACCOUNTS, activeId: CF_ACTIVE_ID });
    if (r && r.success) { cfRender(); return true; }   // 成功提示由调用方给出（保存/禁用语义不同）
    return false;
  }
  // 手动推送配置到各账号同步域名
  window.__nodesSync = async function () {
    var r = await LiteAPI.call('/api/nodes-sync', { method: 'POST' });
    if (!r) return;
    var vers = r.versions ? Object.keys(r.versions).map(function (d) { return d + '=' + r.versions[d]; }).join('、') : '';
    // per-Snippet 明细：后端返回 pullBased [{id,name,domain}] + snippets [{id,name,status,domain}]
    // Snippets 为拉取模式无 ok/fail，用 pullBased 明细展示每个 Snippet 的归属域名，避免只显示第一个
    var snipDetail = '';
    if (Array.isArray(r.pullBased) && r.pullBased.length) {
      snipDetail = '；Snippets 拉取：' + r.pullBased.map(function (s) { return (s.name || s.id) + '·' + (s.domain || '').replace(/^https?:\/\//, ''); }).join('、');
    }
    showToast(r.message + (vers ? '，版本 ' + vers : '') + (r.fail && r.fail.length ? '，失败：' + r.fail.join('、') : '') + snipDetail);
  };
  window.__cfAddOpen = function () {
    if (CF_NO_D1) { showToast('未绑定 D1 数据库，无法保存 Cloudflare 账号', true); return; }
    cfModal('添加 Cloudflare 账号', null, async function (obj) {
      obj.id = 'cf-' + Date.now();
      obj.status = 'normal';
      obj.createdAt = new Date().toISOString().slice(0, 10);
      var activeWasEmpty = !CF_ACTIVE_ID;
      if (activeWasEmpty) CF_ACTIVE_ID = obj.id;
      CF_ACCOUNTS.push(obj);
      // 凭据校验失败整体拒绝，回滚本地新增
      if (!await cfPersistAll()) {
        CF_ACCOUNTS.pop();
        if (activeWasEmpty) CF_ACTIVE_ID = null;
        return false;
      }
      return obj.id;   // 成功返回账号 id，供保存后按需打开编辑弹窗
    });
  };
  window.__cfEditOpen = function (id) {
    var a = cfById(id);
    if (!a) return;
    cfModal('编辑账号', a, async function (obj) {
      var backup = Object.assign({}, a);
      Object.assign(a, obj);
      // 凭据有改动时后端先校验，失败回滚本地修改（错误详情已由 LiteAPI 统一 toast）
      if (!await cfPersistAll()) {
        Object.assign(a, backup);
        cfRender();
        return false;
      }
      return a.id;   // 成功返回账号 id，供保存后按需重新打开编辑弹窗
    });
  };
  window.__cfDel = function (id) {
    window.__showConfirm(
      '确定删除该 Cloudflare 账号？将按部署记录删除其 Worker / Pages / D1 及绑定的生产域，未在面板绑定的手动部署不受影响，不可恢复。',
      async function () {
        var r = await LiteAPI.cfPost({ action: 'delete', id: id });
        if (r && r.success) {
          showToast('账号已删除');
          await ensureCfLoaded(true);
        }
      },
      '删除账号',
      { okText: '删除', cancelText: '取消', danger: true }
    );
  };
  // 启用/禁用单账号：弹窗确认后持久化，禁用后其域名退出订阅节点生成与配置推送，失败还原重绘
  function cfToggleAccount(id, on) {
    var a = cfById(id);
    if (!a) return;
    window.__showConfirm(
      on ? '启用后该账号将重新参与订阅节点生成与配置推送，是否继续？' : '禁用后该账号的域名将退出订阅节点生成与配置推送，是否继续？',
      async function () {
        var old = a.status;
        a.status = on ? 'normal' : 'disabled';
        var ok = await cfPersistAll();
        if (!ok) { a.status = old; cfRender(); showToast('状态保存失败', true); }
        else showToast(on ? '账号已启用' : '账号已禁用');
      },
      on ? '启用账号' : '禁用账号',
      { okText: on ? '启用' : '禁用', cancelText: '取消', danger: !on }
    );
  }
  // 账号新增/编辑弹窗（动态构建，样式复用主题弹窗 .modal）
  function cfModal(title, acc, onOk) {
    var old = document.getElementById('cfAccModal');
    if (old) old.remove();
    var isEdit = !!acc;
    var modal = document.createElement('div');
    modal.className = 'modal show';
    modal.id = 'cfAccModal';
    modal.onclick = function (e) { if (e.target === modal) modal.remove(); };
    var field = function (id, label, type, val, ph) {
      return '<div class="form-group"><label>' + label + '</label>' +
        '<input type="' + (type || 'text') + '" class="form-control" id="' + id + '" value="' + escHtml(val == null ? '' : val) + '" placeholder="' + escHtml(ph || '') + '"></div>';
    };
    modal.innerHTML = '<div class="modal-content" style="max-width:480px" onclick="event.stopPropagation()">' +
      '<div class="modal-header"><h3>' + title + '</h3><button class="modal-close" onclick="document.getElementById(\'cfAccModal\').remove()">×</button></div>' +
      '<div class="modal-body">' +
        field('cfName', '名称', 'text', acc && acc.name, '主后端') +
        field('cfEmail', '邮箱', 'text', acc && acc.email, 'you@example.com') +
        '<div class="form-group"><label>认证方式</label><select class="form-control" id="cfAuthType">' +
          '<option value="token">Token 模式</option><option value="globalKey">Global Key 模式</option></select></div>' +
        field('cfAccountId', 'Account ID（ 可选，留空自动查询 ）', 'text', acc && acc.accountId) +
        '<div class="form-group"><label>API Token</label>' +
        '<input type="text" class="form-control" id="cfApiToken" autocomplete="off" value="' + escHtml(acc && acc.apiToken || '') + '" placeholder="sk_xxx 或粘贴新 Token 覆盖"></div>' +
        '<div class="form-group"><label>Global API Key</label>' +
        '<input type="password" class="form-control" id="cfGlobalKey" autocomplete="new-password" value="' + escHtml(acc && acc.globalApiKey || '') + '" placeholder="粘贴 Global API Key"></div>' +
        field('cfQuota', '每日请求配额', 'number', (acc && acc.quota) != null ? acc.quota : 100000) +
        '<div class="form-group"><label>部署方式<small class="hint" style="display:inline;margin-left:6px">决定配置同步与订阅生成行为</small></label><select class="form-control" id="cfDeployType">' +
          '<option value="worker">Worker 部署（D1 推送同步，支持 WS/XHTTP）</option><option value="snippet">Snippets 部署（自动拉取，节点不带 early-data）</option></select></div>' +
        '<div class="form-group"><label>子后端协议<small class="hint" style="display:inline;margin-left:6px">按账号覆盖全局协议设置</small></label><select class="form-control" id="cfProtocol">' +
          '<option value="">跟随全局</option><option value="WS">WebSocket</option><option value="XHTTP">XHTTP</option></select></div>' +
        '<div class="form-group" id="cfSyncDomainsGroup"><label id="cfSyncDomainsLabel">数据同步域名<small class="hint" style="display:inline;margin-left:6px">每行一个「必填：面板部署自动填充」</small></label>' +
        '<textarea class="form-control" id="cfSyncDomains" rows="2" placeholder="sync.example.com">' + escHtml((acc && Array.isArray(acc.syncDomains) ? acc.syncDomains : []).join('\n')) + '</textarea>' +
        '<span class="hint" id="cfSyncDomainsHint1">「同步配置」节点配置修改后会自动把配置推送至该域名绑定的子后端</span>' +
        '<span class="hint" id="cfSyncDomainsHint2">「订阅生成域名」留空时，订阅节点由这些域名生成</span></div>' +
        '<div class="form-group" id="cfDomainsGroup"><label id="cfDomainsLabel">订阅生成域名<small class="hint" style="display:inline;margin-left:6px">每行一个「选填」</small></label>' +
        '<textarea class="form-control" id="cfDomains" rows="2" placeholder="node.example.com">' + escHtml((acc && Array.isArray(acc.domains) ? acc.domains : []).join('\n')) + '</textarea>' +
        '<span class="hint" id="cfDomainsHint1">订阅节点 Host / SNI 由此生成，留空则使用数据同步域名生成订阅</span>' +
        '<span class="hint" id="cfDomainsHint2">订阅按子后端排列及子域行数顺序进行轮询填充，第 1 个 / 行权重最大</span></div>' +
      '</div>' +
      '<div class="modal-footer"><button class="btn btn-outline" onclick="document.getElementById(\'cfAccModal\').remove()">取消</button>' +
      '<button class="btn btn-primary" id="cfAccOk">' + (isEdit ? '保存' : '添加') + '</button></div></div>';
    document.body.appendChild(modal);
    if (isEdit) {
      document.getElementById('cfAuthType').value = acc.authType === 'globalKey' ? 'globalKey' : 'token';
      document.getElementById('cfDeployType').value = acc.deployType === 'snippet' ? 'snippet' : 'worker';
      document.getElementById('cfProtocol').value = (acc.protocol === 'WS' || acc.protocol === 'XHTTP') ? acc.protocol : '';
    }
    // 认证方式联动：Token 显 ID + Token，Global Key 只显 Key，
    // ms 下拉选项点击会派发冒泡 change，监听原生 select 即可
    var syncAuthFields = function () {
      var isToken = document.getElementById('cfAuthType').value === 'token';
      var grp = function (id) { var el = document.getElementById(id); return el ? el.closest('.form-group') : null; };
      var accG = grp('cfAccountId'), tokG = grp('cfApiToken'), keyG = grp('cfGlobalKey');
      if (accG) accG.style.display = isToken ? '' : 'none';
      if (tokG) tokG.style.display = isToken ? '' : 'none';
      if (keyG) keyG.style.display = isToken ? 'none' : '';
    };
    // 邮箱即时校验：格式非法红框（globalKey 模式凭据头依赖邮箱，必填）
    var emailEl = document.getElementById('cfEmail');
    var checkCfEmail = function () {
      var ev = String(emailEl.value || '').trim();
      var bad = ev ? !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(ev) : document.getElementById('cfAuthType').value === 'globalKey';
      emailEl.classList.toggle('invalid', !!bad);
    };
    emailEl.addEventListener('input', checkCfEmail);
    document.getElementById('cfAuthType').addEventListener('change', function () { syncAuthFields(); checkCfEmail(); });
    syncAuthFields();
    // 部署方式联动：Snippets 模式下「订阅生成域名」升为必填（节点 Host/SNI 来源、子端拉取登记域名），
    // 「数据同步域名」降为选填（Snippets 无推送通道，仅登记用）；Worker 模式维持原语义（同步必填、订阅选填）
    // 根因修复：旧版 Snippets 误把节点域名填进 syncDomains（必填框），后端却读 domains → 节点丢失
    var syncDeployFields = function () {
      var isSnip = document.getElementById('cfDeployType').value === 'snippet';
      var syncLabel = document.getElementById('cfSyncDomainsLabel');
      var domLabel = document.getElementById('cfDomainsLabel');
      var syncHint1 = document.getElementById('cfSyncDomainsHint1');
      var syncHint2 = document.getElementById('cfSyncDomainsHint2');
      var domHint1 = document.getElementById('cfDomainsHint1');
      var domHint2 = document.getElementById('cfDomainsHint2');
      if (isSnip) {
        if (syncLabel) syncLabel.innerHTML = '数据同步域名<small class="hint" style="display:inline;margin-left:6px">每行一个「选填：Snippets 无推送通道，仅登记用」</small>';
        if (syncHint1) syncHint1.textContent = 'Snippets 子端无 /api/sync/receive-config，不接收推送；此字段仅作登记，可留空';
        if (syncHint2) syncHint2.style.display = 'none';
        if (domLabel) domLabel.innerHTML = '订阅生成域名<small class="hint" style="display:inline;margin-left:6px">每行一个「必填：节点 Host/SNI 来源 · 子端拉取登记域名」</small>';
        if (domHint1) domHint1.textContent = '订阅节点 Host / SNI 由此生成；Snippets 子端每 5 分钟按此域名拉取 /api/node-config';
        if (domHint2) domHint2.style.display = 'none';
      } else {
        if (syncLabel) syncLabel.innerHTML = '数据同步域名<small class="hint" style="display:inline;margin-left:6px">每行一个「必填：面板部署自动填充」</small>';
        if (syncHint1) syncHint1.textContent = '「同步配置」节点配置修改后会自动把配置推送至该域名绑定的子后端';
        if (syncHint2) syncHint2.style.display = '';
        if (domLabel) domLabel.innerHTML = '订阅生成域名<small class="hint" style="display:inline;margin-left:6px">每行一个「选填」</small>';
        if (domHint1) domHint1.textContent = '订阅节点 Host / SNI 由此生成，留空则使用数据同步域名生成订阅';
        if (domHint2) domHint2.style.display = '';
      }
    };
    document.getElementById('cfDeployType').addEventListener('change', syncDeployFields);
    syncDeployFields();
    enhanceSelects(modal);   // 动态插入的 select 补走 ms 下拉增强
    document.getElementById('cfAccOk').onclick = async function () {
      var v = function (id) { return String(document.getElementById(id).value || '').trim(); };
      // 域名列表解析：换行/逗号分隔，去空行去空白
      var parseList = function (id) { var s = v(id); return s ? s.split(/\r?\n|[,，]/).map(function (s2) { return s2.trim(); }).filter(Boolean) : []; };
      var oldDomains = acc ? (acc.syncDomains || []).concat(acc.domains || []).slice() : [];   // 编辑前的域名集合，保存后对账解绑用
      var okBtn = this;
      var okText = okBtn.textContent;
      okBtn.disabled = true;   // 凭据校验期间请求较慢，防重复提交
      okBtn.textContent = '验证中…';   // 新凭据要过 CF 校验，明确告知不是卡死
      // onOk 返回 false = 校验失败，弹窗保持打开
      var savedId = await onOk({
        name: v('cfName') || 'CF 账号',
        email: v('cfEmail'),
        accountId: v('cfAccountId'),
        authType: document.getElementById('cfAuthType').value,
        // 凭据与回显一致 = 未修改，有改动必过 CF 校验
        apiToken: v('cfApiToken'),
        // 清空 = 未修改（沿用库内原值）：凭据没有「删除」语义，要换就粘贴新值
        apiTokenSet: !!v('cfApiToken') && v('cfApiToken') !== (acc && acc.apiToken || ''),
        globalApiKey: v('cfGlobalKey'),
        globalApiKeySet: !!v('cfGlobalKey') && v('cfGlobalKey') !== (acc && acc.globalApiKey || ''),
        quota: parseInt(v('cfQuota'), 10) || 100000,
        deployType: document.getElementById('cfDeployType').value,
        protocol: document.getElementById('cfProtocol').value,
        domains: parseList('cfDomains'),
        syncDomains: parseList('cfSyncDomains')
      });
      okBtn.disabled = false;
      okBtn.textContent = okText;
      if (savedId === false) return;
      var hasSync = parseList('cfSyncDomains').length > 0;   // 先读表单再关弹窗：remove 后 DOM 已不存在
      modal.remove();
      if (hasSync) {
        showToast('Cloudflare 账号已保存');
        // 对账解绑：旧集合里被删掉的域名从子后端解绑，其余重新绑定（免重部署）
        var nowSet = parseList('cfSyncDomains').concat(parseList('cfDomains'));
        bindAccDomains(savedId, oldDomains.filter(function (h) { return nowSet.indexOf(h) === -1; }));
        return;
      }
      // Snippets 账号：不在面板部署，提示手动部署后结束
      var savedAcc0 = cfById(savedId);
      if (savedAcc0 && savedAcc0.deployType === 'snippet') {
        window.__showConfirm(
          'Snippets 账号已保存。子后端脚本请在 Cloudflare 控制台对应「订阅生成域名」的 Snippets 中手动部署，节点配置将由子端每 5 分钟自动拉取（无需同步域名，订阅生成域名必填）。',
          function () { }, '提示', { okText: '知道了', cancelText: '关闭' });
        return;
      }
      // 账号已保存进列表，按部署状态分两支：没部署先引导部署，已部署引导回编辑补域名
      var rec = deployRec(cfById(savedId));
      if (rec.worker || rec.project) {
        window.__showConfirm(
          '子后端已部署，无需重新部署。数据同步域名未填写，节点配置将无法推送至子后端也无法生成节点，请添加同步域名。',
          function () { window.__cfEditOpen(savedId); },
          '提示',
          { okText: '继续添加', cancelText: '稍后添加' }
        );
      } else {
        window.__showConfirm(
          '是否立即部署子后端？域名将按账号 CF 域名自动生成。',
          function () { window.openDeployModal([savedId]); },
          '提示',
          { okText: '一键部署', cancelText: '稍后部署' }
        );
      }
    };
  }

  // 渲染账号卡片（用量取 CF_USAGE 实查结果）
  function cfRender() {
    var grid = document.getElementById('cfAccountsGrid');
    if (!grid) return;
    if (CF_NO_D1) {
      // 跨全部列，防子项被挤偏
      grid.innerHTML = '<div style="grid-column:1/-1;display:flex;align-items:center;justify-content:center;padding:56px 20px;color:var(--text-muted,#94a3b8);font-size:.88rem">未绑定 D1 数据库，Cloudflare 账号管理不可用</div>';
      var bar = document.getElementById('cfActionBar');
      if (bar) bar.style.display = 'none';   // 操作栏（添加/批量/计数）整体隐藏：无存储层时这些操作必然失败
      return;
    }
    var barEl = document.getElementById('cfActionBar');
    if (barEl) barEl.style.display = 'flex';   // 从无 D1 态进入正常渲染时还原操作栏
    if (!CF_ACCOUNTS.length) {
      grid.innerHTML = '<div style="grid-column:1/-1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:56px 20px;text-align:center;color:var(--text-muted,#94a3b8)">' +
        '<div style="font-size:.92rem;font-weight:600">暂无 Cloudflare 账号</div>' +
        '<div style="font-size:.78rem">点击下方「添加账号」接入今日用量统计</div>' +
        '</div>';
      updateCFSelected();
      return;
    }
    grid.innerHTML = CF_ACCOUNTS.map(function (a) {
      var u = CF_USAGE[a.id] || { used: 0, workers: 0, pages: 0 };
      var quota = Number(a.quota) > 0 ? Number(a.quota) : 100000;
      var pct = Math.min(u.used / quota * 100, 100);
      var lv = pct > 80 ? 'danger' : pct > 50 ? 'warning' : 'normal';
      var wPct = u.used > 0 ? u.workers / u.used * 100 : 0;
      var pPct = u.used > 0 ? u.pages / u.used * 100 : 0;
      var domainCount = Array.isArray(a.domains) ? a.domains.length : 0;
      var syncCount = Array.isArray(a.syncDomains) ? a.syncDomains.length : 0;
      var added = a.createdAt ? String(a.createdAt).slice(0, 10) : '';
      var aid = escHtml(a.id);
      var off = a.status === 'disabled';   // 旧数据无 status 字段视为启用
      var drec = deployRec(a);
      var depBadge = drec.lastMode === 'pages' ? 'Pages' : drec.lastMode === 'worker' ? 'Workers' : (drec.worker ? 'Workers' : drec.project ? 'Pages' : '');   // 最近一次部署方式优先，旧记录无 lastMode 按 worker 优先回落
      var ver = CF_VERSIONS[a.id] || '';
      return '<div class="cf-account-card' + (a.id === CF_ACTIVE_ID ? ' active' : '') + (off ? ' disabled' : '') + '" data-id="' + aid + '">' +
        '<div class="cf-card-header">' +
          '<label class="checkbox-label no-text"><input type="checkbox" class="cf-card-checkbox" data-id="' + aid + '"><span class="checkmark"></span></label>' +
        '</div>' +
        '<div class="cf-card-info">' +
          '<div class="cf-card-account">' +
            '<div class="cf-card-title">' +
              '<div class="cf-card-avatar">' + (String(a.name || '').indexOf('子') !== -1 ? '子' : '主') + '<span class="cf-status-dot"></span></div>' +
              '<div class="cf-card-name"><h4>' + escHtml(a.name) + (a.deployType === 'snippet' ? '<span class="cf-deploy-badge">Snippets</span>' : '') + (depBadge ? '<span class="cf-deploy-badge">' + depBadge + '</span>' : '') + (ver ? '<span class="cf-deploy-badge cf-card-version">' + escHtml(ver) + '</span>' : '') + '</h4><p>' + escHtml(a.email) + '</p></div>' +
            '</div>' +
            '<div class="cf-card-details">' +
              '<div class="cf-card-row"><span class="label">认证方式</span><span class="value">' + (a.authType === 'globalKey' ? 'Global Key 模式' : 'Token 模式') + '</span></div>' +
              '<div class="cf-card-row"><span class="label">部署方式</span><span class="value">' + (a.deployType === 'snippet' ? 'Snippets 自动拉取 ≤5min' : 'Worker 推送') + (a.protocol === 'WS' || a.protocol === 'XHTTP' ? ' · ' + a.protocol : '') + '</span></div>' +
              '<div class="cf-card-row"><span class="label">' + (a.deployType === 'snippet' ? '同步域名' : '同步域名') + '</span><span class="value">' + syncCount + ' 个' + (a.deployType === 'snippet' ? ' · 选填' : '') + '</span></div>' +
              '<div class="cf-card-row"><span class="label">订阅域名</span><span class="value">' + domainCount + ' 个' + (a.deployType === 'snippet' && !domainCount ? ' · 待补' : '') + '</span></div>' +
            '</div>' +
          '</div>' +
          '<div class="cf-card-stats">' +
            '<div class="cf-stat-card cf-card-usage">' +
              '<div class="cf-usage-header"><span class="label">使用量</span><span class="percent ' + lv + '">' + pct.toFixed(1) + '%</span></div>' +
              '<div class="cf-usage-bar"><div class="cf-usage-fill ' + lv + '" style="width:' + pct + '%"></div></div>' +
              '<div class="cf-usage-stats"><span>' + cfFmt(u.used) + ' / ' + cfFmt(quota) + '</span><span>剩余 <span>' + cfFmt(Math.max(quota - u.used, 0)) + '</span></span></div>' +
            '</div>' +
            '<div class="cf-stat-card cf-card-wp">' +
              '<div class="cf-wp-item workers"><span class="cf-wp-icon">' + CF_ICON_BOLT + '</span><span class="cf-wp-label">Workers</span><div class="cf-wp-bar"><div class="cf-wp-bar-fill" style="width:' + wPct + '%"></div></div><span class="cf-wp-value">' + cfFmt(u.workers) + ' 次</span></div>' +
              '<div class="cf-wp-item pages"><span class="cf-wp-icon">' + CF_ICON_FILE + '</span><span class="cf-wp-label">Pages</span><div class="cf-wp-bar"><div class="cf-wp-bar-fill" style="width:' + pPct + '%"></div></div><span class="cf-wp-value">' + cfFmt(u.pages) + ' 次</span></div>' +
            '</div>' +
          '</div>' +
          '<div class="cf-card-footer">' +
            '<span class="cf-card-time">' + (added ? '添加于 ' + escHtml(added) : '点击刷新查询今日用量') + '</span>' +
            '<div class="cf-card-actions">' +
              '<button title="刷新用量" data-act="refresh" data-id="' + aid + '">' + CF_ICON_SYNC + '</button>' +
              '<button title="编辑" data-act="edit" data-id="' + aid + '">' + CF_ICON_EDIT + '</button>' +
              '<button title="一键部署" data-act="deploy" data-id="' + aid + '">' + CF_ICON_DEPLOY + '</button>' +
              '<button' + (off ? ' class="off" title="已禁用，点击启用"' : ' title="启用中，点击禁用（域名退出订阅与同步）"') + ' data-act="toggle" data-id="' + aid + '">' + CF_ICON_POWER + '</button>' +
              '<button class="danger" title="删除" data-act="del" data-id="' + aid + '">' + CF_ICON_TRASH + '</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');
    updateCFSelected();
  }
  function updateCFSelected() {
    var n = document.querySelectorAll('.cf-card-checkbox:checked').length;
    var el = document.getElementById('cfSelectedCount');
    if (el) el.textContent = n;
  }
  document.addEventListener('change', function (e) {
    if (e.target && e.target.classList && e.target.classList.contains('cf-card-checkbox')) updateCFSelected();
  });
  // 卡片操作按钮走事件委托（data-act/data-id，防注入）
  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('.cf-card-actions button[data-act]') : null;
    if (!btn) return;
    var id = btn.dataset.id;
    if (btn.dataset.act === 'toggle') { var a = cfById(id); if (a) cfToggleAccount(id, a.status === 'disabled'); }
    else if (btn.dataset.act === 'refresh') window.__cfRefresh(id);
    else if (btn.dataset.act === 'edit') window.__cfEditOpen(id);
    else if (btn.dataset.act === 'deploy') openDeployModal([id]);
    else if (btn.dataset.act === 'del') window.__cfDel(id);
  });
  // 批量操作下拉（批量禁用/批量删除，点击空白处关闭）
  window.toggleCFBatchDropdown = function (e) {
    e.stopPropagation();
    var menu = document.getElementById('cfBatchDropdownMenu');
    if (menu) menu.classList.toggle('show');
  };
  window.batchCFDisable = async function () {
    closeCFMenu();
    var ids = Array.prototype.map.call(document.querySelectorAll('.cf-card-checkbox:checked'), function (c) { return c.dataset.id; });
    if (!ids.length) { showToast('请先勾选要禁用的账号', true); return; }
    var toDisable = ids.filter(function (id) { var a = cfById(id); return a && a.status !== 'disabled'; });
    if (!toDisable.length) { showToast('选中账号均已处于禁用状态'); return; }
    window.__showConfirm(
      '将禁用 ' + toDisable.length + ' 个账号，其域名将退出订阅节点生成与配置推送，是否继续？',
      async function () {
        toDisable.forEach(function (id) { cfById(id).status = 'disabled'; });
        var ok = await cfPersistAll();
        showToast(ok ? '已禁用 ' + toDisable.length + ' 个账号' : '状态保存失败', !ok);
      },
      '批量禁用',
      { okText: '禁用', cancelText: '取消', danger: true }
    );
  };
  window.batchCFDelete = async function () {
    closeCFMenu();
    if (!window.LiteAPI) return;
    if (CF_NO_D1) { showToast('未绑定 D1 数据库，无法删除账号', true); return; }
    var ids = Array.prototype.map.call(document.querySelectorAll('.cf-card-checkbox:checked'), function (c) { return c.dataset.id; });
    if (!ids.length) { showToast('请先勾选要删除的账号', true); return; }
    window.__showConfirm(
      '确定删除选中的 ' + ids.length + ' 个账号？各自按部署记录删除 Worker / Pages / D1 及绑定的生产域，未在面板绑定的手动部署不受影响，不可恢复。',
      async function () {
        var okN = 0;
        for (var i = 0; i < ids.length; i++) {
          var rr = await LiteAPI.cfPost({ action: 'delete', id: ids[i] });
          if (rr && rr.success) okN++;
        }
        showToast(okN === ids.length ? '已删除 ' + okN + ' 个账号'
          : '仅删除 ' + okN + '/' + ids.length + ' 个（未绑定 D1 时无法删除）', okN !== ids.length);
        await ensureCfLoaded(true);
      },
      '删除账号',
      { okText: '删除', cancelText: '取消', danger: true }
    );
  };
  function closeCFMenu() {
    var menu = document.getElementById('cfBatchDropdownMenu');
    if (menu) menu.classList.remove('show');
  }
  document.addEventListener('click', closeCFMenu);

  // ============ 一键部署（POST /api/deploy：Worker 一次请求全链，Pages init→分片上传→commit） ============
  // 批量由前端逐账号顺序驱动，来源三选一两链共用 ============
  var DEPLOY_TAB = 'worker', DEPLOY_TARGETS = [], DEPLOY_RUNNING = false, DEPLOY_STOP = false;
  var DEPLOY_RESULTS = {}, DEPLOY_PG_DIRTY = false;   // 项目名被手动改动：显式指定目标，匹配不走记录/前缀兜底
  var DEPLOY_PG_SCAN = null;   // 弹窗打开时的 Pages 项目名扫描缓存（单账号无记录时拉取，供提示判断「将更新/将新建」）
  var DEPLOY_LAST_SPEC = null;   // 最近一次部署参数快照：部署状态弹窗下重试/重新部署时表单已关，取缓存
  var DEPLOY_MIME = { html: 'text/html', htm: 'text/html', css: 'text/css', js: 'application/javascript', mjs: 'application/javascript', json: 'application/json', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', avif: 'image/avif', ico: 'image/x-icon', txt: 'text/plain', md: 'text/plain', wasm: 'application/wasm', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf', xml: 'application/xml', pdf: 'application/pdf' };
  var DEPLOY_LIBS = [
    { local: 'assets/vendor/jszip.min.js', cdn: 'https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js', ok: function () { return typeof window.JSZip !== 'undefined'; } },
    { local: 'assets/vendor/spark-md5.min.js', cdn: 'https://cdn.jsdelivr.net/npm/spark-md5@3.0.2/spark-md5.min.js', ok: function () { return typeof window.SparkMD5 !== 'undefined'; } }
  ];
  var DeployPgPrefix = 'senflarelink-node';   // Pages 产品前缀：未手动改名时，账号内此前缀项目视为本工具的，一并更新（记录丢失时兜底识别）
  /** 部署记录解析（cfAccounts.deployInfo JSON：worker/d1/project） */
  function deployRec(a) { try { return JSON.parse(a && a.deployInfo || '{}') || {}; } catch (e) { return {}; } }
  /** 部署记录本地回写：面板内存与库内记录即时一致，下次打开弹窗自动带入 */
  function recordDeployLocal(id, patch) {
    var a = cfById(id);
    if (!a) return;
    var lastMode = patch.worker ? 'worker' : patch.project ? 'pages' : deployRec(a).lastMode;   // 最近一次部署方式，徽章以此为准
    a.deployInfo = JSON.stringify(Object.assign(deployRec(a), patch, { lastMode: lastMode }));
  }

  /** 是否生产域（workers.dev / pages.dev）：不作自定义域绑定，权重沉底 */
  function isProdHost(h) { return /\.workers\.dev$|\.pages\.dev$/i.test(String(h).replace(/^https?:\/\//i, '').trim()); }
  /** 可绑定/可登记域名：非 * 通配且非生产域 */
  function isBindableHost(h) { return h.indexOf('*') !== 0 && !isProdHost(h); }
  /** 同步域名排序：自定义域权重高于生产域（生产域沉底），与后端持久化口径一致 */
  function sortSyncDomains(list) {
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var h = String(list[i]).replace(/^https?:\/\//i, '').replace(/\/+$/, '').trim().toLowerCase();   // 登记一律为裸主机名
      if (h && out.indexOf(h) === -1) out.push(h);
    }
    return out.sort(function (a, b) { return (isProdHost(a) ? 1 : 0) - (isProdHost(b) ? 1 : 0); });
  }
  /** 编辑框内是否存在自定义域行（排除生产域与空行）：决定是否需要自动生成 */
  function hasCustomSync(el) {
    var lines = el.value.split(/[\r\n|,，]+/);
    for (var i = 0; i < lines.length; i++) { var t = lines[i].trim(); if (t && !isProdHost(t)) return true; }
    return false;
  }
  /** 保存后对账域名绑定（免重部署）：移除的解绑、其余的绑定，按部署记录走对应 API，CF 幂等可重复执行 */
  async function bindAccDomains(id, removed) {
    var a = cfById(id);
    if (!a) return;
    var rec = deployRec(a);
    if (!rec.worker && !rec.project) return;   // 未部署过：绑定在部署链里做
    var syncs = Array.isArray(a.syncDomains) ? a.syncDomains : [];
    var subs = Array.isArray(a.domains) ? a.domains : [];
    removed = removed || [];
    var hosts = syncs.concat(subs).filter(isBindableHost);
    if (!hosts.length && !removed.length) return;
    var n = 0, fail = 0;
    var bind = function (action, extra) {
      return LiteAPI.deploy(Object.assign({ action: action, accountId: id }, extra)).then(function (r) {
        n++;
        if (!r || !r.success) fail++;
      }, function () { fail++; });
    };
    // 各域名互不冲突，全量并行绑定（后端单次绑定已并行预取，这里再消掉逐域名串行）
    var jobs = [];
    for (var r0 = 0; r0 < removed.length; r0++) {
      if (removed[r0].indexOf('*') === 0) continue;
      if (rec.worker) jobs.push(bind('delete-worker-domain', { hostname: removed[r0], workerName: rec.worker }));
      else if (rec.project) jobs.push(bind('delete-page-domain', { domain: removed[r0], project: rec.project }));
    }
    for (var i = 0; i < hosts.length; i++) {
      if (rec.worker) {
        jobs.push(bind('add-worker-domain', { hostname: hosts[i], workerName: rec.worker, dns: syncs.indexOf(hosts[i]) !== -1 }));   // 同步域：DNS + 路由；订阅生成域：仅路由
      } else if (rec.project) {
        jobs.push(bind('add-page-domain', { domain: hosts[i], project: rec.project }));
      }
    }
    await Promise.all(jobs);
    if (fail) showToast('域名对账完成，' + fail + ' 项失败（域名需已接入该 CF 账号）', true);
    else if (n) showToast('域名已同步到子后端（' + n + ' 项）');
  }

  /** 按需加载 zip/hash 组件（本地 vendor 优先，失败回落 CDN），done(ok) */
  function loadDeployLibs(done) {
    var need = DEPLOY_LIBS.filter(function (l) { return !l.ok(); });
    if (!need.length) return done(true);
    var left = need.length, bad = false;
    need.forEach(function (l) {
      var load = function (src, isCdn) {
        var t = document.createElement('script');
        t.src = src;
        t.onload = function () { if (!l.ok()) bad = true; settle(); };
        t.onerror = function () { if (isCdn) { bad = true; settle(); } else load(l.cdn, true); };
        document.head.appendChild(t);
      };
      load(l.local, false);
    });
    function settle() { if (--left > 0) return; done(!bad); }
  }
  function deployMime(path) {
    var ext = (path.split('.').pop() || '').toLowerCase();
    return DEPLOY_MIME[ext] || 'application/octet-stream';
  }
  /** 路径过滤：隐藏文件 */
  function deployPathOk(path) {
    return !!path && path.charAt(0) !== '.' && !/(^|\/)\./.test(path) && !/__MACOSX/i.test(path);
  }
  function fileB64(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result || '').split(',')[1] || ''); };
      r.onerror = function () { reject(new Error('文件读取失败')); };
      r.readAsDataURL(file);
    });
  }
  function textB64(text) {
    var bytes = new TextEncoder().encode(text), bin = '';
    for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  }
  function isZipBytes(bytes) { return !!bytes && bytes.length > 3 && bytes[0] === 0x50 && bytes[1] === 0x4B; }
  function readAsText(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result || '')); };
      r.onerror = function () { reject(new Error('文件读取失败')); };
      r.readAsText(file);
    });
  }

  /** 打开一键部署弹窗：lockIds 传账号 id 锁定单账号（卡片入口），不传取页面勾选（批量入口，禁用账号排除） */
  window.openDeployModal = function (lockIds) {
    if (CF_NO_D1) { showToast('未绑定 D1 数据库，无法部署', true); return; }
    if (DEPLOY_RUNNING) { showToast('上一轮部署仍在收尾，请稍候', true); return; }
    doSwitchTab('nodes-backend');   // 切到后端管理视图，部署进度与账号卡片同屏可见
    DEPLOY_TARGETS = lockIds && lockIds.length ? lockIds.slice()
      : Array.prototype.map.call(document.querySelectorAll('.cf-card-checkbox:checked'), function (c) { return c.dataset.id; })
        .filter(function (id) { var a = cfById(id); return a && a.status !== 'disabled'; });
    if (!DEPLOY_TARGETS.length) { showToast('请先勾选要部署的账号', true); return; }
    DEPLOY_STOP = false; DEPLOY_RESULTS = {}; DEPLOY_PG_DIRTY = false;

    var old = document.getElementById('deployModal');
    if (old) old.remove();
    var modal = document.createElement('div');
    modal.className = 'modal show';
    modal.id = 'deployModal';
    modal.onclick = function (e) { if (e.target === modal) closeDeployModal(); };
    modal.innerHTML = '<div class="modal-content modal-lg dep-modal" onclick="event.stopPropagation()">' +
      '<div class="modal-header"><h3>' + (DEPLOY_TARGETS.length === 1 ? '一键部署' : '批量部署（' + DEPLOY_TARGETS.length + ' 个账号）') + '</h3><button class="modal-close" onclick="closeDeployModal()">×</button></div>' +
      '<div class="modal-body">' +
        '<div class="dep-form">' +
        '<div class="node-tabs"><div class="src-toggle">' +
          '<button class="src-btn active" onclick="switchDeployType(\'worker\', this)">Worker</button>' +
          '<button class="src-btn" onclick="switchDeployType(\'pages\', this)">Pages</button>' +
        '</div></div>' +
        '<span class="hint dep-note">' + (DEPLOY_TARGETS.length > 1
          ? '批量部署：按各账号部署记录判断，已有部署项目自动更新，没有则按照当前选择的模式进行新建'
          : '按所选模式部署：账号里已有的同模式项目会自动匹配更新，没有则新建') + '</span>' +
        '<div class="form-group"><label>代码来源</label>' +
          '<div class="dep-src-row">' +
            '<label><input type="radio" name="depSrc" value="url" checked onchange="switchDeploySource(this.value)">直链</label>' +
            '<label><input type="radio" name="depSrc" value="text" onchange="switchDeploySource(this.value)">编辑框</label>' +
            '<label><input type="radio" name="depSrc" value="file" onchange="switchDeploySource(this.value)">上传</label>' +
          '</div>' +
          '<div id="depSrcUrl"><input type="url" class="form-control" id="depUrl" placeholder=".js 直链或 .zip 直链"></div>' +
          '<div id="depSrcText" style="display:none"><textarea class="form-control" rows="6" id="depText" placeholder="粘贴子后端 _worker.js 代码…"></textarea></div>' +
          '<div id="depSrcFile" style="display:none">' +
            '<div class="dep-drop" id="depFileDrop">点击选择或拖入子后端 <b>_worker.js</b> / <b>_worker.zip</b></div>' +
            '<input type="file" id="depFile" accept=".js,.zip" style="display:none">' +
            '<div id="depFileInfo" class="dep-fileinfo"></div>' +
          '</div>' +
        '</div>' +
        '<div id="depPaneWorker">' +
          '<div class="form-group"><label>项目名</label>' +
            '<input type="text" class="form-control" id="depWkName" value="senflarelink-node">' +
            '<span class="hint" id="depWkNameHint">与部署记录及 senflarelink-node Worker 匹配更新，手动改名后只匹配同名，没有则新建</span></div>' +
          '<div class="form-group"><label>D1 数据库名</label>' +
            '<input type="text" class="form-control" id="depWkD1" value="senflarelink-node">' +
            '<span class="hint" id="depWkD1Hint">项目已绑定数据库时不改动，没有时自动创建并绑定</span></div>' +
        '</div>' +
        '<div id="depPanePages" style="display:none">' +
          '<div class="form-group" style="display:flex;gap:10px">' +
            '<div style="flex:1"><label>项目名</label><input type="text" class="form-control" id="depPgName" value="senflarelink-node-page"><span class="hint" id="depPgNameHint">与部署记录及 senflarelink-node-* 项目匹配更新，手动改名后只匹配同名，没有则新建</span></div>' +
            '<div style="width:140px"><label>分支</label><input type="text" class="form-control" id="depPgBranch" value="main"></div>' +
          '</div>' +
          '<div class="form-group"><label>D1 数据库名</label>' +
            '<input type="text" class="form-control" id="depPgD1" value="senflarelink-node">' +
            '<span class="hint" id="depPgD1Hint">项目已绑定数据库时不改动，没有时自动创建并绑定</span></div>' +
        '</div>' +
        '<div class="form-group"><label>项目域名</label>' +
          '<select class="form-control" id="depXDomainWk" onchange="pdDomainChange(this.value, \'Wk\')">' +
            '<option value="default">默认域名</option>' +
            '<option value="custom">自定义域名</option>' +
          '</select>' +
          (DEPLOY_TARGETS.length > 1 ? '<span class="hint" id="depXBatchHint" style="display:none"></span>' : '') +
          '<span class="hint" id="depXHintWk" style="display:none"></span>' +
          '<div id="depXCustomWk" style="display:none">' +
            '<div class="form-group"><label>域名列表</label>' +
              '<select class="form-control" id="depXZoneWk" onchange="pdZoneGen(this.value, \'Wk\')"><option value="">获取中…</option></select>' +
              '<span class="hint">账号接入的 CF 域名，选定后自动生成下方未填写的域名</span></div>' +
            '<div class="form-group"><label>数据同步域名<small class="hint" style="display:inline;margin-left:6px">每行一个「必填：部署时自动填充」</small></label>' +
              '<textarea class="form-control" id="depSyncWk" rows="2" placeholder="sync.example.com"></textarea>' +
              '<span class="hint">节点配置推送目标，主域段按上方选定域名自动生成，仅需修改域名前缀「sync 」</span></div>' +
            '<div class="form-group"><label>订阅生成域名<small class="hint" style="display:inline;margin-left:6px">每行一个「选填」</small></label>' +
              '<textarea class="form-control" id="depSubWk" rows="2" placeholder="*.example.com"></textarea>' +
              '<span class="hint">订阅节点 Host / SNI 生成来源，可不填写</span>' +
              '<span class="hint">留空则使用数据同步域名生成订阅，* 开头的通配域名不参与生成与绑定，如需自定义域名，具体规则同上</span></div>' +
          '</div>' +
        '</div>' +
        '</div>' +
        '<div class="dep-body" id="depBody" style="display:none">' +
          '<div class="dep-list" id="depList"><div class="dep-scroll" id="depListScroll"></div></div>' +
          '<div class="dep-detail" id="depDetail"></div>' +
        '</div>' +
      '</div>' +
      '<div class="modal-footer">' +
        '<span class="dep-foot-status" id="depFootStatus"></span>' +
        '<button class="btn btn-outline" id="depCancelBtn" onclick="closeDeployModal()">取消部署</button>' +
        '<button class="btn btn-primary" id="depStartBtn" onclick="deployStartClick()">开始部署</button>' +
      '</div>' +
    '</div>';
    document.body.appendChild(modal);
    enhanceSelects(modal);   // 动态插入的原生 select（项目域名等）补走 ms 下拉增强
    // 批量：项目域名按选择器二态走，自定义档展示示例编辑框
    if (DEPLOY_TARGETS.length > 1) pdDomainChange('default', 'Wk');
    // 自动域接管：此前以自定义域部署过的账号（登记了非生产同步域）自动选中「自定义域名」并回填
    if (DEPLOY_TARGETS.length === 1) {
      var accAuto = cfById(DEPLOY_TARGETS[0]) || {};
      var hasCustomSync = Array.isArray(accAuto.syncDomains) && accAuto.syncDomains.some(function (h) { return !isProdHost(h); });
      if (hasCustomSync) {
        var dsel = document.getElementById('depXDomainWk');
        if (dsel && dsel.value !== 'custom') { dsel.value = 'custom'; dsel.dispatchEvent(new Event('change', { bubbles: true })); }
      }
    }
    wireDeployEvents();
    deployPrefill();
    // Pages 项目名：前缀 + 随机后缀，规避同名冲突
    var pgName = document.getElementById('depPgName');
    if (!deployRec(cfById(DEPLOY_TARGETS[0])).project) {
      pgName.value = 'senflarelink-node-' + Math.random().toString(36).slice(2, 8);
    }
    document.getElementById('depFootStatus').textContent = '将部署到 ' + DEPLOY_TARGETS.length + ' 个账号';
    refreshDeployHints();
    // 无记录单账号：扫同名 Worker/D1 回写记录
    if (DEPLOY_TARGETS.length === 1 && !deployRec(cfById(DEPLOY_TARGETS[0])).worker) {
      var scanName = document.getElementById('depWkName').value;
      LiteAPI.deploy({ action: 'check-worker', accountId: DEPLOY_TARGETS[0], workerName: scanName }).then(function (r) {
        if (r && r.success && r.hasWorker && document.getElementById('deployModal')) {
          recordDeployLocal(DEPLOY_TARGETS[0], { worker: scanName, d1: r.d1 || scanName });
          refreshDeployHints();
        }
      }).catch(function () { });
    }
    // 无 Pages 记录：扫同名/前缀项目回写记录
    if (DEPLOY_TARGETS.length === 1 && !deployRec(cfById(DEPLOY_TARGETS[0])).project) {
      var pgAcc = DEPLOY_TARGETS[0];
      LiteAPI.deploy({ action: 'list-pages', accountId: pgAcc }).then(function (r) {
        if (!r || !r.success || !document.getElementById('deployModal')) return;
        DEPLOY_PG_SCAN = (r.projects || []).map(function (p) { return String(p.name || '').toLowerCase(); });
        var hit = '';
        var cur = document.getElementById('depPgName').value.toLowerCase();
        if (DEPLOY_PG_SCAN.indexOf(cur) !== -1) hit = cur;
        else {
          var prefixHits = DEPLOY_PG_SCAN.filter(function (n) { return n.indexOf(DeployPgPrefix + '-') === 0; });
          if (prefixHits.length) hit = prefixHits[0];
        }
        if (hit && !deployRec(cfById(pgAcc)).project) {
          recordDeployLocal(pgAcc, { project: hit });
          document.getElementById('depPgName').value = hit;   // 接管手动部署的项目
          refreshDeployHints();
        }
      }).catch(function () { });
    }
  };
  window.batchCFDeploy = function () { closeCFMenu(); openDeployModal(null); };

  /** 弹窗内事件绑定（文件选择 / 拖放 / 名称输入联动提示） */
  function wireDeployEvents() {
    var file = document.getElementById('depFile');
    file.addEventListener('change', function () { onSourcePicked(file.files[0]); });
    bindDeployDrop('depFileDrop', function (f) { onSourcePicked(f); });
    ['depWkName', 'depWkD1', 'depPgName', 'depPgD1'].forEach(function (id) {
      document.getElementById(id).addEventListener('input', function () {
        if (id === 'depPgName') DEPLOY_PG_DIRTY = true;
        refreshDeployHints();
      });
    });
  }
  function bindDeployDrop(id, onFile) {
    var el = document.getElementById(id);
    el.addEventListener('click', function () { onFile(null); });
    ['dragenter', 'dragover'].forEach(function (k) {
      el.addEventListener(k, function (e) { e.preventDefault(); el.classList.add('over'); });
    });
    el.addEventListener('dragleave', function () { el.classList.remove('over'); });
    el.addEventListener('drop', function (e) {
      e.preventDefault(); el.classList.remove('over');
      var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      onFile(f || null);
    });
  }
  /** 上传来源选定：.js/.zip 暂存 File（zip 内容部署时再解，避免打开弹窗就付解析成本） */
  function onSourcePicked(f) {
    var info = document.getElementById('depFileInfo');
    if (!f) { document.getElementById('depFile').click(); return; }
    if (!/\.js$|\.zip$/i.test(f.name)) { info.textContent = '请选择 .js 或 .zip 文件'; return; }
    info.textContent = '已选择：' + f.name + '（' + (f.size / 1024).toFixed(1) + ' KB）';
  }
  function deployPrefill() {
    var rec = deployRec(cfById(DEPLOY_TARGETS[0]));
    if (rec.worker) document.getElementById('depWkName').value = rec.worker;
    if (rec.d1) document.getElementById('depWkD1').value = rec.d1;
    if (rec.project) document.getElementById('depPgName').value = rec.project;
  }
  /** 新建/更新动态提示 + 名称即时校验：非法红框，错误文案顶替提示（规则与主后端一致） */
  var DeployWkNameRe = /^[a-zA-Z0-9_-]{1,58}$/;
  var DeployPgNameRe = /^[a-z0-9](?:[a-z0-9-]{0,56}[a-z0-9])?$/;
  var DeployPgHintDef = {};   // Pages 两个提示位的默认文案（弹窗重建不变，首次捕获后复用）
  function pgHint(id, err) {
    var el = document.getElementById(id);
    if (!el) return;
    if (!(id in DeployPgHintDef)) DeployPgHintDef[id] = el.textContent;
    el.textContent = err || DeployPgHintDef[id];
  }
  function refreshDeployHints() {
    var nameEl = document.getElementById('depWkName'), d1El = document.getElementById('depWkD1');
    if (!nameEl || !d1El) return;
    var name = String(nameEl.value || '').trim(), d1v = String(d1El.value || '').trim();
    var recs = DEPLOY_TARGETS.map(function (id) { return deployRec(cfById(id)); });
    var wAll = recs.length && recs.every(function (r) { return r.worker === name; });
    var dAll = recs.length && recs.every(function (r) { return r.d1 === d1v; });
    var wkErr = name && !DeployWkNameRe.test(name) ? '名称不合法：仅字母/数字/连字符/下划线，≤58' : '';
    nameEl.classList.toggle('invalid', !!wkErr);
    document.getElementById('depWkNameHint').textContent = wkErr
      ? wkErr
      : (wAll ? '上次部署过「' + name + '」，将直接更新它' : '将以此名称新建 Worker（账号里已有同名则转为更新）');
    var d1Err = !d1v ? 'D1 数据库名不能为空' : '';
    d1El.classList.toggle('invalid', !!d1Err);
    document.getElementById('depWkD1Hint').textContent = d1Err
      ? d1Err
      : (dAll ? '使用已有的「' + d1v + '」数据库，数据不动' : '没有同名数据库时会自动创建');
    // Pages 链同规则即时校验（红框 + 错误文案顶替默认提示）
    var pgEl = document.getElementById('depPgName'), pgD1El = document.getElementById('depPgD1');
    if (!pgEl || !pgD1El) return;
    var pgV = String(pgEl.value || '').trim();
    var pgErr = pgV && !DeployPgNameRe.test(pgV) ? '项目名不合法：仅小写字母/数字/连字符，2-58' : '';
    pgEl.classList.toggle('invalid', !!pgErr);
    if (!pgErr && pgV && DEPLOY_TARGETS.length === 1) {
      var recPg = deployRec(cfById(DEPLOY_TARGETS[0])).project;
      var known = DEPLOY_PG_SCAN && DEPLOY_PG_SCAN.indexOf(pgV.toLowerCase()) !== -1;
      if ((recPg && recPg.toLowerCase() === pgV.toLowerCase()) || known) {
        pgHint('depPgNameHint', '账号里已有同名项目，将直接更新它');
        return;
      }
    }
    pgHint('depPgNameHint', pgErr);
    var pgD1Err = !String(pgD1El.value || '').trim() ? 'D1 数据库名不能为空' : '';
    pgD1El.classList.toggle('invalid', !!pgD1Err);
    var pgRecs = DEPLOY_TARGETS.map(function (id) { return deployRec(cfById(id)); });
    var pgD1All = pgRecs.length && pgRecs.every(function (r) { return r.d1 === String(pgD1El.value || '').trim(); });
    var pgD1HintEl = document.getElementById('depPgD1Hint');
    pgD1HintEl.textContent = pgD1Err ? pgD1Err
      : (pgD1All ? '项目已绑定该数据库，不会改动' : '项目未绑定时将自动创建并绑定');
  }
  window.switchDeployType = function (t, btn) {
    DEPLOY_TAB = t;
    var btns = document.querySelectorAll('#deployModal .src-btn');
    for (var i = 0; i < btns.length; i++) btns[i].classList.toggle('active', btns[i] === btn);
    document.getElementById('depPaneWorker').style.display = t === 'worker' ? '' : 'none';
    document.getElementById('depPanePages').style.display = t === 'pages' ? '' : 'none';
  };
  // ===== 项目域名交互 =====
  /** 切默认/自定义：批量下说明展开 + 自定义档展示可改前缀的示例编辑框；单账号自定义展开 主域名下拉 + 两个域名编辑框（账号已登记的预填，缺的按选定主域名自动生成） */
  window.pdDomainChange = function (v, sid) {
    var hint = document.getElementById('depXHint' + sid);
    var box = document.getElementById('depXCustom' + sid);
    if (!hint || !box) return;
    if (DEPLOY_TARGETS.length > 1) {
      hint.style.display = 'none';
      var bh = document.getElementById('depXBatchHint');
      if (bh) {
        bh.style.display = '';
        bh.textContent = '已部署的账号一律沿用登记域名绑定，不受此功能影响，未部署的账号按所选模式部署并绑定对应域名';
      }
      box.style.display = v === 'custom' ? '' : 'none';
      var zoneGrp = document.getElementById('depXZone' + sid);
      if (zoneGrp) zoneGrp.closest('.form-group').style.display = 'none';   // 各账号主域不同，zone 下拉不适用
      var syncEl = document.getElementById('depSync' + sid), subEl = document.getElementById('depSub' + sid);
      if (syncEl && !syncEl.value.trim()) syncEl.value = 'sync.example.com';   // 前缀可改，主域段仅为占位（已有编辑值时不覆盖）
      if (subEl && !subEl.value.trim()) subEl.value = '*.example.com';   // * = 通配不生成，改具体前缀才生成
      var syncHint = syncEl && syncEl.nextElementSibling, subHint = subEl && subEl.nextElementSibling;   // 编辑框下方的 hint
      if (syncHint) syncHint.textContent = '节点配置推送目标，仅需修改域名前缀「sync 」， .example.com 为占位符不可修改，未登记账号按「前缀.各账号主域」自动生成并登记';
      if (subHint) subHint.textContent = '订阅域名格式：仅需修改域名前缀「* 」， .example.com 为占位符不可修改，改为具体前缀（如 sub）时未登记账号按「前缀.各账号主域」自动生成并登记';
      return;
    }
    box.style.display = v === 'custom' ? '' : 'none';
    if (v !== 'custom') { hint.style.display = 'none'; return; }
    var zoneSel = document.getElementById('depXZone' + sid);
    var syncEl = document.getElementById('depSync' + sid), subEl = document.getElementById('depSub' + sid);
    if (!zoneSel || !syncEl || !subEl) return;
    zoneSel.parentElement.style.display = '';
    var a = cfById(DEPLOY_TARGETS[0]) || {};
    if (!syncEl.value.trim() && Array.isArray(a.syncDomains)) syncEl.value = sortSyncDomains(a.syncDomains).join('\n');
    if (!subEl.value.trim() && Array.isArray(a.domains)) subEl.value = a.domains.filter(isBindableHost).join('\n');   // 不回显 * 与生产域脏数据
    // 已建绑定回显：路由 + Pages 域映射进订阅生成域
    var recD = deployRec(a);
    var mergeDomains = function (hosts) {
      var cur = subEl.value.trim() ? subEl.value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean) : [];
      var added = false;
      hosts.forEach(function (h) { if (h && cur.indexOf(h) === -1 && (a.syncDomains || []).indexOf(h) === -1 && isBindableHost(h)) { cur.push(h); added = true; } });
      if (added) subEl.value = cur.join('\n');
    };
    if (recD.worker) {
      LiteAPI.deploy({ action: 'list-worker-routes', accountId: DEPLOY_TARGETS[0], workerName: recD.worker }).then(function (r) {
        if (r && r.success && r.hosts) mergeDomains(r.hosts);
      });
    }
    if (recD.project) {
      LiteAPI.deploy({ action: 'list-pages', accountId: DEPLOY_TARGETS[0] }).then(function (r) {
        if (!r || !r.success) return;
        var p = (r.projects || []).filter(function (x) { return x.name === recD.project; })[0];
        if (p) mergeDomains(p.domains || []);
      });
    }
    if (zoneSel.options.length > 1) { pdZoneGen(zoneSel.value, sid); return; }   // 已拉取过：只补空缺
    zoneSel.options.length = 0;
    zoneSel.add(new Option('获取中…', ''));
    var done = false;   // 超时截断：请求挂起时 8s 后放手，迟到结果不再覆盖 UI
    LiteAPI.deploy({ action: 'list-zones', accountId: DEPLOY_TARGETS[0] }).then(function (r) {
      if (done) return;
      done = true;
      var zones = (r && r.zones) || [];
      zoneSel.options.length = 0;
      if (!zones.length) {
        zoneSel.add(new Option('未获取到域名', ''));
        if (!syncEl.value.trim()) { hint.textContent = '账号无可用的 CF 域名，请手动填写同步域名'; hint.style.display = ''; }
        return;
      }
      zones.forEach(function (z) { zoneSel.add(new Option(z.name + (z.status !== 'active' ? '（' + z.status + '）' : ''), z.name)); });
      var act = zones.filter(function (x) { return x.status === 'active'; })[0] || zones[0];
      zoneSel.value = act.name;
      // options 异步填充后重建 ms 镜像：enhanceSelects 跳过已标记的 select，须先拆旧结构
      var oldMs = zoneSel.parentElement.querySelector('.ms');
      if (oldMs) oldMs.remove();
      zoneSel.removeAttribute('data-ms');
      zoneSel.classList.remove('hidden');
      enhanceSelects(zoneSel.parentElement);
      pdZoneGen(act.name, sid);
    }).catch(function () {
      if (done) return;
      done = true;
      zoneSel.options.length = 0;
      zoneSel.add(new Option('获取失败', ''));
      if (!syncEl.value.trim()) { hint.textContent = '域名获取失败，请手动填写同步域名'; hint.style.display = ''; }
    });
    setTimeout(function () {
      if (done) return;
      done = true;
      zoneSel.options.length = 0;
      zoneSel.add(new Option('获取失败', ''));
      if (!syncEl.value.trim()) { hint.textContent = '域名获取失败，请手动填写同步域名'; hint.style.display = ''; }
    }, 8000);
  };
  /** 选定域名：同步域名生成 sync.前缀，订阅生成域名生成 * 通配（默认不绑定，改具体前缀才绑定） */
  window.pdZoneGen = function (zone, sid) {
    if (!zone) return;
    var syncEl = document.getElementById('depSync' + sid), subEl = document.getElementById('depSub' + sid);
    if (syncEl && !hasCustomSync(syncEl)) syncEl.value = 'sync.' + zone;   // 生产域行不算已有自定义域
    if (subEl) subEl.value = '';   // 订阅生成域名不自动生成，显式填写才登记
  };

  window.switchDeploySource = function (v) {
    ['Url', 'Text', 'File'].forEach(function (s) {
      document.getElementById('depSrc' + s).style.display =
        ({ Url: 'url', Text: 'text', File: 'file' }[s] === v ? '' : 'none');
    });
  };
  window.closeDeployModal = async function () {
    var m = document.getElementById('deployStatusModal') || document.getElementById('deployModal');
    if (!m) return;
    if (DEPLOY_RUNNING) {
      if (!(await themeConfirm('部署进行中，关闭将不再继续后续账号，是否关闭？', '关闭部署', { danger: true }))) return;
      DEPLOY_STOP = true;   // 不清 DEPLOY_RUNNING：旧循环收尾时复位，防止收尾前重开弹窗引发并发部署
    }
    m.remove();
  };
  function lockDeployParams(on) {
    ['depPaneWorker', 'depPanePages'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.classList.toggle('locked', on);
    });
  }
  /** 七步统一骨架 + 账号状态渲染（方案 D）：步骤名固定，详情按链路填充 */
  var DEPLOY_STEPS = ['初始化', '上传资产', '创建部署', '绑定数据库', '绑定域名', '推送配置', '项目预览'];
  var DEPLOY_STATE = {};   // id → { done, cur, failStep, infs[6], type, url, t0, err }
  var DEPLOY_SEL = null;
  var DEPLOY_TICK = null;
  function depPct(st) { return Math.min(Math.round(st.done / DEPLOY_STEPS.length * 100), 100); }
  function depRenderList() {
    var box = document.getElementById('depListScroll');
    if (!box) return;
    box.innerHTML = DEPLOY_TARGETS.map(function (id) {
      var st = DEPLOY_STATE[id] || { done: 0, cur: -1, type: depTypeOf(id) };
      var a = cfById(id);
      var dot = st.failStep != null ? 'fail' : (DEPLOY_RESULTS[id] === 'ok' || st.done >= DEPLOY_STEPS.length ? 'ok' : (st.cur >= 0 ? 'run' : 'wait'));
      var pct = DEPLOY_RESULTS[id] === 'ok' ? 100 : depPct(st);
      return '<div class="dep-item' + (DEPLOY_SEL === id ? ' on' : '') + '" data-id="' + id + '">' +
        '<span class="dep-dot ' + dot + '"></span>' + escHtml(a ? a.name : id) +
        '<span class="cf-deploy-badge">' + st.type + '</span>' +
        '<span class="dep-res">' + pct + '%</span></div>';
    }).join('');
    box.querySelectorAll('.dep-item').forEach(function (el) {
      el.onclick = function () { DEPLOY_SEL = el.dataset.id; depRenderList(); depRenderDetail(); };
    });
  }
  function depRenderDetail() {
    var box = document.getElementById('depDetail');
    if (!box || !DEPLOY_SEL) return;
    var st = DEPLOY_STATE[DEPLOY_SEL] || { done: 0, cur: -1, infs: [], failStep: null };
    var a = cfById(DEPLOY_SEL);
    var pct = DEPLOY_RESULTS[DEPLOY_SEL] === 'ok' ? 100 : depPct(st);
    var off = (226 * (1 - pct / 100)).toFixed(0);
    var stepsHtml = DEPLOY_STEPS.map(function (lbl, i) {
      var failed = st.failStep === i;
      var cls = failed ? ' fail' : (i < st.done ? ' done' : (i === st.cur ? ' cur' : ''));
      var dotIn = failed ? '✗' : (i < st.done ? '✓' : (i === st.cur ? '<span class="dep-spin"></span>' : String(i + 1)));
      var inf = failed ? (st.err || '失败') : (st.infs[i] || '—');
      var infCls = failed ? 'inf err' : (i === 6 && st.url ? 'inf link' : 'inf');
      var infHtml = (i === 6 && st.url) ? '<a href="' + escHtml(st.url) + '" target="_blank">' + escHtml(st.url) + '</a>' : escHtml(inf);
      return '<div class="dep-step' + cls + '"><span class="dot">' + dotIn + '</span><span class="lbl">' + lbl +
        '</span><span class="' + infCls + '">' + infHtml + '</span></div>';
    }).join('');
    var head = '';
    if (DEPLOY_TARGETS.length === 1) {
      var secs = st.t0 ? Math.round((Date.now() - st.t0) / 1000) : 0;
      head = '<div class="dep-head"><span class="acc">' + escHtml(a ? a.name : DEPLOY_SEL) +
        '<span class="cf-deploy-badge">' + st.type + '</span></span><span class="t">已运行 ' + secs + 's</span></div>';
    }
    box.innerHTML = head +
      '<div class="dep-ring-wrap">' +
        '<svg class="dep-ring" viewBox="0 0 84 84"><circle class="bg" cx="42" cy="42" r="36"></circle>' +
        '<circle class="fg" cx="42" cy="42" r="36" stroke-dasharray="226" stroke-dashoffset="' + off + '"></circle>' +
        '<text class="pc" x="42" y="48">' + pct + '%</text></svg>' +
        '<div class="dep-steps">' + stepsHtml + '</div>' +
      '</div>';
  }
  /** 账号在本次部署中的方式徽章：批量按部署记录（同执行路由），单账号按所选 Tab */
  function depTypeOf(id) {
    if (DEPLOY_TARGETS.length === 1) return DEPLOY_TAB === 'pages' ? 'Pages' : 'Worker';
    var rec = deployRec(cfById(id));
    if (rec.worker) return 'Worker';
    if (rec.project) return 'Pages';
    return DEPLOY_TAB === 'pages' ? 'Pages' : 'Worker';
  }
  function depStateInit(ids) {
    ids.forEach(function (id) {
      DEPLOY_STATE[id] = { done: 0, cur: -1, failStep: null, infs: ['', '', '', '', '', '', ''], type: depTypeOf(id), url: '', t0: 0, err: '' };
    });
    DEPLOY_SEL = ids[0];
  }
  var depStepRun = function (id, n, inf) {
    var st = DEPLOY_STATE[id];
    st.cur = n - 1; if (inf != null) st.infs[n - 1] = inf;
    depRenderList(); depRenderDetail();
  };
  var depStepDone = function (id, n, inf) {
    var st = DEPLOY_STATE[id];
    st.done = Math.max(st.done, n); st.cur = -1;
    if (inf != null) st.infs[n - 1] = inf;
    depRenderList(); depRenderDetail();
  };
  var depStepFail = function (id, n, msg) {
    var st = DEPLOY_STATE[id];
    st.failStep = n - 1; st.cur = -1; st.err = msg;
    depRenderList(); depRenderDetail();
  };
  /** 收集并校验当前 Tab 的名称参数，非法时 toast 并返回 null（来源在 prepareSource 处理） */
  async function collectDeploySpec() {
    var gv = function (id) { var el = document.getElementById(id); return el ? String(el.value || '').trim() : ''; };
    var isBatch = DEPLOY_TARGETS.length > 1;
    var sel = document.getElementById('depXDomainWk');   // 项目域名在公共区（Tab 之外），恒用 Wk 系列 id
    var pdMode = (sel && sel.value) || 'default';   // 批量/单账号同构：default/custom，选定模式只决定未登记账号的去向
    var spec = { pdMode: pdMode, syncDomains: [], subDomains: [] };
    var dom = pdMode === 'custom' && !isBatch ? pdCollectDomains('Wk') : { syncDomains: [], subDomains: [] };
    spec.syncDomains = dom.syncDomains;
    spec.subDomains = dom.subDomains;
    if (pdMode === 'custom' && isBatch) {
      spec.syncPrefix = pdCollectPrefix('depSyncWk', 'sync');   // 同步域前缀，主域段按各账号生成
      spec.subPrefix = pdCollectPrefix('depSubWk', '*');   // 订阅域前缀，* = 通配不生成
    }
    // Worker 参数（Worker 链账号用）
    var workerName = gv('depWkName'), d1Name = gv('depWkD1');
    if (!/^[a-zA-Z0-9_-]{1,58}$/.test(workerName)) { showToast('项目名不合法（字母/数字/连字符/下划线，≤58）', true); return null; }
    if (!d1Name) { showToast('请填写 D1 数据库名', true); return null; }
    var d1Changed = DEPLOY_TARGETS.some(function (id) { var d = deployRec(cfById(id)).d1; return d && d !== d1Name; });
    if (d1Changed && !(await themeConfirm('D1 数据库名与上次部署不同：将绑定新建的空库，节点配置会回落默认值（部署后推送配置即恢复），是否继续？', 'D1 数据库变更', { okText: '是否继续' }))) return null;
    spec.workerName = workerName;
    spec.d1Name = d1Name;
    // Pages 参数（Pages 链账号用，批量混合路由时与 Worker 参数并存）
    var project = gv('depPgName').toLowerCase(), pgD1 = gv('depPgD1');
    if (!/^[a-z0-9](?:[a-z0-9-]{0,56}[a-z0-9])?$/.test(project)) { showToast('项目名不合法（小写字母/数字/连字符）', true); return null; }
    if (!pgD1) { showToast('请填写 Pages 的 D1 数据库名', true); return null; }
    spec.project = project;
    spec.branch = gv('depPgBranch') || 'main';
    spec.projectD1 = pgD1;
    return spec;
  }
  /** 读取指定 Pane 的域名编辑框（换行/逗号分隔，空行与 * 通配、生产域不收集），仅自定义模式调用 */
  function pdCollectDomains(sid) {
    var parse = function (id) {
      var el = document.getElementById(id);
      return el ? el.value.split(/[\r\n|,，]+/).map(function (s) { return s.trim(); }).filter(function (h) { return h && isBindableHost(h); }) : [];
    };
    return { syncDomains: parse('depSync' + sid), subDomains: parse('depSub' + sid) };
  }
  /** 批量模式提取域名前缀（编辑框值第一段，非法回落 def） */
  function pdCollectPrefix(id, def) {
    var el = document.getElementById(id);
    var first = el && el.value.trim() ? el.value.trim().split(/[\r\n|,，]+/)[0].split('.')[0] : '';
    return /^[a-zA-Z0-9-]+$/.test(first) ? first.toLowerCase() : def;
  }
  /** 直链经主后端代拉（绕开 CORS），返回 Uint8Array */
  async function fetchUrlBytes(url) {
    var r = await LiteAPI.deploy({ action: 'fetch-url', url: url });
    if (!r) throw new Error('网络请求失败');
    if (!r.success) throw new Error(r.error || '直链拉取失败');
    var bin = atob(r.base64), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }
  /** zip/文件夹条目 → 站点描述：根 _worker.js 为 Functions 入口，其余为资产（hash+base64），主 js 供 Worker 链 */
  function buildSite(items) {
    return new Promise(function (resolve, reject) {
      var rootWorker = null, assets = [];
      items.forEach(function (it) {
        if (it.path === '_worker.js') rootWorker = it;
        else assets.push(it);
      });
      if (assets.length > 1000) return reject(new Error('文件数超过 1000'));
      var enc = new TextEncoder(), out = [], i = 0;
      var fail = function (e) { reject(e); };
      var finish = function () {
        var mainJs = null;
        ['node-worker.js', 'worker.js', 'index.js'].some(function (n) {
          mainJs = assets.filter(function (a) { return (a.path.split('/').pop() || '').toLowerCase() === n; })[0] || null;
          return !!mainJs;
        });
        if (!mainJs && rootWorker) mainJs = rootWorker;
        var rootWorkerB64 = null, mainJsText = null;
        var tasks = [];
        if (rootWorker) tasks.push((rootWorker.file ? fileB64(rootWorker.file) : rootWorker.entry.async('base64')).then(function (v) { rootWorkerB64 = v; }));
        if (mainJs) tasks.push((mainJs.file ? readAsText(mainJs.file) : mainJs.entry.async('string')).then(function (v) { mainJsText = v; }));
        Promise.all(tasks).then(function () {
          if (rootWorkerB64 && rootWorkerB64.length > 14 * 1024 * 1024) return reject(new Error('_worker.js 超过 10MB'));
          if (!out.length && !rootWorkerB64) return reject(new Error('没有可部署的文件'));
          resolve({ assets: out, rootWorkerB64: rootWorkerB64, mainJs: mainJsText });
        }, fail);
      };
      var next = function () {
        if (i >= assets.length) return finish();
        var it = assets[i++];
        var afterBuf = function (buf, b64) {
          if (buf.byteLength > 10 * 1024 * 1024) return fail(new Error('文件超过 10MB：/' + it.path));
          var hasher = new SparkMD5.ArrayBuffer();
          hasher.append(buf);
          hasher.append(enc.encode('/' + it.path).buffer);
          var hash = hasher.end();
          Promise.resolve(b64).then(function (v) {
            out.push({ path: '/' + it.path, hash: hash, base64: v, contentType: deployMime(it.path) });
            next();
          }, fail);
        };
        if (it.file) it.file.arrayBuffer().then(function (buf) { afterBuf(buf, fileB64(it.file)); }, fail);
        else it.entry.async('arraybuffer').then(function (buf) { afterBuf(buf, it.entry.async('base64')); }, fail);
      };
      next();
    });
  }
  /** 来源预处理：直链/编辑框/上传统一为 {kind:'text',text} 或 {kind:'site',assets,rootWorkerB64,mainJs} */
  async function prepareSource() {
    var mode = (document.querySelector('input[name="depSrc"]:checked') || {}).value || 'url';
    var gv = function (id) { var el = document.getElementById(id); return el ? String(el.value || '').trim() : ''; };
    if (mode === 'text') {
      var text = document.getElementById('depText').value;
      if (!text.trim()) throw new Error('请粘贴 Worker 源码');
      return { kind: 'text', text: text };
    }
    if (mode === 'url') {
      var url = gv('depUrl');
      if (!/^https:\/\//i.test(url)) throw new Error('请填写 https 开头的直链');
      var bytes = await fetchUrlBytes(url);
      if (isZipBytes(bytes) || /\.zip($|\?)/i.test(url)) return buildSiteFromZip(bytes);
      return { kind: 'text', text: new TextDecoder().decode(bytes) };
    }
    var f = (document.getElementById('depFile').files || [])[0];
    if (!f) throw new Error('请选择 .js 或 .zip 文件');
    if (/\.zip$/i.test(f.name)) return buildSiteFromZip(new Uint8Array(await f.arrayBuffer()));
    var text2 = await readAsText(f);
    if (!text2.trim()) throw new Error('文件内容为空');
    return { kind: 'text', text: text2 };
  }
  /** zip 字节 → 站点条目（剥顶层目录、滤隐藏与 __MACOSX）→ buildSite */
  async function buildSiteFromZip(bytes) {
    var ok = await new Promise(function (r) { loadDeployLibs(r); });
    if (!ok) throw new Error('解析组件加载失败，请检查网络');
    var zip = await JSZip.loadAsync(bytes);
    var items = [];
    zip.forEach(function (path, entry) {
      if (entry.dir || !deployPathOk(path)) return;
      items.push({ path: path, file: null, entry: entry });
    });
    if (!items.length) throw new Error('压缩包里没有可部署的文件');
    var hasSub = items.some(function (it) { return it.path.indexOf('/') !== -1; });
    var roots = {};
    items.forEach(function (it) { roots[it.path.split('/')[0]] = 1; });
    if (hasSub && Object.keys(roots).length === 1) {
      items.forEach(function (it) { it.path = it.path.split('/').slice(1).join('/'); });
    }
    items = items.filter(function (it) { return it.path; });
    return buildSite(items);
  }
  /** 分片：单请求 ≤8 文件且 base64 总量 ≤10MB（规避免费版 CPU 与请求体限制） */
  function chunkPagesFiles(files) {
    var chunks = [], cur = [], size = 0;
    for (var i = 0; i < files.length; i++) {
      var sz = files[i].base64.length + 512;
      if (cur.length && (cur.length >= 8 || size + sz > 10 * 1024 * 1024)) { chunks.push(cur); cur = []; size = 0; }
      cur.push(files[i]); size += sz;
    }
    if (cur.length) chunks.push(cur);
    return chunks;
  }
  /** 单账号执行：七步统一骨架（初始化→上传资产→创建部署→绑定数据库→绑定域名→推送配置→项目预览），详情按链路填充 */
  async function deployRunOne(id, spec) {
    var st = DEPLOY_STATE[id];
    st.t0 = Date.now();
    DEPLOY_SEL = id;
    // 部署方式路由：单账号按所选 Tab，批量按各账号部署记录（有 Worker 走 Worker，仅 Pages 走 Pages，无记录按 Tab）
    var isPages, isSnippet = String(cfById(id)?.deployType || '') === 'snippet';
    if (DEPLOY_TARGETS.length > 1) {
      var rec0 = deployRec(cfById(id));
      isPages = !rec0.worker && !!rec0.project ? true : (rec0.worker ? false : DEPLOY_TAB === 'pages');
    } else {
      isPages = DEPLOY_TAB === 'pages';
    }
    var secs = function () { return (Math.round((Date.now() - st.t0) / 100) / 10) + 's'; };
    var pause = function () { return new Promise(function (r2) { setTimeout(r2, 180); }); };   // 步骤回放节奏，两链共用
    try {
      if (isSnippet) {
        // Snippets 账号：不在面板部署（脚本在 CF 控制台 Snippets 手动部署），配置由子端每 5 分钟自动拉取
        depStepDone(id, 1, 'Snippets 手动部署 · 无需面板操作');
        depStepDone(id, 2, '—'); depStepDone(id, 3, '—'); depStepDone(id, 4, '—');
        depStepDone(id, 5, '—'); depStepDone(id, 6, '≤5 分钟自动拉取'); depStepDone(id, 7, '—');
        DEPLOY_RESULTS[id] = 'ok';
        return;
      }
      if (!isPages) {
        depStepRun(id, 1, '校验 D1 数据库 · ' + spec.d1Name + '…');
        var text = spec.src.kind === 'text' ? spec.src.text : spec.src.mainJs;
        if (!text) throw new Error('该来源不含可部署的 Worker 脚本（zip 主文件缺失）');
        // 自定义域判定：批量按选定模式（已登记的沿用登记值并绑定，未登记的按 default/custom 走），
        // 单账号按编辑框 > 账号已登记 > 自动生成（编辑框显式填写才登记）
        var syncs = [], subs = [], pdCustom = false;
        var acc = cfById(id) || {};
        var regSync = (acc.syncDomains || []).filter(isBindableHost);
        var regSubs = (acc.domains || []).filter(isBindableHost);
        if (DEPLOY_TARGETS.length > 1) {
          // 选定模式只决定未登记账号的去向，已登记的一律沿用登记值并绑定
          syncs = regSync.slice();
          subs = regSubs.slice();
          pdCustom = syncs.length > 0 || spec.pdMode === 'custom';
          if (spec.pdMode === 'custom') {
            // 未登记 + 自定义档：按前缀生成，主域逐账号查 zone
            var subPfx = spec.subPrefix && spec.subPrefix !== '*' ? spec.subPrefix : '';
            if (!syncs.length || (subPfx && !subs.length)) {
              var zr = await LiteAPI.deploy({ action: 'list-zones', accountId: id });
              var zones = (zr && zr.zones) || [];
              var zone = (zones.filter(function (z) { return z.status === 'active'; })[0] || zones[0] || {}).name || '';
              if (zone) {
                if (!syncs.length) syncs = [(spec.syncPrefix || 'sync') + '.' + zone];
                if (subPfx && !subs.length) subs = [subPfx + '.' + zone];
              } else if (!syncs.length) {
                pdCustom = false;   // 账号无接入域名，生成落空，回落默认域名部署
              }
            }
          }
        } else if (spec.pdMode === 'custom') {
          pdCustom = true;
          syncs = spec.syncDomains && spec.syncDomains.length ? spec.syncDomains.slice() : regSync.slice();
          subs = spec.subDomains && spec.subDomains.length ? spec.subDomains.slice() : regSubs.slice();
          if (!syncs.length) {   // 编辑框与登记均无同步域时才查 zone 生成（订阅生成域名不自动生成：显式填写才登记）
            var zr2 = await LiteAPI.deploy({ action: 'list-zones', accountId: id });
            var zones2 = (zr2 && zr2.zones) || [];
            var zone2 = (zones2.filter(function (z) { return z.status === 'active'; })[0] || zones2[0] || {}).name || '';
            if (zone2) syncs = ['sync.' + zone2];
            else pdCustom = false;   // 账号无接入域名，生成落空，回落默认域名部署
          }
        }
        var r = await LiteAPI.deploy({ action: 'deploy-worker', accountId: id, workerName: spec.workerName, d1Name: spec.d1Name, source: { type: 'text', text: text }, syncDomains: syncs, subDomains: subs });
        if (!r) throw new Error('网络请求失败');
        if (!r.success) throw new Error(r.error || '部署失败');
        depStepDone(id, 1, spec.d1Name + ' · ' + (r.d1.created ? '已新建' : '已存在，复用') + ' · ' + secs());
        depStepRun(id, 2, '子后端脚本上传中…');
        await pause();
        depStepDone(id, 2, '子后端脚本 · ' + Math.max(1, Math.round(text.length / 1024)) + ' KB');
        depStepRun(id, 3, '创建子后端…');
        await pause();
        depStepDone(id, 3, '已创建 · ' + secs());
        depStepRun(id, 4, '绑定 D1 · ' + spec.d1Name + '…');
        await pause();
        depStepDone(id, 4, spec.d1Name + ' · 已绑定');
        // 自定义域名绑定（各账号各自的域，CF 自动管 DNS）
        if (pdCustom) {
          depStepRun(id, 5, '绑定传输域…');
          var hosts = syncs.concat(subs).filter(isBindableHost);
          await Promise.all(hosts.map(function (h) {
            var isSync = syncs.indexOf(h) !== -1;   // 同步域：DNS 指向生产域 + 路由；订阅生成域：仅路由（DNS 由用户自指优选）
            return LiteAPI.deploy({ action: 'add-worker-domain', accountId: id, hostname: h, workerName: spec.workerName, dns: isSync }).then(function (bd) {
              if (!bd || !bd.success) throw new Error((bd && bd.error) || '绑定传输域失败：' + h + '（重试部署可自动恢复）');
              return bd;
            });
          }));
          depStepDone(id, 5, hosts.join(' / '));
          var accLocal = cfById(id);   // 已用域名回写内存账号（库内由 deploy-worker 持久化），账号编辑框不再显示为空
          if (accLocal) {
            if (syncs.length) accLocal.syncDomains = syncs.slice();
            if (subs.length) accLocal.domains = subs.slice();
            cfRender();
          }
        } else {
          depStepDone(id, 5, '默认域名 · workers.dev');
        }
        if (pdCustom) r.push = await LiteAPI.deploy({ action: 'push-config', accountId: id }).catch(function () { return { total: 0, ok: [], versions: {} }; });   // 内建推送早于绑定执行：绑定完成补推，推送状态真实回显
        var versions = r.push && r.push.versions ? Object.keys(r.push.versions).map(function (d) { return r.push.versions[d]; }) : [];
        var okN = r.push && r.push.ok ? (Array.isArray(r.push.ok) ? r.push.ok.length : r.push.ok) : 0;   // 旧主后端 ok 为计数，新版为数组
        depStepRun(id, 6, r.push ? '推送节点配置…' : '—');
        await pause();
        depStepDone(id, 6, r.push ? (okN ? okN + ' 个同步域名' + (versions[0] ? ' · 子端 ' + versions[0] : '') : '推送失败') : '—');
        depStepRun(id, 7, '获取项目预览…');
        await pause();
        // 项目预览：自定义模式显示绑定的自定义域（自动域），默认模式显示 workers.dev 域
        st.url = (pdCustom && hosts.length) ? 'https://' + hosts[0] : (r.previewUrl || '');
        depStepDone(id, 7, st.url || '—');
        DEPLOY_RESULTS[id] = 'ok';
        recordDeployLocal(id, { worker: spec.workerName, d1: spec.d1Name });
        // 域名回写本地：跟随部署模式
        var accLocal = cfById(id);
        if (accLocal) {
          var finalSyncs = (pdCustom && syncs.length) ? syncs.slice() : (st.url ? [st.url] : (Array.isArray(accLocal.syncDomains) ? accLocal.syncDomains.slice() : []));
          if (pdCustom && subs.length) accLocal.domains = subs.slice();
          accLocal.syncDomains = sortSyncDomains(finalSyncs);
          cfRender();
        }
        // 模式切换：移除旧 Pages 项目（D1 保留）
        if (DEPLOY_TARGETS.length === 1) {
          var recNow = deployRec(cfById(id));
          if (recNow.project) {
            var rc = await LiteAPI.deploy({ action: 'remove-deployment', accountId: id, keep: 'worker' });
            if (rc && rc.success) {
              var inf = deployRec(cfById(id));
              delete inf.project;
              cfById(id).deployInfo = JSON.stringify(Object.assign(inf, { lastMode: 'worker' }));
              cfRender();
            } else showToast('旧 Pages 项目清理失败，可稍后手动删除', true);
          }
        }
        return;
      }
      depStepRun(id, 1, '获取项目列表…');
      var files = [], workerB64 = null;
      if (spec.src.kind === 'text') workerB64 = textB64(spec.src.text);   // 编辑框/单 js：作为 Functions 入口
      else { files = spec.src.assets; workerB64 = spec.src.rootWorkerB64; }
      var lst = await LiteAPI.deploy({ action: 'list-pages', accountId: id });
      if (!lst) throw new Error('网络请求失败');
      if (!lst.success) throw new Error(lst.error || '获取项目列表失败');
      var rec = deployRec(cfById(id));
      // 未手动改名：记录优先，产品前缀项目兜底（记录丢失时仍能找到本工具的项目），
      // 手动改名 = 显式指定目标：只精确匹配同名，没有就新建，不扫前缀
      var want = (DEPLOY_PG_DIRTY ? spec.project : rec.project || spec.project).toLowerCase();
      var names = (lst.projects || []).map(function (p) { return String(p.name || '').toLowerCase(); })
        .filter(DEPLOY_PG_DIRTY ? function (n) { return n === want; }
          : function (n) { return n === want || n.indexOf(DeployPgPrefix + '-') === 0; });
      if (!names.length) names = [want];
      // 一个账号只部署一个项目：多命中（历史遗留）收敛到优先目标，避免同域绑定互相抢占
      if (names.length > 1) {
        var prefer = want;
        if (names.indexOf(prefer) === -1) prefer = names[0];
        names = [prefer];
      }
      var lastUrl = '', projectName = want;
      for (var pi = 0; pi < names.length; pi++) {
        projectName = names[pi];
        depStepRun(id, 1, '项目 ' + projectName + ' · 初始化…');   // 列表匹配与初始化合并为一步的运行过程，不提前打✓
        var init = await LiteAPI.deploy({ action: 'pages-init', accountId: id, project: projectName, branch: spec.branch, d1Name: spec.projectD1 });
        if (!init) throw new Error('网络请求失败');
        if (!init.success) throw new Error(init.error || '初始化失败');
        projectName = init.project || projectName;   // 后端冲突改名后的实际名
        var branch = String(init.branch || spec.branch);   // 对齐项目现有生产分支，防误建预览部署
        st.infs[3] = spec.projectD1 + ' · ' + (init.d1 && init.d1.created ? '已新建' : '已绑定');   // ④ 数据初始化时已定，展示在后置步骤
        depStepDone(id, 1, '项目 ' + projectName + ' · ' + secs());
        var total = files.length, doneN = 0;
        var chunks = chunkPagesFiles(files);
        depStepRun(id, 2, total ? '0 / ' + total + ' 文件' : '子后端脚本部署（无静态资产）');
        for (var ci = 0; ci < chunks.length; ci++) {
          depStepRun(id, 2, doneN + ' / ' + total + ' 文件');
          var up = null;
          for (var att = 0; att < 3; att++) {   // 大 body 分片在大陆链路易抖动：网络失败重试，业务错误直抛
            if (att) { await new Promise(function (r2) { setTimeout(r2, 1200 * att); }); depStepRun(id, 2, '重试 ' + att + '/2 · ' + doneN + ' / ' + total + ' 文件'); }
            up = await LiteAPI.deploy({ action: 'pages-upload', uploadToken: init.uploadToken, files: chunks[ci] });
            if (up && up.error) throw new Error(up.error);
            if (up && up.success) break;
          }
          if (!up || !up.success) throw new Error('网络请求失败（已重试 2 次）');
          doneN += chunks[ci].length;
          depStepRun(id, 2, doneN + ' / ' + total + ' 文件');
        }
        depStepDone(id, 2, total ? total + ' / ' + total + ' 文件' : '子后端脚本部署（无静态资产）');
        // 域名计算前置：批量按选定模式，单账号按编辑框 > 登记 > 自动生成；commit 推送需读到新目标
        var syncs = [], subs = [], hosts = [], pdCustom = false;
        var acc = cfById(id) || {};
        var regSync = (acc.syncDomains || []).filter(isBindableHost);
        var regSubs = (acc.domains || []).filter(isBindableHost);
        if (DEPLOY_TARGETS.length > 1) {
          // 选定模式只决定未登记账号的去向，已登记的一律沿用登记值并绑定
          syncs = regSync.slice();
          subs = regSubs.slice();
          pdCustom = syncs.length > 0 || spec.pdMode === 'custom';
          if (spec.pdMode === 'custom') {
            // 未登记 + 自定义档：按前缀生成，主域逐账号查 zone
            var subPfx = spec.subPrefix && spec.subPrefix !== '*' ? spec.subPrefix : '';
            if (!syncs.length || (subPfx && !subs.length)) {
              var zr = await LiteAPI.deploy({ action: 'list-zones', accountId: id });
              var zones = (zr && zr.zones) || [];
              var zone = (zones.filter(function (z) { return z.status === 'active'; })[0] || zones[0] || {}).name || '';
              if (zone) {
                if (!syncs.length) syncs = [(spec.syncPrefix || 'sync') + '.' + zone];
                if (subPfx && !subs.length) subs = [subPfx + '.' + zone];
              } else if (!syncs.length) {
                pdCustom = false;   // 账号无接入域名，生成落空，回落默认域名部署
              }
            }
          }
        } else if (spec.pdMode === 'custom') {
          pdCustom = true;
          syncs = spec.syncDomains && spec.syncDomains.length ? spec.syncDomains.slice() : regSync.slice();
          subs = spec.subDomains && spec.subDomains.length ? spec.subDomains.slice() : regSubs.slice();
          if (!syncs.length) {   // 编辑框与登记均无同步域时才查 zone 生成（订阅生成域名不自动生成：显式填写才登记）
            var zr = await LiteAPI.deploy({ action: 'list-zones', accountId: id });
            var zones = (zr && zr.zones) || [];
            var zone = (zones.filter(function (z) { return z.status === 'active'; })[0] || zones[0] || {}).name || '';
            if (zone) syncs = ['sync.' + zone];
            else pdCustom = false;   // 账号无接入域名，生成落空，回落默认域名部署
          }
        }
        if (pdCustom && syncs.length) {
          var pr = await LiteAPI.deploy({ action: 'persist-page-domains', accountId: id, syncDomains: syncs, subDomains: subs });
          if (!pr || !pr.success) throw new Error('同步域名登记失败（推送目标未更新）');
        }
        hosts = pdCustom ? syncs.concat(subs).filter(isBindableHost) : [];
        depStepRun(id, 3, '创建部署…');
        var manifest = {};
        files.forEach(function (f) { manifest[f.path] = f.hash; });
        var c = null;
        for (var ct = 0; ct < 3; ct++) {   // commit 携带 worker 脚本 base64，同样加重试
          if (ct) { await new Promise(function (r2) { setTimeout(r2, 1200 * ct); }); depStepRun(id, 3, '重试 ' + ct + '/2 · 创建部署…'); }
          c = await LiteAPI.deploy({ action: 'pages-commit', accountId: id, project: projectName, branch: branch, uploadToken: init.uploadToken, manifest: manifest, worker: workerB64, defaultMode: !pdCustom });
          if (c && c.error) throw new Error(c.error);
          if (c && c.success) break;
        }
        if (!c || !c.success) throw new Error('创建部署失败（网络已重试 2 次）');   // 默认模式：后端将生产域设为唯一同步域名
        depStepDone(id, 3, '已创建 · ' + secs());
        depStepRun(id, 4, st.infs[3] || '绑定数据库…');   // D1 已在初始化时绑定，此处补运行过程
        await new Promise(function (r2) { setTimeout(r2, 180); });
        depStepDone(id, 4, st.infs[3]);
        depStepRun(id, 5, pdCustom ? '绑定自定义域…' : '默认域名 · pages.dev');
        lastUrl = 'https://' + projectName + '.pages.dev';   // 生产域，dep.url 是带 hash 的部署快照预览，不作展示
        // 此处仅执行绑定（域名已在 commit 前持久化）
        if (pdCustom) {
          await Promise.all(hosts.map(function (h) {
            return LiteAPI.deploy({ action: 'add-page-domain', accountId: id, domain: h, project: projectName }).then(function (bp) {
              if (!bp || !bp.success) throw new Error((bp && bp.error) || '绑定 Pages 域名失败：' + h + '（重试部署可自动恢复）');
              return bp;
            });
          }));
          if (hosts.length) lastUrl = 'https://' + hosts[0];   // 项目预览显示绑定的自定义域
          depStepDone(id, 5, hosts.join(' / '));
        } else {
          depStepDone(id, 5, '默认域名 · pages.dev');
        }
        depStepRun(id, 6, '推送节点配置…');
        var pc = pdCustom ? await LiteAPI.deploy({ action: 'push-config', accountId: id }).catch(function () { return { ok: [] }; }) : null;   // commit 内建推送早于绑定：绑定完成重推
        await pause();
        st.url = lastUrl;
        DEPLOY_RESULTS[id] = 'ok';
        depStepDone(id, 6, pc ? ((pc.ok && pc.ok.length) ? pc.ok.length + ' 个同步域名' : '推送失败') : '项目更新完成 · ' + secs());
        depStepDone(id, 7, lastUrl);
        recordDeployLocal(id, { project: projectName, d1: spec.projectD1 });   // 记录绑定关系：D1 提示按记录动态判断「已绑定/自动创建」
        // 域名回写本地：跟随部署模式
        if (pdCustom || lastUrl) {
          var accLocal = cfById(id);
          if (accLocal) {
            var finalSyncs = (pdCustom && syncs.length) ? syncs.slice() : (lastUrl ? [lastUrl] : (Array.isArray(accLocal.syncDomains) ? accLocal.syncDomains.slice() : []));
            if (pdCustom && subs.length) accLocal.domains = subs.slice();
            accLocal.syncDomains = sortSyncDomains(finalSyncs);
            cfRender();
          }
        }
        // 模式切换：移除旧 Worker（域/脚本，D1 保留）
        if (DEPLOY_TARGETS.length === 1) {
          var recNow2 = deployRec(cfById(id));
          if (recNow2.worker) {
            var rc2 = await LiteAPI.deploy({ action: 'remove-deployment', accountId: id, keep: 'pages' });
            if (rc2 && rc2.success) {
              var inf2 = deployRec(cfById(id));
              delete inf2.worker;
              cfById(id).deployInfo = JSON.stringify(Object.assign(inf2, { lastMode: 'pages' }));
              cfRender();
            } else showToast('旧 Worker 清理失败，可稍后手动删除', true);
          }
        }
      }
    } catch (e) {
      depStepFail(id, st.cur >= 0 ? st.cur + 1 : 1, e.message || String(e));
      DEPLOY_RESULTS[id] = 'fail';
    }
  }
  window.deployStartClick = function () { runDeploy(); };
  /** 批量执行器：逐账号顺序、失败隔离、停止（当前账号完成后生效） */
  async function runDeploy() {
    if (DEPLOY_RUNNING) { DEPLOY_STOP = true; showToast('将在当前账号完成后停止'); return; }
    var ids = DEPLOY_TARGETS;
    if (!ids.length) { showToast('没有可部署的账号', true); return; }
    DEPLOY_RESULTS = {};
    // 表单弹窗还在（首次）→ 现场收集，只剩状态弹窗（重试/重新部署）→ 用部署时的参数快照
    var spec = document.getElementById('deployModal') ? await collectDeploySpec() : DEPLOY_LAST_SPEC;
    if (!spec) return;
    // Snippets 账号不在面板部署：脚本在 CF 控制台手动部署，配置由子端自动拉取
    if (ids.length === 1) {
      var acc0 = cfById(ids[0]);
      if (acc0 && String(acc0.deployType || '') === 'snippet') {
        showToast('Snippets 账号请在 Cloudflare 控制台手动部署，配置将自动拉取', true);
        return;
      }
    }
    // 模式切换明示：主题弹窗确认后继续
    var proceedDeploy = function () {
      // 账号未登记同步域名时直接部署：自定义模式会按 CF 域名自动生成并写回，无需阻断确认
      var noSync = DEPLOY_TARGETS.some(function (id) { var a = cfById(id); return !a || !Array.isArray(a.syncDomains) || !a.syncDomains.length; });
      if (noSync && DEPLOY_TARGETS.length === 1) showToast('未登记同步域名，将按账号 CF 域名自动生成', true);
      runDeployProceed(spec, ids);
    };
    // 模式切换确认仅单账号需要：批量按各账号部署记录路由、不移除任何项目，无需确认
    if (DEPLOY_TARGETS.length === 1) {
      var recPre = deployRec(cfById(DEPLOY_TARGETS[0]));
      var switching = (DEPLOY_TAB === 'worker' && recPre.project) || (DEPLOY_TAB === 'pages' && recPre.worker);
      if (switching) {
        var removed = DEPLOY_TAB === 'worker' ? 'Pages 项目' : 'Worker 及其域名绑定';
        window.__showConfirm(
          '本次部署将移除账号里已有的 ' + removed + '（D1 数据保留），并清理其域名的 DNS 解析记录，是否继续？',
          proceedDeploy,
          '模式切换确认',
          { okText: '确定', cancelText: '取消' }
        );
        return;
      }
    }
    proceedDeploy();
  }

  /** 确认后实际执行部署（ids 为本轮要执行的目标） */
  async function runDeployProceed(spec, ids) {
    var startBtn = document.getElementById('depStartBtn');
    if (!spec.src) {
      startBtn.disabled = true; startBtn.textContent = '准备来源…';
      try { spec.src = await prepareSource(); }
      catch (e) { startBtn.disabled = false; startBtn.textContent = '开始部署'; showToast(e.message || String(e), true); return; }
      if (!document.getElementById('deployModal')) return;   // 来源准备期间表单弹窗已关：放弃本轮
      DEPLOY_LAST_SPEC = spec;   // 快照：状态弹窗下的重试 / 重新部署复用
    }
    startBtn.disabled = false; startBtn.textContent = '开始部署';
    DEPLOY_RUNNING = true; DEPLOY_STOP = false;
    startBtn.textContent = '停止';
    document.getElementById('depCancelBtn').style.display = 'none';
    lockDeployParams(true);
    var mc = document.querySelector('#deployModal .modal-content');
    if (mc) mc.classList.add('deploying');   // 执行视图：隐藏表单区，详情占满
    var body = document.getElementById('depBody');
    body.style.display = 'flex';
    body.classList.toggle('single', DEPLOY_TARGETS.length === 1);
    // 独立部署状态弹窗：dep-body 整体搬入
    var formModal = document.getElementById('deployModal');
    if (formModal) {
      var foot = formModal.querySelector('.modal-footer');
      var sm = document.createElement('div');
      sm.className = 'modal show';
      sm.id = 'deployStatusModal';
      sm.onclick = function (e) { if (e.target === sm) closeDeployModal(); };
      sm.innerHTML = '<div class="modal-content modal-lg dep-modal deploying" onclick="event.stopPropagation()">' +
        '<div class="modal-header"><h3>部署状态</h3><button class="modal-close" onclick="closeDeployModal()">×</button></div>' +
        '<div class="modal-body"></div>' +
        '<div class="modal-footer">' + (foot ? foot.innerHTML : '') + '</div></div>';
      sm.querySelector('.modal-body').appendChild(document.getElementById('depBody'));
      document.body.appendChild(sm);
      formModal.remove();
      startBtn = document.getElementById('depStartBtn') || startBtn;   // 页脚已整体搬入状态弹窗，重取引用（旧节点随表单弹窗销毁）
    }
    depStateInit(ids);
    depRenderList();
    depRenderDetail();
    if (DEPLOY_TICK) clearInterval(DEPLOY_TICK);
    DEPLOY_TICK = setInterval(function () { if (DEPLOY_RUNNING) depRenderDetail(); }, 1000);
    for (var i = 0; i < ids.length; i++) {
      if (DEPLOY_STOP) {
        ids.slice(i).forEach(function (id) {
          var st = DEPLOY_STATE[id];
          if (st) { st.cur = -1; st.infs[Math.min(st.done, DEPLOY_STEPS.length - 1)] = '已跳过'; }
          DEPLOY_RESULTS[id] = 'skip';
        });
        depRenderList(); depRenderDetail();
        break;
      }
      await deployRunOne(ids[i], spec);
    }
    DEPLOY_RUNNING = false;
    lockDeployParams(false);
    var okN = 0, failN = 0;
    DEPLOY_TARGETS.forEach(function (id) {
      if (DEPLOY_RESULTS[id] === 'ok') okN++;
      else if (DEPLOY_RESULTS[id] === 'fail') failN++;
    });
    if (!document.getElementById('deployStatusModal')) return;   // 状态弹窗已关（中途停止）：结果留在 DEPLOY_RESULTS，不再更新界面
    document.getElementById('depFootStatus').textContent = '部署完成：成功 ' + okN + ' / 失败 ' + failN + ' / 共 ' + DEPLOY_TARGETS.length;
    startBtn.textContent = '重新部署';
    document.getElementById('depCancelBtn').style.display = '';
    document.getElementById('depCancelBtn').textContent = '关闭';
    if (DEPLOY_TICK) { clearInterval(DEPLOY_TICK); DEPLOY_TICK = null; }
    showToast('部署完成：成功 ' + okN + ' / 失败 ' + failN, failN > 0);
  }

  // ============ 数据看板（真实数据：/api/status 状态六格 + 激活账号 GraphQL 用量三环） ============
  var DASH_STATUS = null;
  if (window.LiteAPI) {
    LiteAPI.getStatus().then(function (s) {
      if (s) {
        DASH_STATUS = s;
        applyDashStatus(DASH_STATUS);
        fillSystemBar(DASH_STATUS);
      }
    }).catch(function () {});
  }
  // 后端状态六格：基础（节点域名/伪装）→ 节点（模式/状态）→ 反代（模式/状态）
  function applyDashStatus(s) {
    var view = document.getElementById('view-dashboard');
    if (!view) return;
    var vals = view.querySelectorAll('.backend-field-value');
    if (!s) {
      vals.forEach(function (el) { el.textContent = '—'; });
      return;
    }
    [
      s.subHost || '未配置',
      s.fakePage ? '已开启' : '已关闭',
      inboundLabel(s.inbound),
      s.speedConfigured ? '正常' : '未配置',
      proxyModeLabel(s.proxyMode),
      (String(s.proxyMode || '').toUpperCase() === 'AUTO' || s.proxyConfigured) ? '正常' : '未配置'
    ].forEach(function (v, i) { if (vals[i]) vals[i].textContent = v; });
  }
  // 三环 + 配额进度卡：u 为空时保持零值并提示绑定账号
  function cfTotalQuota() {
    var total = 0;
    for (var i = 0; i < CF_ACCOUNTS.length; i++) {
      var q = Number(CF_ACCOUNTS[i].quota);
      total += q > 0 ? q : 100000;
    }
    return total > 0 ? total : 100000;
  }
  function renderDashRings(u) {
    var view = document.getElementById('view-dashboard');
    if (!view) return;
    var quota = cfTotalQuota();
    var used = u ? u.used : 0, workers = u ? u.workers : 0, pages = u ? u.pages : 0;
    var totalPct = Math.min(used / quota * 100, 100);
    var wPct = used > 0 ? workers / used * 100 : 0;
    var pPct = used > 0 ? pages / used * 100 : 0;
    // 三只环：日配额 / Workers 占比 / Pages 占比（C=264 与模板 stroke-dasharray 基准一致，r=42）
    var C = 264;
    [totalPct, Math.min(wPct, 100), Math.min(pPct, 100)].forEach(function (pct, i) {
      var item = view.querySelectorAll('.usage-ring-item')[i];
      if (!item) return;
      var fill = item.querySelector('.ring-fill');
      if (fill) fill.setAttribute('stroke-dasharray', (C * pct / 100).toFixed(1) + ' ' + C);
      var pctEl = item.querySelector('.quota-percent');
      if (pctEl) pctEl.textContent = pct.toFixed(1) + '%';
    });
    var ratio = view.querySelectorAll('.usage-progress-ratio span');
    if (ratio.length >= 3) { ratio[0].textContent = cfFmt(used); ratio[2].textContent = cfFmt(quota); }
    var barFill = view.querySelector('.usage-progress-fill');
    if (barFill) barFill.style.width = totalPct.toFixed(1) + '%';
    var tags = view.querySelectorAll('.usage-progress-footer .legend-tag');
    if (tags.length >= 3) {
      tags[0].textContent = u ? ('当前进度：' + totalPct.toFixed(1) + '%') : '绑定 Cloudflare 账号后显示今日用量';
      tags[1].textContent = 'Workers：' + cfFmt(workers) + ' 次';
      tags[2].textContent = 'Pages：' + cfFmt(pages) + ' 次';
    }
  }
  // ============ 网络检测（采样与 IP 情报在 LiteCore，本节只画卡片） ============
  // 国内/国外站点并发延迟测试（8 轮采样取均值），点击卡片查询访问该站点的出口 IP 详情
  var LATENCY_TEST_COUNT = 8;      // 心电图窗口：同屏展示最近 N 次采样
  var NETCHECK_POLL_MS = 1000;     // 轮询间隔：1s 一采样
  var netCheckStarted = false;
  var netCheckInFlight = false;
  var latencySites = [
    { name: '字节跳动', region: '国内', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#1677FF" d="m19.9 1.5 4.1 1v19l-4.1 1zM6.5 10.9l4.1 1v9l-4 1.1zM0 2.6l4.1 1v16.8l-4.1 1zm17.5 5.6v11.1l-4.2-1v-9z"></path></svg>', url: 'https://lf3-zlink-tos.ugurl.cn/obj/zebra-public/resource_lmmizj_1632398893.png' },
    { name: '抖音', region: '国内', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#000" d="M16.75 0C15.78 0 15 .78 15 1.75v12.5c0 2.07-1.68 3.75-3.75 3.75S7.5 16.32 7.5 14.25s1.68-3.75 3.75-3.75c.28 0 .56.03.83.09V8.08c-.28-.03-.55-.08-.83-.08C7.19 8 4 11.19 4 15.25S7.19 22.5 11.25 22.5s7.25-3.19 7.25-7.25V7.76c1.38.88 3.03 1.39 4.75 1.39V6.65c-2.07 0-3.75-1.68-3.75-3.75V1.75C19.5.78 18.72 0 17.75 0z"/></svg>', url: 'https://www.douyin.com/favicon.ico' },
    { name: 'Bilibili', region: '国内', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#FB7299" d="M17.813 4.653h.854q2.266.08 3.773 1.574Q23.946 7.72 24 9.987v7.36q-.054 2.266-1.56 3.773c-1.506 1.507-2.262 1.524-3.773 1.56H5.333q-2.266-.054-3.773-1.56C.053 19.614.036 18.858 0 17.347v-7.36q.054-2.267 1.56-3.76t3.773-1.574h.774l-1.174-1.12a1.23 1.23 0 0 1-.373-.906q0-.534.373-.907l.027-.027q.4-.373.92-.373t.92.373L9.653 4.44q.107.106.187.213h4.267a.8.8 0 0 1 .16-.213l2.853-2.747q.4-.373.92-.373c.347 0 .662.151.929.4s.391.551.391.907q0 .532-.373.906zM5.333 7.24q-1.12.027-1.88.773q-.76.748-.786 1.894v7.52q.026 1.146.786 1.893t1.88.773h13.334q1.12-.026 1.88-.773t.786-1.893v-7.52q-.026-1.147-.786-1.894t-1.88-.773zM8 11.107q.56 0 .933.373q.375.374.4.96v1.173q-.025.586-.4.96q-.373.375-.933.374c-.56-.001-.684-.125-.933-.374q-.375-.373-.4-.96V12.44q0-.56.386-.947q.387-.386.947-.386m8 0q.56 0 .933.373q.375.374.4.96v1.173q-.025.586-.4.96q-.373.375-.933.374c-.56-.001-.684-.125-.933-.374q-.375-.373-.4-.96V12.44q.025-.586.4-.96q.373-.373.933-.373"></path></svg>', url: 'https://i0.hdslb.com/bfs/face/member/noface.jpg@24w_24h_1c' },
    { name: '微信', region: '国内', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#09B83E" d="M8.7 2.19C3.9 2.19 0 5.48 0 9.53c0 2.21 1.17 4.2 3 5.55a.6.6 0 0 1 .21.66l-.39 1.48q-.03.11-.04.22c0 .16.13.3.29.3a.3.3 0 0 0 .16-.06l1.9-1.11a.9.9 0 0 1 .72-.1 10 10 0 0 0 2.84.4q.41-.01.81-.05a5.85 5.85 0 0 1 1.93-6.45 8.3 8.3 0 0 1 5.86-1.83c-.58-3.59-4.2-6.35-8.6-6.35m-2.9 3.8c.64 0 1.16.53 1.16 1.18a1.17 1.17 0 0 1-1.16 1.18 1.17 1.17 0 0 1-1.17-1.18c0-.65.52-1.18 1.17-1.18m5.8 0c.65 0 1.17.53 1.17 1.18a1.17 1.17 0 0 1-1.16 1.18 1.17 1.17 0 0 1-1.16-1.18c0-.65.52-1.18 1.16-1.18m5.34 2.87a8 8 0 0 0-5.28 1.78 5.5 5.5 0 0 0-1.78 6.22c.94 2.46 3.66 4.23 6.88 4.23q1.25 0 2.36-.33a.7.7 0 0 1 .6.08l1.59.93.14.04c.13 0 .24-.1.24-.24q-.01-.09-.04-.18l-.33-1.23-.02-.16a.5.5 0 0 1 .2-.4 5.8 5.8 0 0 0 2.5-4.62c0-3.21-2.93-5.84-6.66-6.09zm-2.53 3.27c.53 0 .97.44.97.98a1 1 0 0 1-.97.99 1 1 0 0 1-.97-.99c0-.54.43-.98.97-.98zm4.84 0c.54 0 .97.44.97.98a1 1 0 0 1-.97.99 1 1 0 0 1-.97-.99c0-.54.44-.98.97-.98"></path></svg>', url: 'https://res.wx.qq.com/a/wx_fed/assets/res/NTI4MWU5.ico' },
    { name: '谷歌', region: '国外', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53"/></svg>', url: 'https://www.google.com/favicon.ico' },
    { name: 'Cloudflare', region: '国外', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="#F6821F"><circle cx="8.5" cy="13" r="4"/><circle cx="14.5" cy="11.5" r="5"/><rect x="8" y="11" width="11" height="6" rx="3"/></g></svg>', url: 'https://www.cloudflare.com/favicon.ico' },
    { name: 'ChatGPT', region: '国外', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#10A37F" d="M22.3 8.7c.4-1.8-.1-3.7-1.4-5.1-1.3-1.3-3.2-1.8-5-1.4-1.1-1.5-2.9-2.4-4.9-2.2-2 .1-3.7 1.3-4.6 3-1.8.4-3.3 1.6-4.1 3.3-.8 1.7-.7 3.6.2 5.2-.4 1.8.1 3.7 1.4 5.1 1.3 1.3 3.2 1.8 5 1.4 1.1 1.5 2.9 2.4 4.9 2.2 2-.1 3.7-1.3 4.6-3 1.8-.4 3.3-1.6 4.1-3.3.8-1.7.7-3.6-.2-5.2m-10.3 11c-1.2.1-2.3-.4-3-1.3l.2-.1 5-2.9c.3-.1.4-.4.4-.7V9.3l2.1 1.2v5.2c0 2.2-1.7 4-3.7 4.1M4.5 17.5c-.6-1-.8-2.3-.4-3.4l.2.1 5 2.9c.3.1.6.1.8 0l6.1-3.5v2.4l-5 2.9c-1.9 1.1-4.4.5-5.7-1.4M3.3 8c.6-1 1.6-1.8 2.8-2.1v5.9c0 .3.1.5.4.7l6.1 3.5-2.1 1.2-5-2.9C3.6 13.2 2.2 10.9 3.3 8m16.4 3.7-6.1-3.5 2.1-1.2 5 2.9c1.9 1.1 2.6 3.5 1.5 5.4-.6 1-1.6 1.8-2.8 2.1v-5.9c0-.3-.1-.5-.4-.7m2.1-3.2-.2-.1-5-2.9c-.3-.1-.6-.1-.8 0L9.7 9v-2.4l5-2.9c1.9-1.1 4.4-.5 5.7 1.4.6 1 .8 2.3.4 3.4M9.7 13.3 7.6 12V6.8c0-2.2 1.8-4 4-4 1.2-.1 2.3.4 3 1.3l-.2.1-5 2.9c-.3.1-.4.4-.4.7zm1.1-2.4 2.7-1.6 2.7 1.6v3.2l-2.7 1.6-2.7-1.6z"/></svg>', url: 'https://cdn.oaistatic.com/_next/static/media/apple-touch-icon.59f2e898.png' },
    { name: 'YouTube', region: '国外', icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#FF0000" d="M23.5 6.19a3 3 0 0 0-2.12-2.14c-1.87-.5-9.38-.5-9.38-.5s-7.5 0-9.38.5A3 3 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3 3 0 0 0 2.12 2.14c1.87.5 9.38.5 9.38.5s7.5 0 9.38-.5a3 3 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81M9.55 15.57V8.43L15.82 12z"></path></svg>', url: 'https://www.youtube.com/favicon.ico' }
  ];
  var siteLatencies = {};

  function generateLatencyCards() {
    var container = document.getElementById('latency-cards');
    if (!container) return;
    container.innerHTML = '';
    var sorted = latencySites.slice().sort(function (a, b) { return (a.region === '国内' ? 0 : 1) - (b.region === '国内' ? 0 : 1); });
    sorted.forEach(function (site) {
      var key = site.name.toLowerCase().replace(/\s+/g, '-');
      siteLatencies[key] = [];
      var card = document.createElement('div');
      card.className = 'latency-card';
      card.style.cursor = 'pointer';
      card.addEventListener('click', function () { queryIpForSite(site); });
      card.innerHTML = '<div class="latency-card-title"><div class="latency-card-icon">' + site.icon + '</div><span class="latency-card-name">' + site.name + '</span><div class="latency-value" id="latency-' + key + '">测试中...</div><span class="latency-card-region latency-card-region-' + (site.region === '国内' ? 'domestic' : 'international') + '">' + site.region + '</span></div><div class="latency-card-content"><div class="latency-bars" id="bars-' + key + '">' + Array(LATENCY_TEST_COUNT).fill('<div class="latency-bar loading"></div>').join('') + '</div></div>';
      container.appendChild(card);
    });
  }

  function updateLatencyDisplay(key, latencies) {
    var valueEl = document.getElementById('latency-' + key);
    var barsEl = document.getElementById('bars-' + key);
    if (!valueEl || !barsEl) return;
    var valid = latencies.filter(function (l) { return l !== -1; });
    var avg = valid.length > 0 ? valid.reduce(function (a, b) { return a + b; }, 0) / valid.length : -1;
    valueEl.textContent = avg === -1 ? '-ms' : Math.round(avg) + 'ms';
    valueEl.style.color = getLatencyColor(avg);
    barsEl.querySelectorAll('.latency-bar').forEach(function (bar, i) {
      var l = latencies[i];
      if (l !== undefined) {
        bar.style.backgroundColor = getLatencyColor(l);
        bar.title = l === -1 ? '连接失败' : l + 'ms';
        bar.classList.remove('loading');
      }
    });
  }

  /** 心电图式轮询：每 1s 各站点采一次样，新样本从右侧入列、最旧左移出窗 */
  function pollNetOnce() {
    if (netCheckInFlight || document.hidden) return;
    var view = document.getElementById('view-dashboard');
    var container = document.getElementById('latency-cards');
    if (!view || view.style.display === 'none' || !container) return;
    netCheckInFlight = true;
    Promise.all(latencySites.map(async function (site) {
      var key = site.name.toLowerCase().replace(/\s+/g, '-');
      var l = await testLatency(site);
      var arr = siteLatencies[key] || (siteLatencies[key] = []);
      arr.push(l);
      if (arr.length > LATENCY_TEST_COUNT) arr.shift();
      updateLatencyDisplay(key, arr);
    })).finally(function () { netCheckInFlight = false; });
  }

  function ensureNetCheck() {
    if (netCheckStarted) return;
    netCheckStarted = true;
    generateLatencyCards();          // 首次生成骨架（loading 态采样条）
    pollNetOnce();
    setInterval(pollNetOnce, NETCHECK_POLL_MS);
  }

  // ============ 出口 IP 情报卡片（国内/国外/CloudFlare/墙外，探测取数在 LiteCore） ============
  // 左侧国旗右侧 IP 信息，点击卡片复用 IP 详情弹窗查看该出口完整情报
  var netExitDetails = {};
  var NET_EXIT_DEFS = [
    { id: 'domestic', title: '国内测试', errText: '加载失败', badge: '国内', badgeCls: 'latency-card-region latency-card-region-domestic', probe: function () { return Core.probeDomesticExit(); } },
    { id: 'overseas', title: '国外测试', errText: '加载失败', badge: '国外', badgeCls: 'latency-card-region latency-card-region-international', probe: function () { return Core.probeOverseasExit(); } },
    { id: 'wall', title: '墙外测试', errText: '翻墙未开启', badge: '国外', badgeCls: 'latency-card-region latency-card-region-international', probe: function () { return Core.probeWallExit(); } },
    { id: 'cf', title: 'CloudFlare', errText: '加载失败', badge: 'CF', badgeCls: 'latency-card-region latency-card-region-cf', probe: function () { return Core.probeCfExit(); } }
  ];

  function setNetExitState(id, state, ipText, locText) {
    var card = document.getElementById('netexit-' + id);
    if (!card) return;
    var ipEl = card.querySelector('.net-exit-ip');
    var locEl = card.querySelector('.net-exit-loc');
    if (ipEl) { ipEl.textContent = ipText; ipEl.classList.toggle('error', state === 'error'); }
    if (locEl) locEl.textContent = locText || '';
    var flag = card.querySelector('.net-exit-flag');
    if (flag && state !== 'success') flag.style.backgroundImage = '';   // 非成功态清掉旧国旗
  }

  /** 角标固定用卡片定义的文案（国内/国外/CF），不随 IP 版本变化 */
  function setNetExitBadge(def) {
    var el = document.querySelector('#netexit-' + def.id + ' .net-exit-badge');
    if (el) el.textContent = def.badge;
  }

  /** 依据情报详情里的国家代码点亮左侧国旗（flagcdn 与在线优选同源，uk 特殊处理同 node-flag-img） */
  function setNetExitFlag(id, detail) {
    var card = document.getElementById('netexit-' + id);
    var flag = card && card.querySelector('.net-exit-flag');
    if (!flag) return;
    var cc = detail && detail.location && detail.location.country_code ? String(detail.location.country_code).toLowerCase().replace(/[^a-z]/g, '') : '';
    if (cc === 'uk') cc = 'gb';
    flag.style.backgroundImage = /^[a-z]{2}$/.test(cc) ? 'url(https://flagcdn.com/w80/' + cc + '.png)' : '';
  }

  async function loadNetExitCard(def) {
    setNetExitState(def.id, 'loading', '查询中...', '');
    try {
      var hit = await def.probe();
      setNetExitBadge(def);
      // IP 先行展示（同 admin.devtools 逻辑）：情报查询失败只空位置行，不吞 IP
      var detail = null;
      try { detail = await Core.queryIpDetail(hit.ip); } catch (e) { detail = null; }
      if (detail) {
        netExitDetails[def.id] = detail;
        setNetExitState(def.id, 'success', detail.ip || hit.ip, Core.exitLocLine(detail));
        setNetExitFlag(def.id, detail);
      } else {
        setNetExitState(def.id, 'success', hit.ip, '');
      }
    } catch (e) {
      setNetExitState(def.id, 'error', def.errText, '');
    }
  }

  function generateNetExitCards() {
    var container = document.getElementById('net-exit-cards');
    if (!container) return;
    container.innerHTML = '';
    NET_EXIT_DEFS.forEach(function (def) {
      var card = document.createElement('div');
      card.className = 'net-exit-card';
      card.id = 'netexit-' + def.id;
      card.addEventListener('click', function () {
        if (!netExitDetails[def.id]) { showToast(def.title + ' 的出口 IP 尚未就绪', true); return; }
        showIpDetailModal(netExitDetails[def.id]);
      });
      // 两行布局：国旗 + IP + 角标，点击复用详情弹窗
      card.innerHTML = '<div class="net-exit-flag"></div><div class="net-exit-body">'
        + '<div class="net-exit-main"><span class="net-exit-ip">-</span><span class="net-exit-badge ' + def.badgeCls + '">' + def.badge + '</span></div>'
        + '<div class="net-exit-loc"></div></div>';
      container.appendChild(card);
    });
  }

  function ensureNetExit() {
    generateNetExitCards();
    NET_EXIT_DEFS.forEach(function (def) { loadNetExitCard(def); });   // 每次进入数据看板都重新探测：切节点后出口 IP 实时变化，不留旧缓存
  }

  function formatIpType(type) {
    if (!type) return '<span class="ip-type-unknown">未知</span>';
    var map = { 'isp': '住宅', 'hosting': '机房', 'business': '商用' };
    var cls = ({ 'isp': 'residential', 'hosting': 'hosting', 'business': 'business' })[type.toLowerCase()] || 'unknown';
    return '<span class="ip-type-' + cls + '">' + (map[type.toLowerCase()] || type) + '</span>';
  }

  // 点击站点卡片：实时查询本机出口 IP 情报（取数在 LiteCore，这里只提示 + 弹窗）
  // 不做缓存：切换节点后出口 IP 会变，缓存会让所有卡片都停留在首次查询的旧数据
  async function queryIpForSite(site) {
    showToast('正在查询访问 ' + site.name + ' 的出口 IP...');
    try {
      var probe = site.region === '国内' ? Core.probeDomesticExit() : Core.probeOverseasExit();   // 按卡片区域探测真实出口：国内直连 / 国外代理
      var hit = await probe;
      showIpDetailModal(await Core.queryIpDetail(hit.ip), site);
    } catch (e) {
      showToast('查询失败: ' + e.message, true);
    }
  }

  function showIpDetailModal(data, site) {
    var modal = document.createElement('div');
    modal.className = 'modal show';   // 复用后台标准遮罩外壳（同测速设置弹窗）
    var flags = { is_crawler: data.is_crawler, is_proxy: data.is_proxy, is_vpn: data.is_vpn, is_tor: data.is_tor, is_abuser: data.is_abuser, is_bogon: data.is_bogon };
    var score = calcAbuseScore(fmtAbuserScore(data.company && data.company.abuser_score), fmtAbuserScore(data.asn && data.asn.abuser_score), flags);
    var scoreBadge = getAbuseScoreBadge(score);
    var isValid = function (v) { return v && v !== '-' && v !== '未知' && v !== 'unknown'; };
    var html = '<div class="modal-content" style="max-width:520px"><div class="modal-header"><h3>IP 详细信息' + (site ? ' · ' + escHtml(site.name) : '') + '</h3><button class="modal-close" onclick="this.closest(\'.modal\').remove()">×</button></div><div class="modal-body">';
    var basic = '<div class="ip-detail-item"><span class="ip-detail-label">IP 地址</span><span class="ip-detail-value">' + (data.ip || '未知') + '</span></div>';
    if (data.rir) basic += '<div class="ip-detail-item"><span class="ip-detail-label">区域互联网注册机构</span><span class="ip-detail-value">' + data.rir + '</span></div>';   // 无数据的字段整行不渲染，不留「未知」占位
    if (score !== null) basic += '<div class="ip-detail-item"><span class="ip-detail-label">综合滥用评分</span><span class="ip-detail-value"><span class="ip-detail-badge ' + scoreBadge.cls + '">' + scoreBadge.text + '</span></span></div>';
    html += '<div class="ip-detail-section"><div class="ip-detail-section-title">基本信息</div>' + basic + '</div>';
    if (data.location) {
      var loc = '';
      loc += '<div class="ip-detail-item"><span class="ip-detail-label">国家</span><span class="ip-detail-value">' + (data.location.country || '未知') + ' (' + (data.location.country_code || '-') + ')</span></div>';
      if (isValid(data.location.state)) loc += '<div class="ip-detail-item"><span class="ip-detail-label">省份/州</span><span class="ip-detail-value">' + data.location.state + '</span></div>';
      if (isValid(data.location.city)) loc += '<div class="ip-detail-item"><span class="ip-detail-label">城市</span><span class="ip-detail-value">' + data.location.city + '</span></div>';
      if (isValid(data.location.zip)) loc += '<div class="ip-detail-item"><span class="ip-detail-label">邮编</span><span class="ip-detail-value">' + data.location.zip + '</span></div>';
      if (data.location.latitude && data.location.longitude) loc += '<div class="ip-detail-item"><span class="ip-detail-label">坐标</span><span class="ip-detail-value">' + data.location.latitude + ', ' + data.location.longitude + '</span></div>';
      if (isValid(data.location.timezone)) loc += '<div class="ip-detail-item"><span class="ip-detail-label">时区</span><span class="ip-detail-value">' + data.location.timezone + '</span></div>';
      if (isValid(data.location.local_time)) loc += '<div class="ip-detail-item"><span class="ip-detail-label">当地时间</span><span class="ip-detail-value">' + data.location.local_time + '</span></div>';
      html += '<div class="ip-detail-section"><div class="ip-detail-section-title">位置信息</div>' + loc + '</div>';
    }
    if (data.company && isValid(data.company.name)) {
      var co = '<div class="ip-detail-item"><span class="ip-detail-label">运营商</span><span class="ip-detail-value">' + data.company.name + '</span></div>';
      if (isValid(data.company.domain)) co += '<div class="ip-detail-item"><span class="ip-detail-label">域名</span><span class="ip-detail-value">' + data.company.domain + '</span></div>';
      if (isValid(data.company.type)) co += '<div class="ip-detail-item"><span class="ip-detail-label">类型</span><span class="ip-detail-value">' + formatIpType(data.company.type) + '</span></div>';
      if (isValid(data.company.network)) co += '<div class="ip-detail-item"><span class="ip-detail-label">网络范围</span><span class="ip-detail-value">' + data.company.network + '</span></div>';
      var coScore = fmtAbuserScore(data.company.abuser_score);
      if (coScore) co += '<div class="ip-detail-item"><span class="ip-detail-label">滥用评分</span><span class="ip-detail-value">' + coScore + '</span></div>';
      html += '<div class="ip-detail-section"><div class="ip-detail-section-title">运营商信息</div>' + co + '</div>';
    }
    if (data.asn && isValid(data.asn.asn)) {
      var asn = '<div class="ip-detail-item"><span class="ip-detail-label">ASN 编号</span><span class="ip-detail-value">AS' + data.asn.asn + '</span></div>';
      if (isValid(data.asn.org)) asn += '<div class="ip-detail-item"><span class="ip-detail-label">组织</span><span class="ip-detail-value">' + data.asn.org + '</span></div>';
      if (isValid(data.asn.route)) asn += '<div class="ip-detail-item"><span class="ip-detail-label">路由</span><span class="ip-detail-value">' + data.asn.route + '</span></div>';
      if (isValid(data.asn.type)) asn += '<div class="ip-detail-item"><span class="ip-detail-label">类型</span><span class="ip-detail-value">' + formatIpType(data.asn.type) + '</span></div>';
      var asnScore = fmtAbuserScore(data.asn.abuser_score);
      if (asnScore) asn += '<div class="ip-detail-item"><span class="ip-detail-label">滥用评分</span><span class="ip-detail-value">' + asnScore + '</span></div>';
      if (isValid(data.asn.country)) asn += '<div class="ip-detail-item"><span class="ip-detail-label">国家代码</span><span class="ip-detail-value">' + String(data.asn.country).toUpperCase() + '</span></div>';
      html += '<div class="ip-detail-section"><div class="ip-detail-section-title">ASN 信息</div>' + asn + '</div>';
    }
    html += '</div></div>';
    modal.innerHTML = html;
    modal.addEventListener('click', function (e) { if (e.target === modal) modal.remove(); });
    document.addEventListener('keydown', function handler(e) { if (e.key === 'Escape') { modal.remove(); document.removeEventListener('keydown', handler); } });
    document.body.appendChild(modal);
  }

  async function dashboardLoad() {
    if (!window.LiteAPI) { renderDashRings(null); return; }   // 纯静态预览
    if (!DASH_STATUS) {
      var s = await LiteAPI.getStatus();
      if (s) DASH_STATUS = s;
    }
    applyDashStatus(DASH_STATUS);
    fillSystemBar(DASH_STATUS);
    // 用量环：拉全量账号用量做总览
    await ensureCfLoaded();
    if (CF_ACCOUNTS.length) {
      renderDashRings(CF_USAGE_AGG || null);
      var agg = await cfRefreshUsageAll(true);
      renderDashRings(agg || CF_USAGE_AGG || null);
    } else {
      renderDashRings(null);
    }
  }
  // 高级设置系统状态栏（版本 / D1 绑定 / 登录时间）
  async function fillSystemBar(pre) {
    var s = pre || DASH_STATUS;
    if (!s && window.LiteAPI) { s = await LiteAPI.getStatus(); if (s) DASH_STATUS = s; }
    var v = document.getElementById('sys-version');
    if (v) v.textContent = s ? (s.version || '—') : '获取失败';
    var db = document.getElementById('sys-db-status');
    if (db) db.textContent = s ? (s.d1Bound ? 'D1' : '未绑定 D1') : '未知';
    var dot = document.getElementById('sys-d1-dot');
    if (dot) dot.classList.toggle('ok', !!(s && s.d1Bound));
    var ses = document.getElementById('sys-session');
    if (ses) {
      var t = 0;
      try { t = parseInt(localStorage.getItem('sf_lite_login_time') || '0', 10); } catch (e) {}
      ses.textContent = t ? new Date(t).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }) : '-';
    }
  }

  // ---------- 安全设置：账号 / 登录安全 ----------
  // 管理员头像：本地选图 → canvas 裁方压缩 128px → 含透明导出 PNG 保留 alpha，否则 JPEG → dataURL 存 D1（AdminAvatar 配置键）
  var ADMIN_AVATAR_DRAFT = '';   // 本次会话新选未保存的头像 dataURL；保存成功后清空

  /** 生效头像到全部展示位：侧边栏 .user-avatar img + 安全设置预览 #secAvatar */
  function applyAdminAvatar(src) {
    if (!src) return;
    var side = document.querySelector('.user-avatar img');
    if (side) side.src = src;
    var prev = document.getElementById('secAvatar');
    if (prev) prev.src = src;
  }

  window.__secAvatarPick = function (inp) {
    var f = inp.files && inp.files[0];
    if (!f) return;
    if (!/^image\//.test(f.type)) { showToast('请选择图片文件', true); return; }
    var rd = new FileReader();
    rd.onload = function () {
      var im = new Image();
      im.onload = function () {
        var S = 128, c = document.createElement('canvas');
        c.width = S; c.height = S;
        var ctx = c.getContext('2d');
        // 居中裁方（cover）：短边对齐、裁掉长边两侧，避免拉伸变形
        var m = Math.min(im.width, im.height);
        ctx.drawImage(im, (im.width - m) / 2, (im.height - m) / 2, m, m, 0, 0, S, S);
        // 透明检测：JPEG 无 alpha 通道，导出会把透明区填黑——含透明像素一律改走 PNG，原样保留透明背景
        var px = ctx.getImageData(0, 0, S, S).data, hasAlpha = false;
        for (var i = 3; i < px.length; i += 4) { if (px[i] < 255) { hasAlpha = true; break; } }
        ADMIN_AVATAR_DRAFT = hasAlpha ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', 0.85);
        applyAdminAvatar(ADMIN_AVATAR_DRAFT);
        showToast('头像已更新，点击「保存账号」生效');
      };
      im.onerror = function () { showToast('图片解析失败', true); };
      im.src = rd.result;
    };
    rd.readAsDataURL(f);
    inp.value = '';   // 复位 input，同名文件可重复触发 change
  };

  function secSetVal(id, v) { var el = document.getElementById(id); if (el && document.activeElement !== el) el.value = v; }
  function fillSecurity() {
    if (!window.LiteAPI) return;
    LiteAPI.call('/api/config').then(function (c) {
      if (!c) return;
      secSetVal('secUser', c.USERNAME || '');
      secSetVal('secUuid', c.UUID || '');
      secSetVal('secSession', c.sessionTimeout != null ? c.sessionTimeout : 24);
      var lockEl = document.getElementById('secLock');
      if (lockEl) lockEl.checked = c.loginLockEnabled !== false;
      ADMIN_AVATAR_DRAFT = '';
      if (c.AdminAvatar) applyAdminAvatar(c.AdminAvatar);   // 回填：D1 已有头像时侧边栏与预览同步
    });
  }
  // 进入后台即拉一次配置生效头像（不依赖是否进过安全设置页）
  if (window.LiteAPI && !LiteAPI.loginExpired()) {
    LiteAPI.getConfig().then(function (c) { if (c && c.AdminAvatar) applyAdminAvatar(c.AdminAvatar); });
  }
  window.__secResetUuid = function () {
    window.__showConfirm('确定重置 UUID？旧订阅链接将立即失效，需重新分发新订阅。', function () {
      window.__showConfirm('再次确认：真的要重置吗？', async function () {
        var nu = '';
        try { nu = (crypto.randomUUID && crypto.randomUUID()) || ''; } catch (e) {}
        if (!nu) {
          // fallback v4
          var s = function () { return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1); };
          nu = s() + s() + '-' + s() + '-4' + s().substr(1) + '-8' + s().substr(1) + '-' + s() + s() + s();
        }
        var r = await LiteAPI.call('/api/config', { method: 'POST', body: JSON.stringify({ UUID: nu }) });
        if (r) { secSetVal('secUuid', nu); showToast('UUID 已重置，新订阅已生效'); }
      }, '二次确认', { okText: '确认重置', cancelText: '取消', danger: true });
    }, '重置 UUID', { okText: '下一步', cancelText: '取消', danger: true });
  };
  window.__secSaveAccount = async function () {
    var u = ((document.getElementById('secUser') || {}).value || '').trim();
    var p = (document.getElementById('secPass') || {}).value || '';
    if (!u) { showToast('账号不能为空', true); return; }

    var payload = { USERNAME: u };
    if (p) payload.PASSWORD = p;
    if (ADMIN_AVATAR_DRAFT) payload.AdminAvatar = ADMIN_AVATAR_DRAFT;   // 本次有新选头像才提交，未选择不动库内值
    var r = await LiteAPI.call('/api/config', { method: 'POST', body: JSON.stringify(payload) });
    if (r) {
      var passEl = document.getElementById('secPass');
      if (passEl) passEl.value = '';
      ADMIN_AVATAR_DRAFT = '';
      CFG_SERVER = null;   // 头像已入库，下次拉配置取新值
      showToast(p ? '账号已保存，下次登录请使用新密码' : '账号已保存');
    }
  };
  window.__secSaveSecurity = async function () {
    var h = parseInt((document.getElementById('secSession') || {}).value, 10);
    if (!(h >= 1 && h <= 168)) { showToast('会话超时需在 1-168 小时之间', true); return; }
    var r = await LiteAPI.call('/api/config', { method: 'POST', body: JSON.stringify({
      loginLockEnabled: !!(document.getElementById('secLock') || {}).checked,
      sessionTimeout: h
    }) });
    if (r) showToast('登录安全已保存，下次登录生效');
  };

  // ---------- 安全设置字段即时校验（载入即绑定）
  var secUserEl = document.getElementById('secUser');
  if (secUserEl) secUserEl.addEventListener('input', function () {
    secUserEl.classList.toggle('invalid', !String(secUserEl.value || '').trim());
  });
  var secSessEl = document.getElementById('secSession');
  if (secSessEl) secSessEl.addEventListener('input', function () {
    var h = parseInt(secSessEl.value, 10);
    secSessEl.classList.toggle('invalid', !(h >= 1 && h <= 168));
  });

  // ---------- 系统日志（/api/logs，分页 10/20/30，默认 10） ----------
  var LOGS_CACHE = [];
  var LOGS_PAGE = 1;
  var LOGS_SIZE = 10;
  var LOGS_SIZE_OPTS = [10, 20, 30];
  function fillLogs() {
    if (!window.LiteAPI) return;
    LiteAPI.call('/api/logs?limit=500').then(function (rows) {
      LOGS_CACHE = Array.isArray(rows) ? rows : [];
      LOGS_PAGE = 1;
      logsRender();
    });
  }
  window.__logsRefresh = function () { fillLogs(); };
  window.__logsGo = function (p) { LOGS_PAGE = p; logsRender(); };
  window.__logsSizeToggle = function (e) {
    e.stopPropagation();
    var ms = document.getElementById('ms-logsize');
    if (ms) ms.classList.toggle('open');
  };
  window.__logsSize = function (n) {
    LOGS_SIZE = n;
    LOGS_PAGE = 1;
    logsRender();
  };
  function logsRender() {
    var tbody = document.getElementById('logsBody');
    if (!tbody) return;
    if (!LOGS_CACHE.length) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center" class="text-muted-light">暂无日志</td></tr>';
      var rowEmpty = document.getElementById('logsPagerRow');
      if (rowEmpty) rowEmpty.innerHTML = '';
      var footEmpty = document.getElementById('logsFoot');
      if (footEmpty) footEmpty.hidden = true;
      return;
    }
    var total = LOGS_CACHE.length;
    var totalPages = Math.max(1, Math.ceil(total / LOGS_SIZE));
    if (LOGS_PAGE > totalPages) LOGS_PAGE = totalPages;
    if (LOGS_PAGE < 1) LOGS_PAGE = 1;
    var start = (LOGS_PAGE - 1) * LOGS_SIZE;
    var rows = LOGS_CACHE.slice(start, start + LOGS_SIZE);
    tbody.innerHTML = rows.map(function (lg, i) {
      var timeStr = Core.fmtLogTime(lg.time);   // UTC+8 展示，与表头一致
      var org = lg.org || '';
      var dc = org ? 'AS' + (lg.asn || '?') + ' ' + org : (lg.asn && lg.asn !== '-' ? 'AS' + lg.asn : '-');
      // 单用户面板：日志表不设用户名列（detail 里的「账号: xxx」保留在详情列可见）
      var detail = lg.detail || '';
      var absIdx = start + i + 1;
      return '<tr>' +
        '<td>' + absIdx + '</td>' +
        '<td>' + escHtml(timeStr) + '</td>' +
        '<td>' + escHtml(lg.ip || '-') + '</td>' +
        '<td>' + escHtml(lg.cc || '-') + '</td>' +
        '<td class="truncate" style="max-width:160px" title="' + escHtml(dc) + '">' + escHtml(dc) + '</td>' +
        '<td class="truncate" style="max-width:220px" title="' + escHtml(detail) + '">' + escHtml(detail || '-') + '</td>' +
        '<td><span class="node-type node">' + escHtml(lg.type || '-') + '</span></td>' +
        '</tr>';
    }).join('');
    // 分页栏（显隐切外层 foot，防止内边距留白）
    var row = document.getElementById('logsPagerRow');
    var foot = document.getElementById('logsFoot');
    if (!row || !foot) return;
    foot.hidden = false;
    if (total <= LOGS_SIZE) { row.innerHTML = ''; foot.hidden = true; return; }
    var chevL = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>';
    var chevR = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
    var p = LOGS_PAGE;
    var html = '<button type="button" title="上一页"' + (p <= 1 ? ' disabled' : ' onclick="window.__logsGo(' + (p - 1) + ')"') + '>' + chevL + '</button>';
    pagerPages(p, totalPages).forEach(function (pg) {
      html += pg === '...'
        ? '<span class="page-ellipsis">…</span>'
        : '<button type="button"' + (pg === p ? ' class="active"' : ' onclick="window.__logsGo(' + pg + ')"') + '>' + pg + '</button>';
    });
    html += '<button type="button" title="下一页"' + (p >= totalPages ? ' disabled' : ' onclick="window.__logsGo(' + (p + 1) + ')"') + '>' + chevR + '</button>';
    html += '<span class="jump-box"><span class="jump-label">跳转</span><input id="logsJump" type="number" min="1" max="' + totalPages + '" placeholder="页码" value="' + p + '"><span class="jump-label">页</span></span>';
    html += '<div class="ms" id="ms-logsize" style="min-width:96px">' +
      '<button type="button" class="ms-trigger ui-field" style="height:34px;" onclick="window.__logsSizeToggle(event)">' +
      '<span class="ms-value">' + LOGS_SIZE + ' 条/页</span>' +
      '<svg class="ms-caret" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>' +
      '<div class="ms-panel"><div class="ms-list">' +
      LOGS_SIZE_OPTS.map(function (n) {
        return '<div class="ms-opt single' + (n === LOGS_SIZE ? ' active' : '') + '" onclick="window.__logsSize(' + n + ')"><span>' + n + ' 条/页</span></div>';
      }).join('') +
      '</div></div></div>';
    row.innerHTML = html;
    var inp = document.getElementById('logsJump');
    if (inp) inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { var v = parseInt(inp.value, 10); if (v >= 1 && v <= totalPages && v !== p) window.__logsGo(v); }
    });
  }

  // ---------- 高级设置：配置导出 / 导入 / 恢复出厂，退出登录 ----------
  window.__cfgExport = async function () {
    if (!window.LiteAPI) { showToast('后端未接入（纯静态预览）', true); return; }
    var c = await LiteAPI.getConfig();
    if (!c) return;
    downloadText('senflare-lite-config.json', JSON.stringify(c, null, 2), '配置已导出', 'application/json;charset=utf-8');
  };
  window.__cfgImport = function () {
    var inp = document.getElementById('cfgImportFile');
    if (inp) inp.click();
  };
  window.__cfgImportChange = async function (inp) {
    try {
      if (!inp.files || !inp.files[0]) return;
      var obj = JSON.parse(await inp.files[0].text());
      if (!obj || typeof obj !== 'object' || Array.isArray(obj)) throw new Error('格式不正确');
      delete obj.RESET;
      delete obj.USERNAME;      // 凭据不随配置文件迁移
      delete obj.PASSWORD;
      var r = await LiteAPI.saveConfig(obj);
      if (r) { CFG_SERVER = null; cfgDraftClear(); showToast('配置导入成功'); setTimeout(function () { location.reload(); }, 800); }
    } catch (e) {
      showToast('导入失败：' + e.message, true);
    }
    inp.value = '';
  };
  window.__factoryReset = function () {
    window.__showConfirm('确定恢复出厂设置？将清除 D1 中保存的全部节点/反代配置，此操作不可恢复！', function () {
      window.__showConfirm('再次确认：真的要清除全部配置吗？', async function () {
        var r = await LiteAPI.saveConfig({ RESET: true });
        if (r) {
          cfgDraftClear();
          CFG_SERVER = null;
          showToast('已恢复出厂设置');
          setTimeout(function () { location.reload(); }, 800);
        }
      }, '二次确认', { okText: '确认清除', cancelText: '取消', danger: true });
    }, '恢复出厂设置', { okText: '下一步', cancelText: '取消', danger: true });
  };
  // ---------- 通用确认弹窗（退出登录等场景，样式复用 .st-check-*） ----------
  // opts 可选：{ okText, cancelText, onDiscard }，遮罩 / ESC 恒为安全关闭
  var confirmCb = null, confirmDiscardCb = null, confirmCancelCb = null;
  /** 主题确认弹窗的 Promise 包装：await themeConfirm(msg, title, opts) 返回用户是否点确定 */
  function themeConfirm(msg, title, opts) {
    return new Promise(function (resolve) {
      var o = Object.assign({}, opts || {});
      o.onCancel = function () { resolve(false); };
      window.__showConfirm(msg, function () { resolve(true); }, title, o);
    });
  }
  window.__showConfirm = function (msg, onConfirm, title, opts) {
    opts = opts || {};
    document.getElementById('confirmTitle').textContent = title || '确认';
    document.getElementById('confirmBody').textContent = msg;
    confirmCb = typeof onConfirm === 'function' ? onConfirm : null;
    confirmDiscardCb = typeof opts.onDiscard === 'function' ? opts.onDiscard : null;
    confirmCancelCb = typeof opts.onCancel === 'function' ? opts.onCancel : null;
    document.querySelector('#confirmModal .btn-outline').textContent = opts.cancelText || '取消';
    var okBtn = document.querySelector('#confirmModal .btn-primary');
    okBtn.textContent = opts.okText || '确定';
    okBtn.classList.toggle('danger', !!opts.danger);
    document.getElementById('confirmModal').classList.add('show');
  };
  window.__confirmCancel = function () {
    var m = document.getElementById('confirmModal');
    if (m) m.classList.remove('show');
    var c = confirmCancelCb;
    confirmCb = null; confirmDiscardCb = null; confirmCancelCb = null;
    if (c) c();
  };
  window.__confirmDiscard = function () {          // 左键：关闭并执行放弃类分支（如「直接离开」）
    var d = confirmDiscardCb;
    window.__confirmCancel();
    if (d) d();
  };
  window.__confirmOk = function () {
    var cb = confirmCb;
    confirmCancelCb = null;   // OK 路径不触发取消回调
    window.__confirmCancel();
    if (cb) cb();
  };
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      var m = document.getElementById('confirmModal');
      if (m && m.classList.contains('show')) window.__confirmCancel();
    }
  });

  // 退出登录：确认弹窗 → 清本地令牌 → 回登录页
  window.__logout = function () {
    window.__showConfirm('确定要退出登录吗？', async function () {
      try { await LiteAPI.call('/api/logout', { method: 'POST' }); } catch (e) {}
      try { LiteAPI.setToken(''); localStorage.removeItem('sf_lite_login_time'); } catch (e) {}
      location.href = '/login';
    }, '退出登录');
  };

  // 暴露到全局（主题明暗/调色盘由 js/theme.js 提供）
  window.toggleSidebar = toggleSidebar;
  window.toggleCard = toggleCard;
  window.switchTab = switchTab;
  window.generateSub = generateSub;
  window.switchSubCred = switchSubCred;
  window.copySubUrl = copySubUrl;
  window.toggleSubQR = toggleSubQR;
  window.switchNodeListTab = switchNodeListTab;
  window.toggleNodeListFold = toggleNodeListFold;
  window.switchSpeedTab = switchSpeedTab;
  window.toggleStFold = toggleStFold;
  // 本地优选：复制 CFData-WEB 项目地址
  window.copyCfDataUrl = function () {
    copyText('https://github.com/PoemMisty/CFData-WEB', '项目地址已复制到剪贴板');
  };

  document.addEventListener('DOMContentLoaded', function () {
    // 明暗/主题色初始化由 js/theme.js 负责（含服务端同步）
    // 字体大陆备份：主源超时切 gcore
    (function () {
      function fontBackupOnFail(linkId, family, backupUrl) {
        var link = document.getElementById(linkId);
        if (!link || link.dataset.backed) return;
        link.dataset.backed = '1';
        setTimeout(function () {
          var faces = document.fonts ? Array.from(document.fonts).filter(function (f) { return String(f.family).indexOf(family) !== -1; }) : [];
          var dead = !document.fonts || faces.length === 0 || faces.every(function (f) { return f.status === 'error'; });
          if (dead && link.getAttribute('href') !== backupUrl) { link.media = 'all'; link.href = backupUrl; }
        }, 2500);
      }
      fontBackupOnFail('fontInterCss', 'Inter Variable', 'https://gcore.jsdelivr.net/npm/@fontsource-variable/inter@5/index.css');
      fontBackupOnFail('fontNotoCss', 'Noto Sans SC Variable', 'https://gcore.jsdelivr.net/npm/@fontsource-variable/noto-sans-sc@5/index.css');
    })();
    var sidebar = document.getElementById('sidebar');
    if (sidebar && window.innerWidth > 768 && !sidebar.classList.contains('expanded')) sidebar.classList.add('expanded');
    // 恢复上次激活的 tab，失效回落看板
    var savedTab = null;
    try { savedTab = localStorage.getItem('sf_lite_tab'); } catch (e) {}
    var savedEl = savedTab && document.querySelector('.nav-item[data-tab="' + savedTab + '"]');
    if (savedEl) { try { localStorage.removeItem('sf_lite_cfg_draft_v1'); } catch (e) {} switchTab(savedTab, savedEl); }
    else switchTab('dashboard', document.querySelector('.nav-item[data-tab="dashboard"]'));
  });
  var resizeTimer;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      var sidebar = document.getElementById('sidebar');
      var overlay = document.querySelector('.sidebar-overlay');
      if (!sidebar) return;
      if (window.innerWidth <= 768) {
        sidebar.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
      }
    }, 150);
  });
})();
