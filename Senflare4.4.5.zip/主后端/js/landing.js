// 控制台品牌信息
console.log("%c Senflare Link", "color:#fff;font-weight:700;background:linear-gradient(270deg,#986fee,#8695e6,#68b7dd,#18d7d3);padding:8px 15px;border-radius:15px");
console.log("%c Powered by 简睿 | TG @Senflare", "color:#FFD700;background:linear-gradient(135deg,#0a0a0a,#1a1a1a,#0a0a0a);padding:8px 15px;font-weight:700;border-radius:15px;text-shadow:0 0 10px rgba(255, 215, 0)");

/**
 * ==================== Senflare Link Lite - 落地页脚本 ====================
 * 落地页脚本：导航交互 / 打字机 / 遮罩品牌滑入 / Canvas 网络动画 / 数字计数 / FAQ / 滚动动效 / 节点卡与测速 / 回到顶部
 */

// ==================== 1. UI 交互 ====================
/** 头部滚动效果：滚动超过 50px 添加阴影 */
function initHeaderScroll() {
    const header = document.querySelector('.header');
    if (!header) return;
    window.addEventListener('scroll', () => {
        header.classList.toggle('scrolled', window.scrollY > 50);
    });
}

/** 移动端导航开合：切换 .nav-open，点链接后自动收起 */
function initNavToggle() {
    const header = document.querySelector('.header');
    const toggle = document.querySelector('.nav-toggle');
    if (!header || !toggle) return;
    const setOpen = (open) => {
        header.classList.toggle('nav-open', open);
        toggle.setAttribute('aria-expanded', open);
    };
    toggle.addEventListener('click', () => setOpen(!header.classList.contains('nav-open')));
    header.querySelectorAll('.nav-links a').forEach(a => a.addEventListener('click', () => setOpen(false)));
    document.addEventListener('click', (e) => {
        // 点击头部以外（空白区域）时收起抽屉
        if (header.classList.contains('nav-open') && !header.contains(e.target)) setOpen(false);
    });
}

/** 桌面导航高亮：滚动经过区块时点亮对应锚点 */
function initNavSpy() {
    const links = [...document.querySelectorAll('.nav-links a[href^="#"]')];
    if (!links.length) return;
    const sections = links.map(a => document.getElementById(a.hash.slice(1))).filter(Boolean);
    const update = () => {
        let current = '';
        for (const s of sections) if (s.offsetTop <= window.scrollY + 140) current = s.id;
        if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 2) current = sections[sections.length - 1].id;
        links.forEach(a => a.classList.toggle('active', a.hash === '#' + current));
    };
    window.addEventListener('scroll', update, { passive: true });
    update();
}

/** 版权年份：用当前年份覆盖静态占位 */
function initCopyright() {
    const el = document.getElementById('copyrightYear');
    if (el) el.textContent = new Date().getFullYear();
}

/** 兼容芯片双排跑马灯：克隆现有轨道一行，反向滚动 */
function initCompatDual() {
    const track = document.querySelector('.compat-marquee .compat-track');
    if (!track) return;
    const rev = track.cloneNode(true);
    rev.classList.add('compat-track-rev');
    rev.setAttribute('aria-hidden', 'true');
    track.after(rev);
}

// ==================== 2. 视觉效果 ====================
/** 打字机效果（Hero 区域标题，循环） */
function initTypewriter() {
    const el = document.getElementById('heroTypewriter');
    if (!el) return;

    const texts = ['最快、最稳、最安全的网络加速服务', '一键部署 · 全球节点 · 一触即达'];

    let textIndex = 0;
    let charIndex = 0;
    let isDeleting = false;

    function type() {
        const currentText = texts[textIndex];

        if (isDeleting) {
            el.textContent = currentText.substring(0, charIndex - 1);
            charIndex--;
        } else {
            el.textContent = currentText.substring(0, charIndex + 1);
            charIndex++;
        }

        let delay = isDeleting ? 50 : 100;

        if (!isDeleting && charIndex === currentText.length) {
            delay = 3000;
            isDeleting = true;
        } else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            textIndex = (textIndex + 1) % texts.length;
            delay = 500;
        }

        setTimeout(type, delay);
    }

    setTimeout(type, 500);
}

/** 开场遮罩品牌名逐字滑入：拆分单字 span（占位防跳版，Lite 勋章整体当一个字母排在字流队尾），按 60ms 一档从右侧滑入落位（veilChar 动画），.typed 门控防整名闪现 */
function initVeilTypewriter() {
    const brand = document.querySelector('.page-veil .logo-text');
    if (!brand) return;
    let i = 0;
    const walk = node => [...node.childNodes].forEach(child => {
        if (child.nodeType === 3) {
            const frag = document.createDocumentFragment();
            for (const ch of child.textContent) {
                const s = document.createElement('span');
                s.className = 'ch';
                s.style.setProperty('--ch-delay', (i++ * 60) + 'ms');
                s.textContent = ch;
                frag.appendChild(s);
            }
            child.replaceWith(frag);
        } else if (child.nodeType === 1) {
            child.style.setProperty('--el-delay', (i * 60) + 'ms');   // 勋章的打字时刻 = 它在字流中的字母位
            if (!child.classList.contains('brand-lite')) walk(child);   // 勋章整体当一个字母，不拆字
        }
    });
    walk(brand);
    brand.classList.add('typed');
}

/** Canvas 网络节点动画（Hero 背景，节点/连线跟随动态主题色；滚出视口暂停绘制） */
function initNetworkCanvas() {
    const canvas = document.getElementById('networkCanvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    // 每帧从 CSS 变量重读（单次读取开销可忽略），调色盘换色后粒子/连线实时跟随
    let rgb = (getComputedStyle(document.documentElement).getPropertyValue('--landing-rgb') || '22, 119, 255').trim();
    let nodes = [];
    let animationId;
    let running = false;   // 绘制循环开关：滚出视口暂停，回视口续跑

    function resize() {
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        initNodes();
    }

    function initNodes() {
        nodes = [];
        const count = Math.min(25, Math.floor(canvas.width / 60));
        for (let i = 0; i < count; i++) {
            nodes.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.3,
                vy: (Math.random() - 0.5) * 0.3,
                radius: 2 + Math.random() * 2
            });
        }
    }

    function draw() {
        if (!running) return;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        rgb = (getComputedStyle(document.documentElement).getPropertyValue('--landing-rgb') || '22, 119, 255').trim();

        // 绘制连线
        for (let i = 0; i < nodes.length; i++) {
            for (let j = i + 1; j < nodes.length; j++) {
                const dx = nodes[i].x - nodes[j].x;
                const dy = nodes[i].y - nodes[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 150) {
                    ctx.beginPath();
                    ctx.moveTo(nodes[i].x, nodes[i].y);
                    ctx.lineTo(nodes[j].x, nodes[j].y);
                    ctx.strokeStyle = `rgba(${rgb}, ${0.15 * (1 - dist / 150)})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            }
        }

        // 绘制节点
        nodes.forEach(node => {
            ctx.beginPath();
            ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${rgb}, 0.6)`;
            ctx.fill();

            // 更新位置
            node.x += node.vx;
            node.y += node.vy;

            // 边界反弹
            if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
            if (node.y < 0 || node.y > canvas.height) node.vy *= -1;
        });

        animationId = requestAnimationFrame(draw);
    }

    resize();

    // 常驻 rAF 是无谓的掉帧源：滚出视口暂停绘制，回视口续跑
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(([e]) => {
            running = e.isIntersecting;
            if (running) requestAnimationFrame(draw);
            else cancelAnimationFrame(animationId);
        }, { threshold: 0 }).observe(canvas);
    } else {
        running = true;
        requestAnimationFrame(draw);
    }

    window.addEventListener('resize', resize);

    // 清理函数（页面卸载时取消动画）
    window.addEventListener('beforeunload', () => {
        if (animationId) cancelAnimationFrame(animationId);
    });
}

// ==================== 4. 数字计数动画 ====================
function initCounterAnimation() {
    const counters = document.querySelectorAll('.counter');
    if (!counters.length) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(counter => observer.observe(counter));
}

function animateCounter(el) {
    const target = parseFloat(el.dataset.target);
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    const duration = 1500;
    const startTime = performance.now();
    const isDecimal = target % 1 !== 0;

    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        // easeOutQuart 缓动
        const eased = 1 - Math.pow(1 - progress, 4);
        const current = target * eased;

        el.textContent = prefix + (isDecimal ? current.toFixed(1) : Math.floor(current)) + suffix;

        if (progress < 1) {
            requestAnimationFrame(update);
        } else {
            el.textContent = prefix + (isDecimal ? target.toFixed(1) : target) + suffix;
        }
    }

    requestAnimationFrame(update);
}

// ==================== 2.5 FAQ 手风琴 ====================
/** 常见问题手风琴：单开模式——展开当前项并收起兄弟项 */
window.toggleFaq = function (btn) {
    const item = btn.parentElement;
    const list = item.parentElement;
    const isOpen = item.classList.contains('open');
    list.querySelectorAll('.faq-item.open').forEach(el => el.classList.remove('open'));
    if (!isOpen) item.classList.add('open');
};

// ==================== 3. 滚动入场/出场 ====================
/**
 * 组件级滚动双向动效（配合 css/index.css 的 .reveal）：进场线内收导航条高度（顶）与 10%（底），
 * 元素露出可视区才播入场（同批按纵向顺序每 120ms 一档级联，单发进入不延迟）；退场线为完整视口，
 * 元素完全离屏后才静默复位——屏幕内内容永不淡出，复位保证再进场时重播；须在动态渲染组件之后调用
 */
function initReveal() {
    const els = document.querySelectorAll('.reveal :is(.sec-head, .section-head, .bento-cell, .compat-marquee, .gn-card, .faq-item, .cmp-row, .proto-group, .speed-left, .speed-rows)');
    if (!els.length) return;
    if (!('IntersectionObserver' in window)) {
        els.forEach(el => el.classList.add('in-view'));
        return;
    }
    // 进场观察：顶边内收导航条高度、底边内收 10%，露出可视区才触发
    const header = document.querySelector('.header');
    const topInset = header ? header.offsetHeight : 0;
    const ioIn = new IntersectionObserver((entries) => {
        const batch = entries.filter(e => e.isIntersecting && !e.target.classList.contains('in-view'))
            .map(e => e.target)
            .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
        batch.forEach((el, i) => el.style.setProperty('--enter-delay', Math.min(i * 120, 600) + 'ms'));
        entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in-view'); });
    }, { threshold: 0, rootMargin: `-${topInset}px 0px -10% 0px` });
    // 出场观察：以完整视口为线，完全离屏后才收回状态——嵌套在进场线之外，屏幕内永不触发
    const ioOut = new IntersectionObserver((entries) => {
        entries.forEach(e => { if (!e.isIntersecting) e.target.classList.remove('in-view'); });
    }, { threshold: 0 });
    els.forEach(el => { ioIn.observe(el); ioOut.observe(el); });
}

// ==================== 4. 酷炫动效 ====================
/** Bento 3D 倾斜：指针位置驱动轻微 rotate，离开复位 */
function initTilt() {
    document.querySelectorAll('.bento-cell').forEach(cell => {
        cell.addEventListener('pointermove', (e) => {
            const r = cell.getBoundingClientRect();
            const px = (e.clientX - r.left) / r.width - 0.5;
            const py = (e.clientY - r.top) / r.height - 0.5;
            cell.style.setProperty('--ry', (px * 7).toFixed(2) + 'deg');
            cell.style.setProperty('--rx', (-py * 7).toFixed(2) + 'deg');
        });
        cell.addEventListener('pointerleave', () => {
            cell.style.setProperty('--ry', '0deg');
            cell.style.setProperty('--rx', '0deg');
        });
    });
}

// ==================== 5. 回到顶部 ====================
/** 回到顶部按钮：滚过一屏浮现，点击平滑回顶；刷新固定回到页首 */
function initBackToTop() {
    window.scrollTo(0, 0);
    const btn = document.querySelector('.back-top');
    if (!btn) return;
    const update = () => btn.classList.toggle('show', window.scrollY > 420);
    window.addEventListener('scroll', update, { passive: true });
    update();
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

// ==================== 6. 节点卡自适应网格 ====================
// 节点数据：cc 为 flagcdn 国家码，ms 为实测延迟（进度条按 200ms 满刻度换算）
const GN_NODES = [
    { cc: 'hk', name: '中国·香港', ms: 18 },
    { cc: 'jp', name: '日本·东京', ms: 42 },
    { cc: 'kr', name: '韩国·首尔', ms: 55 },
    { cc: 'sg', name: '新加坡·樟宜', ms: 76 },
    { cc: 'au', name: '澳大利亚·悉尼', ms: 118 },
    { cc: 'us', name: '美国·洛杉矶', ms: 135 },
    { cc: 'de', name: '德国·法兰克福', ms: 158 },
    { cc: 'gb', name: '英国·伦敦', ms: 172 },
    { cc: 'tw', name: '中国·台湾', ms: 28 },
    { cc: 'jp', name: '日本·大阪', ms: 48 },
    { cc: 'in', name: '印度·孟买', ms: 105 },
    { cc: 'ae', name: '阿联酋·迪拜', ms: 128 },
    { cc: 'ca', name: '加拿大·多伦多', ms: 165 },
    { cc: 'fr', name: '法国·巴黎', ms: 168 },
    { cc: 'nl', name: '荷兰·阿姆斯特丹', ms: 182 },
    { cc: 'us', name: '美国·纽约', ms: 198 },
];

/** 渲染全球节点卡（数据驱动，改 GN_NODES 即可增删节点） */
function renderGnNodes() {
    const grid = document.querySelector('.gn-grid');
    if (!grid) return;
    grid.innerHTML = GN_NODES.map(n => `
        <div class="gn-card">
            <img class="gn-flag-img" src="https://flagcdn.com/w80/${n.cc}.png" width="44" height="32" alt="${n.name}" loading="lazy">
            <div class="gn-info"><b>${n.name}</b><span class="ping-line">延迟 <span class="ping-bar"><i style="width:${Math.min(Math.round(n.ms / 2), 100)}%"></i></span><span class="ping-ms" data-base="${n.ms}">${n.ms}ms</span></span></div>
        </div>`).join('');
}

/** 全球节点卡：按容器宽度算列数（每列不小于最小舒适宽度），恒定两行，多余卡隐藏 */
function initGnGrid() {
    renderGnNodes();
    const grid = document.querySelector('.gn-grid');
    if (!grid) return;
    const cards = [...grid.querySelectorAll('.gn-card')];
    if (!cards.length) return;
    const GAP = 12, MIN = 150;   // .75rem 列间距（与 css/index.css 间距刻度一致）+ 单卡最小舒适宽度（最长名 荷兰·阿姆斯特丹 不截断）
    const fit = () => {
        const cols = Math.min(8, Math.max(2, Math.floor((grid.clientWidth + GAP) / (MIN + GAP))));
        grid.style.setProperty('--gn-cols', cols);
        cards.forEach((c, i) => c.classList.toggle('gn-hidden', i >= cols * 2));
    };
    fit();
    startGnTicker();
    if ('ResizeObserver' in window) {
        const ro = new ResizeObserver(fit);
        ro.observe(grid);
    }
    window.addEventListener('resize', fit, { passive: true });
}

/** 延迟数值每秒刷新：围绕基准值 ±10% 抖动，进度条同步伸缩 */
function startGnTicker() {
    setInterval(() => {
        document.querySelectorAll('.gn-card').forEach(card => {
            const msEl = card.querySelector('.ping-ms');
            const bar = card.querySelector('.ping-bar i');
            if (!msEl || !bar) return;
            const base = Number(msEl.dataset.base) || 0;
            const ms = Math.max(4, Math.round(base * (0.9 + Math.random() * 0.2)));
            msEl.textContent = ms + 'ms';
            bar.style.width = Math.min(Math.round(ms / 2), 100) + '%';
        });
    }, 1000);
}

// ==================== 7. 测速条入场 ====================
/** 真实测速条：把 data-w 写成 CSS 变量，宽度随 .speed-rows 进出场在 css 里展开/收回 */
function initSpeedBars() {
    document.querySelectorAll('.speed-row .bar i').forEach(el => {
        el.style.setProperty('--w', (el.getAttribute('data-w') || '60') + '%');
    });
}

// ==================== 初始化 ====================
/** 页内锚点：平滑滚动到目标区块，地址栏不留 #hash */
function initAnchorScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', (e) => {
            const target = document.getElementById(a.getAttribute('href').slice(1));
            if (!target) return;
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth' });
            history.replaceState(null, '', location.pathname + location.search);
        });
    });
}
window.addEventListener('DOMContentLoaded', () => {
    initHeaderScroll();
    initNavToggle();
    initNavSpy();
    initCopyright();
    initTypewriter();
    initVeilTypewriter();
    initNetworkCanvas();
    initCounterAnimation();
    initTilt();
    initGnGrid();
    initReveal();
    initSpeedBars();
    initAnchorScroll();
    initBackToTop();
    initCompatDual();
});

