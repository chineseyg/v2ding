/**
 * Senflare Link Lite - 主后端
 */

// ==================== 1. 核心凭证 ====================

const AdminVersion = 'v4.4.5';
const SyncKey = '67e9cbf4ce525fc6323c326ffcd562442c257a548e79eb7a'; // 子后端通信密钥（须与子后端一致，二创请修改）

// ==================== 2. 全局配置 ====================

const ProxyIPMaxDefault = 'P' + 'r' + 'o' + 'x' + 'y' + '-' + 'A' + 'u' + 't' + 'o' + '.' + 'S' + 'e' + 'n' + 'f' + 'l' + 'a' + 'r' + 'e' + 'L' + 'i' + 'n' + 'k' + '.' + 'k' + 'd' + 'n' + 's' + '.' + 'f' + 'r'; 
const NodeDefaults = {
  USERNAME: 'Senflare',  // 管理员账号
  PASSWORD: 'Senflare',  // 管理员密码
  UUID: '07890f07-c112-4bc6-9dff-10e3915d73eb',   // 订阅凭证
  BE_UUIDS: {},                // 后端专属 UUID 映射 {"子后端域名":"该后端UUID"}——面板 UUID 留空时订阅节点按此映射取各子后端 UUID；未映射回落内置默认

  // —— 优选/反代配置 卡片 ——
  IPMode: 'Custom',      // 优选IP模式: Custom(自定义) / Local(在线优选)
  IP: 'cloudflare.seeck.cn:443#[ Senflare ] | [ SAAS ],ctcc.cloudflare.seeck.cn#[ Senflare ] | [ CTCC ],cmcc.cloudflare.seeck.cn#[ Senflare ] | [ CMCC ],cucc.cloudflare.seeck.cn#[ Senflare ] | [ CUCC ]',
  //  ↑ 自定义优选，支持：IP/域名列表 或 URL直链（格式：IP:PORT#备注）
  LocalIP: '',           // 在线优选IP/域名，格式同上
  ProxyIPMode: 'OFFICIAL',    // 反代模式: OFFICIAL(官方匹配) / Auto(智能匹配) / 地区代码 / Custom(自定义出口) / Local(在线优选)
  ProxyIP: '',                // 反代IP（CUSTOM 出口池）：内联列表或 http(s) API 直链，留空回落 AUTO
  //        ↑ 反代IP（支持 URL 远程拉取，格式同优选IP，两端共用：本端订阅取源 / 子后端 Custom 出口仅吃内联列表）
  LocalProxyIP: '',       // 在线优选反代IP/域名
  ProxyIPMax: ProxyIPMaxDefault, // 兜底反代（所有模式失效时回退 默认端口：443）
  ChainEnabled: false,    // 链式代理开关
  Upstream: '',           // 上游链式出口

  // —— 传输配置 卡片 ——
  Inbound: 'preferred',   // 入站模式: preferred(优选IP列表生成节点) / proxy(反代IP列表生成节点)
  Outbound: 'auto',       // 出站模式: auto(智能分流：CF直连优先，失败切反代/链式，保留兜底) / global(全局代理：开链式全走链式，否则CF直连优先+CF站固定IP，无兜底)
  Protocol: 'WS',         // 协议类型：WS / XHTTP
  ProtocolWorker: '',     // Worker 子后端协议：''=跟随全局 / WS / XHTTP
  ProtocolSnippet: '',    // Snippets 子后端协议：''=跟随全局 / WS / XHTTP
  Fp: 'chrome',           // 指纹伪装：订阅链接携带的浏览器 TLS 指纹
  Alpn: '',               // ALPN 协商：默认留空 = 自动协商，可选 h3 / h2 / http/1.1 / 逗号组合
  Doh: 'auto',            // DoH 劫持：53 端口流量转发至 DoH
  // auto 双端点竞速（Cloudflare + Google，推荐）/ 自定义 如： https://dns.alidns.com/dns-query

  // —— ECH 配置 卡片 ——
  ECH: true,             // ECH 注入全局开关
  EchDns: 'https://dns.alidns.com/dns-query',     // ECH DNS 解析
  EchDomain: 'cloudflare-ech.com',                // ECH 解析域名

  // —— 订阅配置 卡片 ——
  SubName: 'Senflare Link Lite',                  // 订阅展示名
  SubPath: '/links',        // 订阅路径前缀（自动规范化：补首斜杠、去尾斜杠）
  SubKey: 'SenflareLink',               // 订阅固定密钥（留空禁用），路径 /{SubPath}/<密钥> 即可获取订阅

  // —— 高级设置 页（首页伪装 / 缓存设置 卡片）——
  FakePage: false,        // 首页伪装开关：开启后主后端首页（/）出伪装页，面板走真实路径（如 /index.html），其余路径不伪装（子后端伪装常开）
  FakeUrl: 'https://www.xinhuanet.com/',            // 伪装目标 URL（仅主后端首页伪装用，子后端伪装目标固定，不同步）

  Cache: true,            // 配置缓存总开关（false 时全部配置实时拉取：IP 列表 / 节点配置 / cfAccounts）

  // —— 主题色 ——
  ThemeColor: '#1677ff',         // 全局主题色（#RRGGBB）：面板「应用」写入，经公开 GET /api/theme 分发各页
  // —— 登录页壁纸 ——
  BgSource: 'builtin',           // 登录壁纸来源：builtin(源站) / elaina / yeqing / uapis / custom
  BgCustomUrl: '',               // 自定义壁纸地址（BgSource=custom 时生效，留空回落源站）

  // —— 安全设置 卡片 ——
  loginLockEnabled: true,        // 登录失败锁定开关（10 分钟窗口 5 次失败后拒绝）
  sessionTimeout: 24,            // 管理会话有效期（小时，1-168）
  AdminAvatar: '',               // 管理员头像（data URL，面板上传压缩后的 128px 图，存 D1 全端生效）
};

const ConfigKeys = [
  'UUID',
  'BE_UUIDS',
  'IPMode', 'IP', 'LocalIP',
  'ProxyIPMode', 'ProxyIP', 'LocalProxyIP', 'ProxyIPMax', 'ChainEnabled', 'Upstream',
  'Inbound',
  'Outbound',
  'Protocol',
  'ProtocolWorker', 'ProtocolSnippet',
  'Fp',
  'Alpn',
  'Doh',
  'ECH', 'EchDns', 'EchDomain',
  'SubName', 'SubPath', 'SubKey',
  'FakePage', 'FakeUrl', 'Cache',
  'ThemeColor',
  'BgSource', 'BgCustomUrl',
  'loginLockEnabled', 'sessionTimeout',
  'AdminAvatar',
];

const ConfigTtl = 5 * 60 * 1000;   // 配置缓存时长（5 分钟，面板不可改故为常量）

// ==================== 3. 运行时状态与数据库 ====================

let runtimeEnv = null;

let dbInitPromise = null;

/** 初始化数据库：建立数据表，失败自动重试 */
const initDatabase = () => {
  const db = runtimeEnv?.Senflare;
  if (!db || dbInitPromise) return;
  dbInitPromise = db
    .batch([
      // 全局配置：key/value 键值存储，承载 NodeDefaults 全量配置（D1 必选）
      db.prepare('CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL, updatedAt INTEGER NOT NULL)'),
      db.prepare('CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, ip TEXT NOT NULL, cc TEXT, asn TEXT, org TEXT, type TEXT NOT NULL, detail TEXT)'),
      // 清理历史遗留的时间索引
      db.prepare('DROP INDEX IF EXISTS idxLogsTime'),
      // Cloudflare 多账号：domains=订阅域名（生成 Host/SNI），syncDomains=配置推送目标
      db.prepare('CREATE TABLE IF NOT EXISTS cfAccounts (id TEXT PRIMARY KEY, name TEXT, email TEXT, accountId TEXT, authType TEXT, apiToken TEXT, globalApiKey TEXT, quota INTEGER, domains TEXT, syncDomains TEXT, status TEXT, isActive INTEGER, createdAt TEXT)'),
    ])
    .then(() =>
      // 存量库补列，列已存在时忽略报错
      db.prepare('ALTER TABLE cfAccounts ADD COLUMN syncDomains TEXT').run().catch(() => { })
    )
    .then(() =>
      // 部署记录 deployInfo：部署成功后回写，下次部署自动带入
      db.prepare('ALTER TABLE cfAccounts ADD COLUMN deployInfo TEXT').run().catch(() => { })
    )
    .then(() =>
      // 混合部署迁移：为既有库补 deployType 列（'worker' | 'snippet'），列已存在则静默跳过
      db.prepare("ALTER TABLE cfAccounts ADD COLUMN deployType TEXT NOT NULL DEFAULT 'worker'").run().catch(() => { })
    )
    .then(() =>
      // 按账号指定协议：为既有库补 protocol 列（'WS' | 'XHTTP' | ''），列已存在则静默跳过
      db.prepare("ALTER TABLE cfAccounts ADD COLUMN protocol TEXT NOT NULL DEFAULT ''").run().catch(() => { })
    )
    .catch(() => {
      dbInitPromise = null;
    });
};

// ==================== 4. 配置加载 ====================

/** 节点/订阅配置缓存 */
let nodeConf = null;
let nodeConfTime = 0;

/** 配置加载并发去重*/
let nodeConfInflight = null;

/** D1 故障等待（加载失败后短窗内不再访问数据库） */
let nodeConfFailUntil = 0;

const applyOutboundRules = (conf) => {
  let outbound = String(conf.Outbound ?? '').trim().toLowerCase();
  if (outbound === 'fixed') conf.Outbound = outbound = 'global';   // 旧值 fixed 归一为 global（两模式制）
  const mode = String(conf.ProxyIPMode || '').toUpperCase();
  if (outbound === 'global' && conf.ChainEnabled !== true && mode !== 'CUSTOM' && mode !== 'LOCAL') conf.ProxyIPMode = 'CUSTOM';   // 全局未开链式 = 固定 IP 语义，出口须为列表型
  return conf;
};

/** 加载配置：5 分钟缓存 + 并发去重，关闭缓存时实时读取 */
const loadNodeConfig = async () => {
  const now = Date.now();
  const cacheOn = (nodeConf?.Cache ?? NodeDefaults.Cache) !== false;
  if (cacheOn && nodeConf && now - nodeConfTime < ConfigTtl) return nodeConf;
  if (cacheOn && now < nodeConfFailUntil) return nodeConf ?? { ...NodeDefaults };
  if (nodeConfInflight) return nodeConfInflight;
  nodeConfInflight = (async () => {
    const conf = { ...NodeDefaults };
    let loaded = false;
    const db = runtimeEnv?.Senflare;
    if (db) {
      let killer;
      try {
        initDatabase();
        // D1 挂起兜底（与子后端同款）：8s 强制回落旧缓存/默认，防 D1 hang 时整个入口被拖死
        const read = (async () => {
          await dbInitPromise;
          return (await db
            .prepare(`SELECT key, value FROM config WHERE key IN (${ConfigKeys.map(() => '?').join(',')})`)
            .bind(...ConfigKeys)
            .all()).results;
        })();
        read.catch(() => { });   // 超时败者拒绝兜底
        const rows = await Promise.race([read, new Promise((_, rej) => { killer = setTimeout(() => rej(new Error('d1-timeout')), 8000); })]);
        for (const row of rows) {
          try {
            conf[row.key] = JSON.parse(row.value);
          } catch {
            conf[row.key] = row.value;
          }
        }
        loaded = true;
      } catch { }
      finally { clearTimeout(killer); }
    } else {
      loaded = true; // 无 D1 绑定：纯默认即最终配置
    }

    const normalizedSubPath = String(conf.SubPath ?? '/links').trim().replace(/^\/+|\/+$/g, '');
    conf.SubPath = normalizedSubPath ? `/${normalizedSubPath}` : '/links';

    if (loaded) {
      applyOutboundRules(conf);
      nodeConf = conf;
      nodeConfTime = now;
      return conf;
    }
    nodeConfFailUntil = now + 30 * 1000;
    return nodeConf ?? conf;
  })();
  try {
    return await nodeConfInflight;
  } finally {
    nodeConfInflight = null;
  }
};

/** 生效 UUID：D1 覆盖硬编码值（订阅路径凭证用） */
const isValidUuid = (s) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
const getUuid = () => {
  const cfg = String(nodeConf?.UUID || '').trim();
  return isValidUuid(cfg) ? cfg.toLowerCase() : NodeDefaults.UUID;
};

/** 节点生效 UUID：面板 UUID 非空 = 统一覆盖所有子后端；留空 = 各子后端各自 UUID（BE_UUIDS 按域名映射），未映射回落内置默认 */
const uuidForHost = (host) => {
  const override = String(nodeConf?.UUID || '').trim();
  if (isValidUuid(override)) return override.toLowerCase();   // 面板统一覆盖（最高优先）
  let map = nodeConf?.BE_UUIDS;
  if (typeof map === 'string') { if (!map.trim()) map = null; else { try { map = JSON.parse(map); } catch { map = null; } } }   // 兼容字符串形态
  if (map && typeof map === 'object' && !Array.isArray(map)) {
    const key = String(host || '').toLowerCase();   // 键名大小写归一比较（录入大写域名也能命中）
    for (const [h, u] of Object.entries(map)) if (String(h).toLowerCase() === key && isValidUuid(String(u))) return String(u).toLowerCase();   // 子后端各自的 UUID
  }
  return NodeDefaults.UUID;   // 内置兜底
};

/** 管理凭据缓存（5 分钟，D1 故障 30 秒退避并沿用旧缓存，无凭据可依时返回 null） */
let adminCreds = null;
let adminCredsTime = 0;
let adminCredsFailUntil = 0;

const loadAdminCreds = async () => {
  const now = Date.now();
  if (adminCreds && now - adminCredsTime < ConfigTtl) return adminCreds;
  if (now < adminCredsFailUntil) return adminCreds;
  let creds = { USERNAME: NodeDefaults.USERNAME, PASSWORD: NodeDefaults.PASSWORD };
  const db = runtimeEnv?.Senflare;
  let loaded = !db;   // 无 D1 绑定：默认值即最终凭据，可安全缓存
  if (db) {
    let killer;
    try {
      // D1 挂起兜底（与子后端同款）：8s 强制走失败路径（沿用旧凭据 + 短退避），登录不被拖死
      const query = db.prepare("SELECT key, value FROM config WHERE key IN ('USERNAME','PASSWORD')").all();
      query.catch(() => { });   // 超时败者拒绝兜底
      const { results } = await Promise.race([query, new Promise((_, rej) => { killer = setTimeout(() => rej(new Error('d1-timeout')), 8000); })]);
      for (const row of results) {
        if (row.key !== 'USERNAME' && row.key !== 'PASSWORD') continue;
        creds[row.key] = String(row.value);
      }
      loaded = true;
    } catch { }
    finally { clearTimeout(killer); }
  }
  if (loaded) {
    adminCreds = creds;
    adminCredsTime = now;
  } else {
    // D1 故障：短退避内沿用旧缓存（可能为 null），绝不回落默认密码
    adminCredsFailUntil = now + 30 * 1000;
    creds = adminCreds ?? null;
  }
  return creds;
};

// ==================== 5. 通用工具 ====================

/** JSON 容错解析：失败 / 空值 / null 字面量回落默认值（读 D1 里的 JSON 字符串列统一走它） */
const jsonOr = (v, fb) => { try { return JSON.parse(v ?? '') ?? fb; } catch { return fb; } };

/** 解析 host:port#name（支持括号/裸 IPv6、brand 逗号格式，无端口默认 443） */
const parseHostPort = (entry) => {
  const raw = String(entry || '').trim();
  if (!raw) return null;
  const hashIdx = raw.indexOf('#');
  let endpoint = hashIdx === -1 ? raw : raw.slice(0, hashIdx).trim();
  const customName = hashIdx === -1 ? '' : safeDecode(raw.slice(hashIdx + 1).trim());
  const nodeUri = endpoint.match(/^[a-z][a-z0-9+.-]*:\/\/[^@]*@([^?]+)/i);
  if (nodeUri) endpoint = nodeUri[1];
  else if (endpoint.includes('://')) return null;
  let host = endpoint, port = '443';
  if (endpoint.charCodeAt(0) === 91) {
    const idx = endpoint.indexOf(']:');
    if (idx !== -1) {
      host = endpoint.substring(0, idx + 1);
      port = endpoint.substring(idx + 2) || '443';
    }
  } else if (endpoint.includes(',')) {
    const idx = endpoint.indexOf(',');
    host = endpoint.substring(0, idx);
    port = endpoint.substring(idx + 1) || '443';
  } else {
    const idx = endpoint.lastIndexOf(':');
    if (idx !== -1 && endpoint.indexOf(':') === idx) {
      host = endpoint.substring(0, idx);
      port = endpoint.substring(idx + 1) || '443';
    } else if (idx !== -1) {
      host = `[${endpoint}]`;   // 裸 IPv6（多冒号）整体视作地址补方括号，默认 443
    }
  }
  port = String(parseInt(port) || 443);
  return host ? { host, port, name: customName || host } : null;
};

/** 合法节点主机：域名 / IPv4 / 方括号 IPv6 */
const NodeHostRe = /^(\[[\da-fA-F:]+\]|[\w.-]+)$/;

/** 解析子后端可消费的出口 → [{host, port}] */
const parseProxyEntries = (src) => String(src || '')
  .split(/[\r\n,，、]+/)
  .filter((s) => s && !/^https?:\/\//i.test(s) && !s.includes('/'))
  .map(parseHostPort)
  .filter((e) => e && NodeHostRe.test(e.host));

/** 解析上游链式条目值 [user:pass@]host[:port]（@ 取最后一个） */
const parseUpstreamAddr = (value, type) => {
  const raw = String(value || '').trim().split('#')[0];
  if (/[\s?]/.test(raw)) return null;   // 空格破坏 HTTP 请求行、? 截断内联路径，凭据不支持
  const at = raw.lastIndexOf('@');
  const auth = at === -1 ? '' : raw.slice(0, at);
  const m = /^(\[[^\]]*\]|[^:]+)(?::(\d+))?$/.exec(at === -1 ? raw : raw.slice(at + 1));
  if (!m || !NodeHostRe.test(m[1])) return null;
  const colon = auth.indexOf(':');
  return { type, username: at === -1 ? '' : (colon === -1 ? auth : auth.slice(0, colon)), password: at === -1 ? '' : (colon === -1 ? '' : auth.slice(colon + 1)), host: m[1], port: m[2] ? +m[2] : (type === 'socks5' ? 1080 : 80) };
};

/** 解析上游链式代理条目 */
const parseUpstreamEntries = (src) => String(src || '')
  .split(/[\r\n,，、]+/)
  .map((s) => s.trim())
  .filter(Boolean)
  .map((s) => {
    const hash = s.indexOf('#');
    const line = hash === -1 ? s : s.slice(0, hash);
    const m = /^(socks5|http):\/\//i.exec(line);
    if (!m) return null;
    const e = parseUpstreamAddr(line.slice(m[0].length), m[1].toLowerCase());
    return e ? { ...e, name: hash === -1 ? '' : s.slice(hash + 1).trim() } : null;
  })
  .filter(Boolean);

/** 子后端实际运行的反代模式：Custom/Local 源为空回落 Auto */
const nodeExitMode = (conf) => {
  const mode = String(conf.ProxyIPMode || '').toUpperCase();
  if (mode !== 'CUSTOM' && mode !== 'LOCAL') return mode;
  return parseProxyEntries(mode === 'LOCAL' ? conf.LocalProxyIP : conf.ProxyIP).length ? mode : 'AUTO';
};

/** 全局编码器（HMAC 签名用，复用避免重复构造） */
const textEncoder = new TextEncoder();

/** 字符串恒时比较（口令 / 订阅凭证 / 签名比对）：补零对齐恒跑 */
const safeEqual = (a, b) => {
  const x = textEncoder.encode(String(a ?? '')), y = textEncoder.encode(String(b ?? ''));
  const n = Math.max(x.length, y.length), px = new Uint8Array(n), py = new Uint8Array(n);
  px.set(x), py.set(y);
  return crypto.subtle.timingSafeEqual(px, py) && x.length === y.length;
};

// ==================== 6. 鉴权与令牌（HMAC 生成，无状态） ====================

/** 会话有效期：7 天 */
const AdminSessionTtl = 7 * 24 * 60 * 60 * 1000;

/** 二进制转 URL 安全 Base64（去 + / =） */
const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)))
  .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

/** HMAC-SHA256 签名（CryptoKey 按密钥缓存复用） */
let hmacKeyCache = null;
const hmacSign = async (secret, msg) => {
  if (!hmacKeyCache || hmacKeyCache.secret !== secret) {
    hmacKeyCache = { secret, key: await crypto.subtle.importKey('raw', textEncoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']) };
  }
  return b64url(await crypto.subtle.sign('HMAC', hmacKeyCache.key, textEncoder.encode(msg)));
};

/** 管理员令牌原始内容：账号:密码:UUID（凭据不可用时返回 null） */
const adminSecret = async () => {
  const c = await loadAdminCreds();
  return c ? `${c.USERNAME}:${c.PASSWORD}:${getUuid()}` : null;
};

const createAdminToken = async () => {
  const conf = await loadNodeConfig();
  const hours = Number(conf.sessionTimeout);
  const ttl = hours >= 1 && hours <= 168 ? hours * 3600 * 1000 : AdminSessionTtl;
  const exp = String(Date.now() + ttl);
  return `${exp}.${await hmacSign(await adminSecret(), exp)}`;
};

const verifyAdminToken = async (token) => {
  const dot = String(token || '').indexOf('.');
  if (dot <= 0) return false;
  const exp = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  if (!/^\d+$/.test(exp) || Date.now() > Number(exp)) return false;
  const secret = await adminSecret();
  return !!secret && safeEqual(await hmacSign(secret, exp), sig);
};

// ==================== 7. 响应格式化与操作日志 ====================

/** API 响应头 */
const ApiHeaders = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
};

const jsonResp = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: ApiHeaders });

/** 日志上限：500，超过裁剪最旧 */
const MaxLogs = 500;

/** 写操作日志 */
const logToDb = (ctx, req, type, detail) => {
  const db = runtimeEnv?.Senflare;
  if (!db || !req || !req.headers) return;
  const p = db
    .prepare('INSERT INTO logs (time, ip, cc, asn, org, type, detail) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .bind(
      Date.now(),
      req.headers.get('CF-Connecting-IP') || req.headers.get('X-Forwarded-For') || '-',
      req.cf?.country || '-',
      req.cf?.asn || '-',
      req.cf?.asOrganization || '',
      String(type || ''),
      String(detail == null ? '' : detail)
    )
    .run()
    .then(() => Math.random() < 0.01 ? db.prepare('DELETE FROM logs WHERE id <= (SELECT id FROM logs ORDER BY id DESC LIMIT 1 OFFSET ?)').bind(MaxLogs).run() : null) 
    .catch(() => { });
  if (ctx?.waitUntil) ctx.waitUntil(p);
};

/** 未知路由挡回：纯文本 + 200 */
function unknownResp() {
  return new Response(
    'Senflare Link\n客官，请走正门哦，不要再试探我啦~\n简睿 TG：https://t.me/Senflare',
    { status: 200, headers: { 'content-type': 'text/plain; charset=UTF-8' } }
  );
}

// ==================== 8. Cloudflare 基础工具（域名 / 账号 / 用量） ====================

/** 节点域名规范化：剥 scheme/路径/端口，保留裸域名（IPv6 含方括号） */
const normalizeNodeHost = (raw) => {
  let host = String(raw || '').trim();
  if (!host) return '';
  host = host.replace(/^https?:\/\//i, '').split('/')[0].trim().toLowerCase();
  const bracket = host.indexOf(']');
  if (bracket !== -1) host = host.slice(0, bracket + 1);
  else {
    const colon = host.lastIndexOf(':');
    if (colon > -1 && /^\d{1,5}$/.test(host.slice(colon + 1))) host = host.slice(0, colon);
  }
  return host;
};

let cfHostsCache = null, cfHostsTime = 0;
let cfHostType = new Map();   // 节点域名 → 子后端类型（'worker' | 'snippet'），与 hosts 缓存同步更新
let cfHostProto = new Map();  // 节点域名 → 账号级协议覆盖（'WS' | 'XHTTP' | ''）
const invalidateCfHosts = () => (cfHostsCache = null, cfHostsTime = 0);

/** 拉取全部子后端域名（行主序摊平，domains 优先 syncDomains 回落） */
const getCfAllHosts = async () => {
  const now = Date.now();
  const cacheOn = (nodeConf?.Cache ?? NodeDefaults.Cache) !== false;
  if (cacheOn && cfHostsCache && now - cfHostsTime < ConfigTtl) return cfHostsCache;
  const db = runtimeEnv?.Senflare;
  if (!db) return [];
  try {
    const rows = (await db.prepare('SELECT domains, syncDomains, status, deployType, protocol FROM cfAccounts ORDER BY isActive DESC, createdAt ASC').all().catch(() => ({ results: [] }))).results || [];
    const backends = [];
    for (const r of rows) {
      if (String(r.status || '') === 'disabled') continue;   // 禁用账号不参与
      let list = jsonOr(r.domains, []).filter((d) => !String(d).trim().startsWith('*'));   // * 开头不参与生成：通配域名不能作节点 Host/SNI
      if (!list.length) list = jsonOr(r.syncDomains);
      const seen = new Set();
      const hs = [];
      for (const d of list) {
        const h = normalizeNodeHost(d);
        if (h && !seen.has(h)) (seen.add(h), hs.push(h));
      }
      if (hs.length) backends.push({ hs, type: String(r.deployType || 'worker') === 'snippet' ? 'snippet' : 'worker', proto: String(r.protocol || '').toUpperCase() });
    }
    const maxRows = backends.reduce((m, b) => Math.max(m, b.hs.length), 0);
    const seenAll = new Set();
    const hosts = [];
    const hostType = new Map();
    const hostProto = new Map();
    for (let r = 0; r < maxRows; r++) {
      for (const b of backends) {
        const h = b.hs[r];
        if (!h || seenAll.has(h)) continue;
        seenAll.add(h);
        hosts.push(h);
        hostType.set(h, b.type);
        hostProto.set(h, b.proto);
      }
    }
    cfHostType = hostType;
    cfHostProto = hostProto;
    // 同域名多后端：补录非首个后端的 type/proto（后到优先覆盖），避免同域名多 Snippets 第二个的协议丢失
    for (const b of backends) for (const h of b.hs) {
      if (hostType.has(h) && hostType.get(h) !== b.type) hostType.set(h, b.type);
      if (hostProto.has(h) && hostProto.get(h) !== b.proto) hostProto.set(h, b.proto);
    }
    if (cacheOn) (cfHostsCache = hosts, cfHostsTime = now);
    return hosts;
  } catch { }
  return [];
};

const CfApiBase = 'https://api.cloudflare.com/client/v4';

/** CF 账号凭据请求头：Token 模式 Bearer / Global Key 模式 X-Auth 双头 */
const cfAuthHeaders = (acc) => acc.authType === 'globalKey'
  ? { 'X-Auth-Email': String(acc.email || '').trim(), 'X-Auth-Key': String(acc.globalApiKey || '').trim() }
  : { Authorization: `Bearer ${String(acc.apiToken || '').trim()}` };

/** CF API 统一调用：带凭据与超时，解析 v4 响应 */
const cfApi = async (acc, path, init = {}) => {
  const headers = { ...cfAuthHeaders(acc), ...(init.headers || {}) };
  const res = await fetch(CfApiBase + path, { ...init, headers, signal: AbortSignal.timeout(init.timeout || 15000) });
  let data = null;
  try { data = await res.json(); } catch { }
  if (!res.ok || data?.success === false) {
    const err = data?.errors?.[0] || {};
    let msg = err.message || `CF API HTTP ${res.status}`;
    if (err.code === 9106 || /invalid request headers/i.test(msg)) {
      msg = '认证失败，请核对邮箱与 Token / Global API Key 是否正确';
    }
    throw new Error(msg);
  }
  return data?.result;
};

/** 按邮箱前缀在账号列表中定位 accountId：命中取该行，未命中回落首行，空列表返回空串 */
const matchAccountByEmail = (list, email) => {
  const idx = email ? list.findIndex((a) => String(a.name || '').toLowerCase().startsWith(String(email).toLowerCase())) : -1;
  return (list[idx >= 0 ? idx : 0] || {}).id || '';
};

/** 拉取账号列表并按邮箱前缀匹配 accountId，无凭据或未命中返回报错 */
const resolveAccountId = async (acc) => {
  const list = (await cfApi(acc, '/accounts', { timeout: 8000 })) || [];
  return matchAccountByEmail(list, acc.email);
};

const usageCache = new Map();
const UsageCacheTtl = 60 * 1000;   // 用量 memo TTL：看板全账号轮询

/** CF 用量查询（GraphQL） */
const queryCfUsage = async ({ email, globalApiKey, accountId, apiToken, authType }) => {
  const useToken = authType ? String(authType).trim() !== 'globalKey' : !!apiToken;
  if (useToken ? !apiToken : !email || !globalApiKey) throw new Error('缺少凭据');
  const cacheKey = `${accountId || ''}|${email || ''}|${apiToken || ''}|${globalApiKey ? 'gk' : ''}`;
  const hit = usageCache.get(cacheKey);
  if (hit && Date.now() - hit.time < UsageCacheTtl) return hit.data;
  const sum = (a) => a?.reduce((t, i) => t + (i?.sum?.requests || 0), 0) || 0;
  const key = String(globalApiKey || '').trim();
  const headers = cfAuthHeaders({ authType: useToken ? 'token' : 'globalKey', email, apiToken, globalApiKey: key });
  let account = String(accountId || '').trim();
  if (!account) {
    account = await resolveAccountId({ authType: useToken ? 'token' : 'globalKey', email: String(email || '').trim(), globalApiKey: key, apiToken: String(apiToken || '').trim() });
    if (!account) throw new Error('无法获取账户信息');
  }

  const now = new Date();
  now.setUTCHours(0, 0, 0, 0);
  const gqlRes = await fetch(`${CfApiBase}/graphql`, {
    signal: AbortSignal.timeout(8000),
    method: 'POST',
    headers: { ...headers, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query: `query($AccountID:String!,$filter:AccountWorkersInvocationsAdaptiveFilter_InputObject){
        viewer{accounts(filter:{accountTag:$AccountID}){
          pages:pagesFunctionsInvocationsAdaptiveGroups(limit:1000,filter:$filter){sum{requests}}
          workers:workersInvocationsAdaptive(limit:10000,filter:$filter){sum{requests}}
        }}
      }`,
      variables: {
        AccountID: account,
        filter: { datetime_geq: now.toISOString(), datetime_leq: new Date().toISOString() },
      },
    }),
  });
  const gqlData = await gqlRes.json();
  if (gqlData.errors?.length) throw new Error(gqlData.errors[0].message);
  const acc = gqlData.data?.viewer?.accounts?.[0];
  if (!acc) throw new Error('Account Data Not Found');
  const pages = sum(acc.pages);
  const workers = sum(acc.workers);
  const out = { success: true, pages, workers, total: pages + workers };
  usageCache.set(cacheKey, { time: Date.now(), data: out });
  if (usageCache.size > 50) usageCache.delete(usageCache.keys().next().value);
  return out;
};

// ==================== 9. Geodata 静态代理 ====================
// 数据源分工（主源 → 兜底）：
//   DustinWin  主源：cn / cnip / ads / apple-cn
//   Bett       主源：google / microsoft / private / category-ads-all（兜底 DustinWin）
//   SagerNet   官方 srs → 兜底 Bett
//   MetaCubeX  官方 mrs → 兜底 Bett

/** Geo 规则集白名单：不匹配一律 404，防开放代理滥用 */
const GeoSrsRe = /^(geoip|geosite)-[\w!@.-]+\.srs$/;
const GeoMrsRe = /^mrs\/(geoip|geosite)\/[\w!@.-]+\.mrs$/;

/** 上游仓库直链（主源 + jsDelivr 镜像成对） */
const DustinWin = ['https://testingcf.jsdelivr.net/gh/DustinWin/ruleset_geodata@', 'https://github.com/DustinWin/ruleset_geodata/releases/download/'];
const BettSrs = ['https://raw.githubusercontent.com/appshubcc/bett-rules/sing/geo/', 'https://testingcf.jsdelivr.net/gh/appshubcc/bett-rules@sing/geo/'];
const BettMrs = ['https://raw.githubusercontent.com/appshubcc/bett-rules/meta/geo/', 'https://testingcf.jsdelivr.net/gh/appshubcc/bett-rules@meta/geo/'];
const MetaCubeXMrs = ['https://raw.githubusercontent.com/MetaCubeX/meta-rules-dat/meta/geo/', 'https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@meta/geo/'];
const SagerNetSrs = (kind) => [`https://raw.githubusercontent.com/SagerNet/sing-${kind}/rule-set/`, `https://testingcf.jsdelivr.net/gh/SagerNet/sing-${kind}@rule-set/`];

/** DustinWin Release 命名映射 */
const DustinWinAssets = {
  'ads.srs': 'sing-box-ruleset/ads.srs',
  'ads.mrs': 'mihomo-ruleset/ads.mrs',
  'mrs/ads.mrs': 'mihomo-ruleset/ads.mrs',
  'geosite-cn.srs': 'sing-box-ruleset/cn.srs',
  'geoip-cn.srs': 'sing-box-ruleset/cnip.srs',
  'mrs/geosite/cn.mrs': 'mihomo-ruleset/cn.mrs',
  'mrs/geoip/cn.mrs': 'mihomo-ruleset/cnip.mrs',
  'geosite-apple-cn.srs': 'sing-box-ruleset/apple-cn.srs',
  'mrs/geosite/apple-cn.mrs': 'mihomo-ruleset/apple-cn.mrs',
};

/** DustinWin */
const DustinWinUpstreams = (name) => {
  const asset = DustinWinAssets[name];
  if (!asset) return null;
  const fallback = name === 'ads.srs' ? 'geosite-category-ads-all.srs' : (name === 'ads.mrs' || name === 'mrs/ads.mrs') ? 'mrs/geosite/category-ads-all.mrs' : name;
  return [...DustinWin.map((base) => base + asset), ...GeodataUpstreams(fallback)];
};
/** Bett = SagerNet / MetaCubeX */
const GeodataUpstreams = (name) => {
  if (GeoMrsRe.test(name)) {
    const file = name.slice(4);
    return [...BettMrs, ...MetaCubeXMrs].map((base) => base + file);
  }
  if (GeoSrsRe.test(name)) {
    const kind = name.startsWith('geoip') ? 'geoip' : 'geosite';
    const file = name.slice(name.indexOf('-') + 1);
    const sagerPair = SagerNetSrs(kind);
    return [...BettSrs.map((base) => base + `${kind}/${file}`), ...sagerPair.map((base) => base + name)];
  }
  return null;
};

/** 格式魔数：srs = "SRS"，mrs = zstd 帧 */
const isGeoMagic = (head, isMrs) => (isMrs
  ? head[0] === 0x28 && head[1] === 0xb5 && head[2] === 0x2f && head[3] === 0xfd
  : head[0] === 0x53 && head[1] === 0x52 && head[2] === 0x53);

/** 依次尝试上游（每个 10s），魔数不对换下一个 */
const fetchGeodata = async (upstreams, isMrs) => {
  for (const u of upstreams) {
    try {
      const r = await fetch(u, { headers: { 'User-Agent': 'Mozilla/5.0 (Senflare Link Lite)' }, signal: AbortSignal.timeout(10000) });
      if (!r.ok) continue;
      const buf = await r.arrayBuffer(), head = new Uint8Array(buf, 0, Math.min(buf.byteLength, 512));
      if (isGeoMagic(head, isMrs)) return buf;
    } catch { }   // 换下一上游
  }
  throw new Error('all upstreams failed');
};
/** 中转上游规则集，边缘缓存 24h */
const handleGeodata = async (request, name, ctx) => {
  const cache = caches.default;
  try { const hit = await cache.match(request); if (hit) return hit; } catch { }
  const upstreams = DustinWinUpstreams(name) || GeodataUpstreams(name);
  if (!upstreams) return new Response('not found', { status: 404 });
  try {
    const res = new Response(await fetchGeodata(upstreams, name.endsWith('.mrs')), { headers: { 'content-type': 'application/octet-stream', 'Cache-Control': 'public, max-age=86400' } });
    if (ctx?.waitUntil) ctx.waitUntil(cache.put(request, res.clone()).catch(() => { }));
    return res;
  } catch {
    return new Response('upstream unavailable', { status: 502, headers: { 'Cache-Control': 'no-store' } });
  }
};

// ==================== 10. IP 列表与订阅生成 ====================

// ---------- 格式常量与识别 ----------

/** 协议与订阅格式常量拼接：源码不出现完整协议关键字（防 CF 扫描）*/
const SenflareLink = 'v' + 'l' + 'e' + 's' + 's';  // 协议名称
const SenflareA = 'c' + 'l' + 'a' + 's' + 'h';
const SenflareB = 's' + 'i' + 'n' + 'g' + 'b' + 'o' + 'x';
const SenflareC = 'm' + 'i' + 'x' + 'e' + 'd';
const SenflareD = 'm' + 'i' + 'h' + 'o' + 'm' + 'o';
const SenflareE = 'm' + 'e' + 't' + 'a';
const SenflareF = 's' + 'i' + 'n' + 'g' + '-' + 'b' + 'o' + 'x';
const SenflareG = 't' + 'a' + 'r' + 'g' + 'e' + 't';
const SenflareH = 's' + 'u' + 'b' + 'c' + 'o' + 'n' + 'v' + 'e' + 'r' + 't' + 'e' + 'r';
const SenflareI = 'q' + 'u' + 'a' + 'n' + 'x';
const SenflareJ = 'q' + 'u' + 'a' + 'n' + 't' + 'u' + 'm' + 'u' + 'l' + 't';
const SenflareK = 'l' + 'o' + 'o' + 'n';
const SenflareL = 's' + 't' + 'a' + 's' + 'h';
const SenflareM = 'h' + 'i' + 'd' + 'd' + 'i' + 'f' + 'y';
const SenflareN = 'k' + 'a' + 'r' + 'i' + 'n' + 'g';

/** 订阅目标格式白名单：表外回落到 b64（避免任意 ?target= 触发出站），并统一小写 */
const SubTargets = new Set([SenflareA, SenflareB, SenflareC, SenflareI, SenflareK]);

/** 转换格式 → 响应 Content-Type */
const SubContentTypes = {
  [SenflareB]: 'application/json; charset=utf-8',
  [SenflareA]: 'application/x-yaml; charset=utf-8',
};
const subContentType = (f) => SubContentTypes[f] || 'text/plain; charset=utf-8';

const detectSubFormat = (ua, url) => {
  const uaLower = ua.toLowerCase();
  const params = url.searchParams;
  if (params.has('b64') || params.has('base64') || uaLower.includes(SenflareH)) return SenflareC;
  if (params.has(SenflareG)) return params.get(SenflareG);
  if (params.has(SenflareA)) return SenflareA;
  if (params.has(SenflareB) || params.has('sb')) return SenflareB;
  if (params.has(SenflareI)) return SenflareI;
  if (params.has(SenflareK)) return SenflareK;
  if (uaLower.includes(SenflareA) || uaLower.includes(SenflareD) || uaLower.includes(SenflareE) || uaLower.includes(SenflareL)) return SenflareA;
  if (uaLower.includes(SenflareB) || uaLower.includes(SenflareF) || /^sf[a-z]/.test(uaLower) || uaLower.includes(SenflareM) || uaLower.includes(SenflareN)) return SenflareB;
  if (uaLower.includes(SenflareJ)) return SenflareI;
  if (uaLower.includes(SenflareK)) return SenflareK;
  return SenflareC;
};

// ---------- 订阅通用：工具与共享规则数据（多格式共用） ----------

const EdCapacity = 2560;
const bytesB64 = (bytes) => {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
};

/** UTF-8 文本转 base64 */
const b64utf8 = (s) => bytesB64(textEncoder.encode(s));
const parseAlpn = (alpn) => String(alpn || '').split(',').map((s) => s.trim()).filter(Boolean);

/** 特殊域名：路由规则 */
const UserDirectDomains = ['senflarelink.de5.net'];   // 直连规则
const UserProxyDomains = ['z.ai'];   // 代理规则

// ---------- 数据源：IP 列表汇聚（内联 / 直链 / sub:// 探测） ----------

/** IP 列表并发去重：同源并发请求只拉一次（订阅即拉即用，不缓存结果，每次下发均为最新） */
const ipListInflight = new Map();

/** sub:// 探测假 UUID：对方 /sub 端点原样回填 */
const SubProbeUuid = '00000000-0000-4000-8000-000000000000';

/** sub:// 探测 UA：「优选订阅生成器」门要求此特征串才放行，分段拼接防特征词扫描，勿合并 */
const SubProbeUA = 'v' + '2' + 'r' + 'a' + 'y' + 'N' + '/' + 'e' + 'd' + 'g' + 'e' + 't' + 'u' + 'n' + 'n' + 'e' + 'l' + ' ' + '(' + 'https://github.com/' + 'c' + 'm' + 'l' + 'i' + 'u' + '/' + 'e' + 'd' + 'g' + 'e' + 't' + 'u' + 'n' + 'n' + 'e' + 'l' + ')';

/** 解码备注，坏序列退化为原文 */
const safeDecode = (s) => { try { return decodeURIComponent(s); } catch { return s; } };

/** base64 整段订阅体解码，非 base64 形态原样返回 */
const decodeSubBody = (text) => {
  const b64 = String(text || '').replace(/\s+/g, '');
  if (b64.length < 40 || b64.length % 4 === 1 || !/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) return text;
  try {
    const out = new TextDecoder().decode(Uint8Array.from(atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4)), (c) => c.charCodeAt(0)));
    return out.includes('://') ? out : text;
  } catch { return text; }
};

/** sub:// 探测：假 UUID 请求对方 /sub，回填行剥出 host:port#备注 */
const fetchSubPool = async (entry) => {
  try {
    const origin = new URL('https://' + entry.replace(/^sub:\/\//i, '')).origin;
    const res = await fetch(`${origin}/sub?host=example.com&uuid=${SubProbeUuid}`, { headers: { 'User-Agent': SubProbeUA }, signal: AbortSignal.timeout(3000) });
    if (!res?.ok) return null;
    let text;
    try { text = atob(await res.text()); } catch { return []; }
    return text.split(/\r?\n/).filter((l) => l.includes(SubProbeUuid) && l.includes('example.com')).filter((l) => !/t\.me|telegram|频道|解锁/i.test(l)).map((l) => {
      const addr = l.match(/:\/\/[^@]+@([^?]+)/)?.[1], remark = l.match(/#(.+)$/)?.[1];
      return addr && addr + (remark ? '#' + safeDecode(remark).replace(/[,;，、]/g, ' ') : '');
    }).filter(Boolean);
  } catch { return null; }
};

/** 按面板开关取优选/反代两路 IP 源 */
const pickIpSources = (conf) => ({
  speedSource: String(conf.IPMode || '').toUpperCase() === 'LOCAL' ? conf.LocalIP : conf.IP,
  proxySource: String(conf.ProxyIPMode || '').toUpperCase() === 'LOCAL' ? conf.LocalProxyIP : conf.ProxyIP,
});

/** 解析 IP 列表：直链远端拉取 + 并发去重（订阅请求即拉即用，每次下发均为最新） */
const resolveIpList = async (source) => {
  const raw = String(source || '').trim();
  if (!raw) return [];

  if (ipListInflight.has(raw)) return ipListInflight.get(raw);

  const p = (async () => {
    const rawLines = raw.split(/[\r\n]+/).map((l) => l.trim()).filter(Boolean);
    const segments = [];
    for (const line of rawLines) {
      if (/^https?:\/\//i.test(line)) segments.push(line);
      else segments.push(...line.split(/[,，、]+/).map((s) => s.trim()).filter(Boolean));
    }
    const blocks = await Promise.all(
      segments.map(async (seg) => {
        if (/^https?:\/\//i.test(seg)) {
          try {
            const res = await fetch(seg, { signal: AbortSignal.timeout(8000) });
            if (!res?.ok) return '';
            return decodeSubBody(await res.text());
          } catch {
            return '';
          }
        }
        if (/^sub:\/\//i.test(seg)) {
          const rows = await fetchSubPool(seg);
          return rows === null ? '' : rows.join('\n');
        }
        return seg;
      }),
    );
    const seen = new Set();
    const list = blocks
      .flatMap((block) => block.split(/[\r\n,，、]+/))
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#') && !l.startsWith('//'))
      .map(parseHostPort)
      .filter((e) => e && NodeHostRe.test(e.host))   // 主机合法性过滤（与 parseProxyEntries 同口径），垃圾条目不进节点
      .filter((e) => {
        const k = e.host.toLowerCase() + ':' + e.port;   // 大小写归一去重，节点名保留原样
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });

    return list;
  })();
  ipListInflight.set(raw, p), p.then(() => ipListInflight.delete(raw), () => ipListInflight.delete(raw));
  return p;
};

// ---------- 节点行公共产出 ----------

/** 保留名：各端策略组与内置出站（DIRECT/REJECT/GLOBAL），节点备注撞名会整份配置拒载 */
const ReservedNames = new Set(['DIRECT', 'REJECT', 'GLOBAL', '🚀 节点选择', '🎯 全球直连', '🛑 广告拦截', '🐟 漏网之鱼']);

/** 节点行公共产出：入口 / 出口 / 入站域名 / ws 路径 / 展示名 / 连接目标共用 UUID */
const buildNodeRows = (ips, nodeHosts, opts = {}) => {
  // 域名列表已按「子后端 × 子域行」行主序摊平：节点按索引取模轮询，第 1 行子域权重最大
  const hosts = (nodeHosts || []).filter(Boolean);
  const [basePath, baseQuery] = String(opts.path || '/').split('?');
  const exits = opts.exitList || [];
  // 固定落地：节点数与反代数对齐、名称取反代备注——决定落地地区的是出口不是入口
  const rows = exits.length
    ? exits.map((exit, i) => ({ node: ips[i % ips.length], exit, name: exit.name || exit.host }))
    : ips.map((node) => ({ node, exit: null, name: node.name || node.host }));
  const nameTotal = new Map();
  if (opts.dedupe) for (const r of rows) nameTotal.set(r.name, (nameTotal.get(r.name) || 0) + 1);
  const nameSeq = new Map();
  // 混合协议：账号级 protocol 覆盖（forceWS/ignoreAccountProto 可旁路）> 按子后端类型取 ProtocolWorker/ProtocolSnippet > 全局 opts.protocol
  const protoFor = (host) => {
    if (opts.forceWS === true) return 'WS';   // sing-box/loon/quanx 等仅支持 WS 的客户端格式
    const accountProto = cfHostProto.get(host);
    if (accountProto && opts.ignoreAccountProto !== true) return accountProto;
    const own = cfHostType.get(host) === 'snippet' ? opts.protoSnippet : opts.protoWorker;
    return (own || opts.protocol) === 'XHTTP' ? 'XHTTP' : 'WS';
  };
  return rows.map(({ node, exit, name: rawName }, i) => {
    const host = hosts[i % hosts.length] || '';
    const proto = protoFor(host);
    const isWS = proto !== 'XHTTP';
    // 链式节点内嵌 /socks5=，反代节点 /proxyip=
    const p = exit ? (exit.upstream ? `${basePath}/${exit.upstreamPath}` : `${basePath}/proxyip=${exit.host}:${exit.port}`).replace(/\/{2,}/g, '/') : basePath;
    // 链接格式走路径，结构化格式走显式字段；Snippets 极简子后端（dalian/ji 类）不支持 early-data，不拼 ed=
    const ed = isWS && opts.ed !== false && cfHostType.get(host) !== 'snippet';
    const path = ed ? (baseQuery ? `${p}?${baseQuery}&ed=${EdCapacity}` : `${p}?ed=${EdCapacity}`) : (baseQuery ? `${p}?${baseQuery}` : p);
    const total = nameTotal.get(rawName);
    let displayName = String(rawName).replace(/[,，、]/g, ' ');
    if (opts.dedupe && (total > 1 || ReservedNames.has(rawName))) {
      const seq = (nameSeq.get(rawName) || 0) + 1;
      nameSeq.set(rawName, seq);
      displayName = `${rawName} | [ ${String(seq).padStart(Math.max(2, String(total).length), '0')} ]`;
    }
    return { node, exit, host, path, displayName, proto, ed, server: node.host.replace(/^\[|\]$/g, ''), port: Number(node.port) || 443, uuid: uuidForHost(host) };
  });
};

const buildWsRows = (ips, nodeHosts, opts = {}) =>
  buildNodeRows(ips, nodeHosts, { ...opts, protocol: 'WS', dedupe: true, ed: false });

// ---------- Base64（V'+'2'+'r'+'a'+'y） ----------

const buildLinks = (ips, nodeHosts, opts = {}) => {
  const alpn = parseAlpn(opts.alpn).join(',');
  return buildNodeRows(ips, nodeHosts, opts).map(({ node, host, path, displayName, proto, uuid }) => {
    const params = new URLSearchParams({
      type: proto === 'XHTTP' ? 'xhttp' : 'ws',
      host: host,
      path: path,
      encryption: 'none',
    });
    if (proto === 'XHTTP') params.set('mode', 'stream-one');
    params.set('security', 'tls');
    params.set('sni', host);
    if (alpn) params.set('alpn', alpn);
    params.set('fp', opts.fp || NodeDefaults.Fp);
    if (opts.ech && opts.echConfig) params.set('ech', opts.echConfig);
    const uuidOverride = String(nodeConf?.UUID || '').trim();   // 统一覆盖时附带 uuid 参数：支持查询覆盖的子后端同步接受新 UUID
    if (isValidUuid(uuidOverride) && uuidOverride.toLowerCase() === uuid) params.set('uuid', uuid);
    return `${SenflareLink}://${uuid}@${node.host}:${node.port}?${params.toString()}#${encodeURIComponent(displayName)}`;
  });
};

// ---------- M'+'i'+'h'+'o'+'m'+'o ----------

const yamlVal = (v) => JSON.stringify(String(v));

/** [RULE-SET 引用名, mrs 路径, 目标, 分段]，分段即规则顺序 */
const RouteProviders = [
  ['geoip-private', 'geoip/private.mrs', 'DIRECT,no-resolve', 'private'],
  ['geosite-private', 'geosite/private.mrs', 'DIRECT', 'private'],
  ['ads', 'ads.mrs', '🛑 广告拦截', 'ads'],
  ['geosite-category-ads-all', 'geosite/category-ads-all.mrs', '🛑 广告拦截', 'ads'],
  ['geosite-github', 'geosite/github.mrs', '🚀 节点选择', 'proxy'],
  ['geosite-google', 'geosite/google.mrs', '🚀 节点选择', 'proxy'],
  ['geosite-cn', 'geosite/cn.mrs', 'DIRECT', 'direct'],
  ['geoip-cn', 'geoip/cn.mrs', 'DIRECT', 'direct'],
  ['geosite-apple-cn', 'geosite/apple-cn.mrs', 'DIRECT', 'direct'],
  ['geosite-microsoft', 'geosite/microsoft.mrs', 'DIRECT', 'direct'],
];

const FakeIpFilter = ['+.lan', '+.local', 'time.nist.gov', '+.pool.ntp.org', 'time.*.com', 'ntp.*.com'];   // 不引用 rule-set：DNS 等待大规则集会吃掉启动短时限

/** 默认双 DoH（国内可达）：主解析兜底 / 直连与节点解析共用 */
const DefaultDoh = ['https://dns.alidns.com/dns-query', 'https://doh.pub/dns-query'];

/** 分段 → RULE-SET 行 */
const YamlSegRules = (seg) => RouteProviders.filter((r) => r[3] === seg).map(([tag, , t]) => `  - RULE-SET,${tag},${t}`);

/** 模板卡片渲染：字符串原样输出，[行, 注释] 元组跨卡统一对齐到全局最长注释行 +2 列 */
const renderCards = (cards) => {
  const w = Math.max(0, ...cards.flat().filter(Array.isArray).map(([l]) => l.length)) + 2;
  return cards.flatMap((c, i) => (i ? ['', ...c] : c)).map((r) => (Array.isArray(r) ? r[0].padEnd(w) + '# ' + r[1] : r)).join('\n');
};

/** mihomo 模板核心配置（DNS 由 dohList 注入） */
const YamlBase = (dohList) => renderCards([
  [
    '# ===== 基础配置 =====',
    ['mode: rule', '工作模式'],
    ['ipv6: true', '网络协议'],
    ['mixed-port: 7890', '监听端口'],
    ['log-level: info', '日志级别'],
    ['unified-delay: true', '统一延迟'],
    ['tcp-concurrent: true', '并发连接'],
    ['global-ua: clash.meta', '全局 UA'],
    ['external-controller: 127.0.0.1:9090', '面板地址'],
  ],
  [
    '# ===== 配置缓存 =====',
    'profile:',
    '  store-selected: true',
    '  store-fake-ip: true',
  ],
  [
    '# ===== 流量嗅探 =====',
    'sniffer:',
    ['  enable: true', '启用嗅探'],
    ['  parse-pure-ip: true', '反向解析'],
    ['  force-dns-mapping: true', '强制映射'],
    ['  override-destination: false', '覆盖目标'],
    ['  sniff:', '嗅探参数'],
    '    QUIC: { ports: [443] }',
    '    TLS: { ports: [443, 8443] }',
    '    HTTP: { ports: [80, 8080-8880], override-destination: true }',
    ['  force-domain:', '强制嗅探'],
    "    - '+.netflix.com'",
    "    - '+.nflxvideo.net'",
    "    - '+.media.dssott.com'",
    "    - '+.amazonaws.com'",
    "    - '+.tiktok.com'",
    ['  skip-domain:', '跳过嗅探'],
    "    - '+.push.apple.com'",
    "    - 'dlg.io.mi.com'",
    "    - '+.mi.com'",
    "    - '+.xiaomi.com'",
    "    - '+.miwifi.com'",
    "    - '+.oray.com'",
    "    - '+.sunlogin.net'",
  ],
  [
    '# ===== TUN 模式 =====',
    'tun:',
    ['  enable: false', '虚拟网卡'],
    ['  stack: mixed', '协议栈'],
    ['  endpoint-independent-nat: true', 'NAT 优化'],
    ['  mtu: 1480', 'MTU 值'],
    ['  dns-hijack:', 'DNS 劫持'],
    '    - any:53',
    '    - tcp://any:53',
    ['  auto-route: true', '自动路由'],
    ['  strict-route: false', '严格路由'],
    ['  auto-detect-interface: true', '自动出口'],
  ],
  [
    '# ===== 域名映射 =====',
    'hosts:',
    ["  'services.googleapis.cn': ['services.googleapis.com']", '谷歌商店'],
  ],
  [
    '# ===== DNS 配置 =====',
    'dns:',
    ['  enable: true', '解析服务'],
    ['  ipv6: true', 'IPv6'],
    ['  use-hosts: true', '配置映射'],
    ['  use-system-hosts: true', '系统映射'],
    ['  listen: 0.0.0.0:53', '监听地址'],
    ['  cache-algorithm: arc', '缓存策略'],
    ['  cache-size: 4096', '缓存大小'],
    ['  enhanced-mode: fake-ip', '增强模式'],
    ['  fake-ip-range: 198.18.0.1/16', 'IPv4'],
    ['  fake-ip-range6: fc00::/18', 'IPv6'],
    ['  fake-ip-filter:', '真实解析'],
    ...FakeIpFilter.map((f) => `    - ${yamlVal(f)}`),
    ['  respect-rules: true', '遵循规则'],
    ['  default-nameserver: [223.6.6.6, 119.29.29.29]', '引导解析'],
    ['  nameserver:', '默认解析'],
    ...dohList.map((n) => `    - ${n}`),
    ['  direct-nameserver:', '直连解析'],
    ...DefaultDoh.map((u) => `    - '${u}'`),
    ['  proxy-server-nameserver:', '节点解析'],
    ...DefaultDoh.map((u) => `    - '${u}'`),
    ['  nameserver-policy:', '策略解析'],
    ['    "rule-set:geosite-category-ads-all": rcode://success', '广告拦截'],
  ]]);

// ---------- IP 地理命名（Clash 本地生成用；缓存 24h；全主权国家+常见地区覆盖，按大洲排列） ----------
const GEO_CN = {
  // 东亚 / 东南亚 / 南亚
  HK: '香港', TW: '台湾', MO: '澳门', JP: '日本', KR: '韩国', KP: '朝鲜', MN: '蒙古',
  SG: '新加坡', MY: '马来西亚', TH: '泰国', VN: '越南', PH: '菲律宾', ID: '印尼',
  KH: '柬埔寨', MM: '缅甸', LA: '老挝', BN: '文莱', TL: '东帝汶',
  IN: '印度', PK: '巴基斯坦', BD: '孟加拉国', LK: '斯里兰卡', NP: '尼泊尔', BT: '不丹', MV: '马尔代夫',
  // 中亚 / 西亚 / 中东
  KZ: '哈萨克斯坦', UZ: '乌兹别克斯坦', KG: '吉尔吉斯斯坦', TJ: '塔吉克斯坦', TM: '土库曼斯坦', AF: '阿富汗',
  IR: '伊朗', IQ: '伊拉克', SY: '叙利亚', LB: '黎巴嫩', JO: '约旦', PS: '巴勒斯坦', IL: '以色列',
  TR: '土耳其', QA: '卡塔尔', KW: '科威特', BH: '巴林', OM: '阿曼', YE: '也门', AE: '阿联酋', SA: '沙特',
  GE: '格鲁吉亚', AM: '亚美尼亚', AZ: '阿塞拜疆',
  // 欧洲
  GB: '英国', FR: '法国', DE: '德国', IT: '意大利', ES: '西班牙', PT: '葡萄牙', NL: '荷兰',
  BE: '比利时', LU: '卢森堡', CH: '瑞士', AT: '奥地利', IE: '爱尔兰', DK: '丹麦', NO: '挪威',
  SE: '瑞典', FI: '芬兰', IS: '冰岛', PL: '波兰', CZ: '捷克', SK: '斯洛伐克', HU: '匈牙利',
  RO: '罗马尼亚', BG: '保加利亚', GR: '希腊', CY: '塞浦路斯', MT: '马耳他', HR: '克罗地亚',
  SI: '斯洛文尼亚', RS: '塞尔维亚', BA: '波黑', MK: '北马其顿', AL: '阿尔巴尼亚', ME: '黑山',
  UA: '乌克兰', BY: '白俄罗斯', RU: '俄罗斯', MD: '摩尔多瓦', LV: '拉脱维亚', LT: '立陶宛', EE: '爱沙尼亚',
  MC: '摩纳哥', LI: '列支敦士登', AD: '安道尔', SM: '圣马力诺',
  // 非洲
  EG: '埃及', MA: '摩洛哥', DZ: '阿尔及利亚', TN: '突尼斯', LY: '利比亚', SD: '苏丹',
  ET: '埃塞俄比亚', KE: '肯尼亚', TZ: '坦桑尼亚', UG: '乌干达', RW: '卢旺达',
  NG: '尼日利亚', GH: '加纳', CI: '科特迪瓦', SN: '塞内加尔', CM: '喀麦隆',
  AO: '安哥拉', ZM: '赞比亚', ZW: '津巴布韦', NA: '纳米比亚', BW: '博茨瓦纳',
  MZ: '莫桑比克', MG: '马达加斯加', MU: '毛里求斯', SC: '塞舌尔', ZA: '南非',
  // 北美 / 中南美
  US: '美国', CA: '加拿大', MX: '墨西哥', GT: '危地马拉', HN: '洪都拉斯', SV: '萨尔瓦多',
  NI: '尼加拉瓜', CR: '哥斯达黎加', PA: '巴拿马', CU: '古巴', JM: '牙买加', DO: '多米尼加',
  PR: '波多黎各', BS: '巴哈马', BB: '巴巴多斯', TT: '特立尼达和多巴哥', BZ: '伯利兹',
  BR: '巴西', AR: '阿根廷', CL: '智利', CO: '哥伦比亚', PE: '秘鲁', EC: '厄瓜多尔',
  VE: '委内瑞拉', BO: '玻利维亚', PY: '巴拉圭', UY: '乌拉圭',
  // 大洋洲
  AU: '澳大利亚', NZ: '新西兰', FJ: '斐济', PG: '巴布亚新几内亚', NC: '新喀里多尼亚', PF: '法属波利尼西亚', GU: '关岛',
  // 欧洲属地（IP 清单偶见）
  FO: '法罗群岛', GL: '格陵兰', GI: '直布罗陀', IM: '马恩岛', JE: '泽西', GG: '根西',
};
// 中文/代码国家名 → 两位国家码（用于 #国家 备注覆盖 geo 查询）
const CN_GEO = {};
for (const [code, name] of Object.entries(GEO_CN)) {
  CN_GEO[name] = code;
  CN_GEO[code] = code;
}
const geoCache = new Map();   // host → {cc, org, t}
/** IP → 归属地（仅 IPv4；域名/IPv6 返回空 → 用兜底命名）。失败重试一次并短暂缓存失败结果，避免订阅生成时反复打满限流。 */
const geoOf = async (host) => {
  const h = String(host || '').replace(/^\[|\]$/g, '');
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return { cc: '', org: '' };
  const hit = geoCache.get(h);
  if (hit && Date.now() - hit.t < 24 * 3600 * 1000) return hit;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await fetch(`https://api.ipinfo.io/lite/${encodeURIComponent(h)}?token=2cb674df499388`, { signal: AbortSignal.timeout(5000) });
      if (r.ok) {
        const d = await r.json();
        const v = { cc: String(d.country_code || '').toUpperCase(), org: String((d.asn && d.asn.organization) || d.org || ''), t: Date.now() };
        if (geoCache.size > 500) geoCache.delete(geoCache.keys().next().value);
        geoCache.set(h, v);
        return v;
      }
    } catch { }
    if (attempt === 0) await new Promise((res) => setTimeout(res, 300));
  }
  // 失败也缓存 10 分钟，防止同一次/短时间内重复请求放大限流
  const v = { cc: '', org: '', t: Date.now() - 24 * 3600 * 1000 + 10 * 60 * 1000 };
  geoCache.set(h, v);
  return v;
};

/** Clash 节点地理命名（规则同 v4.1.02 buildClashYaml）：emoji+分类[-地区]-序号-协议。
 *  分类优先级：节点备注里的运营商（#电信/#联通/#移动/#三网，在线优选写入）> ipinfo 机构名 > 国旗+国家名 > ⚡三网兜底；
 *  地区位插在分类后：备注地区码（v2too 的洛杉矶 / 结构化源机场码转中文）> 国家名占位（📡电信-美国-1-WS）> 纯运营商（📡电信-1-WS） */
/** 节点备注 → 国家码：国旗 emoji（🇭🇰）> 中文地区名（GEO_CN 全表）> 两位码整词（#SG/[HK]/US-01）。
 *  命中即视为「备注已明确归属」：直接采用、不查 ipinfo，仅无归属备注的裸 IP 才兜底查询 */
const remarkCc = (text) => {
  const t = String(text || '');
  if (!t) return '';
  const flags = t.match(/\uD83C[\uDDE6-\uDDFF]/g);   // 两个区域指示符组成一面国旗
  if (flags && flags.length >= 2) {
    const cc = String.fromCodePoint(flags[0].codePointAt(0) - 0x1F1A5, flags[1].codePointAt(0) - 0x1F1A5);
    if (GEO_CN[cc]) return cc;
  }
  for (const [code, cn] of Object.entries(GEO_CN).sort((a, b) => b[1].length - a[1].length)) if (t.includes(cn)) return code;   // 长名优先：防「白俄罗斯」先命中「俄罗斯」这类子串误判
  for (const m of t.matchAll(/(?:^|[^A-Za-z])([A-Za-z]{2})(?![A-Za-z])/g)) {
    const cc = m[1].toUpperCase();
    if (GEO_CN[cc]) return cc;
  }
  return '';
};

const buildGeoNames = async (rows) => {
  // 备注已明确归属 → 注入 geo 缓存供 geoOf 零查询命中（仅裸备注 IP 才发起 ipinfo 兜底，查询量骤降同时避开限流）
  for (const r of rows) {
    const cc = remarkCc(r.node && r.node.name);
    if (cc) geoCache.set(String(r.node.host || '').replace(/^\[|\]$/g, ''), { cc, org: '', t: Date.now() });
  }
  // 限制并发查询，避免一次性上百个请求触发 ipinfo 限流导致大面积查不到地理信息
  const geos = [];
  {
    const CONCURRENCY = 8;
    let idx = 0;
    const worker = async () => {
      while (idx < rows.length) {
        const i = idx++;
        geos[i] = await geoOf(rows[i].node.host);
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, rows.length) }, worker));
  }
  const ISP_EMOJI = { 电信: '📡', 联通: '🌐', 移动: '📶', 三网: '⚡' };
  const flagOf = (cc) => /^[A-Z]{2}$/.test(cc)
    ? String.fromCodePoint(...[...cc].map((ch) => 0x1F1A5 + ch.charCodeAt(0)))
    : '';
  const pickIsp = (text) => /电信|telecom/i.test(text) ? '电信'
    : /联通|unicom/i.test(text) ? '联通'
    : /移动|mobile/i.test(text) ? '移动'
    : /三网|three/i.test(text) ? '三网'
    : '';
  // 从节点备注提取国家码，覆盖 ipinfo 查询结果；支持 #SG / #新加坡 / #SG|电信 / [SG] / [新加坡] / [SG | 电信]
  const pickCountryFromName = (text) => {
    text = String(text || '');
    const resolve = (key) => {
      key = String(key || '').trim();
      if (!key) return '';
      if (/^[A-Za-z]{2}$/.test(key)) {
        const upper = key.toUpperCase();
        if (GEO_CN[upper]) return upper;
      }
      if (CN_GEO[key]) return CN_GEO[key];
      const lower = key.toLowerCase();
      for (const [k, v] of Object.entries(CN_GEO)) {
        if (k.toLowerCase() === lower) return v;
      }
      return '';
    };
    // # 标签：按空格或 | 分隔
    const hashTags = text.match(/#[^#\s|]+/g);
    if (hashTags) for (const tag of hashTags) { const cc = resolve(tag.slice(1)); if (cc) return cc; }
    // [ ] 标签：常见于 proxy brand 格式
    const brackets = text.match(/\[\s*[A-Za-z]{2}\s*\]|\[\s*[^\[\]\s|]+\s*\]/g);
    if (brackets) for (const tag of brackets) { const cc = resolve(tag.replace(/^\[\s*|\s*\]$/g, '')); if (cc) return cc; }
    return '';
  };
  // 备注地区提取（v2too：⚡电信-洛杉矶-30 → 洛杉矶；三网结构化源已压成「移动-香港」）。
  // 只认运营商词之后的段：防「微测优选 | 移动 | HKG」的首段源名被误当地区
  const pickRegion = (text) => {
    const segs = String(text || '').split(/[-_|#\s]+/).map((w) => w.replace(/[⚡📡🌐📶]/g, '')).filter(Boolean);
    const ispIdx = segs.findIndex((w) => /^(?:电信|联通|移动|三网)$/.test(w));
    if (ispIdx === -1) return '';
    for (const w of segs.slice(ispIdx + 1)) {
      if (/^[一-龥]{2,8}$/.test(w)) return w;
    }
    return '';
  };
  const seqByGroup = new Map(), used = new Map();
  let seqUnknown = 0;
  return rows.map((r, i) => {
    const g = geos[i];
    const org = g.org || '';
    const protoTag = r.proto === 'XHTTP' ? 'XHTTP' : 'WS';
    // 运营商判定优先取节点备注（在线优选写入的 #电信 等），其次 ipinfo 机构名
    const isp = pickIsp(String(r.node.name || '')) || pickIsp(org);
    // 国家码：备注 #SG/#新加坡 优先覆盖 ipinfo，保证面板显示与订阅命名一致
    const cc = pickCountryFromName(r.node.name) || g.cc || '';
    const ccName = GEO_CN[cc] || '';
    // 地区位：备注地区码优先（移动-香港）→ 国家名占位（电信-美国）→ 都无则纯运营商（电信-1）
    const region = pickRegion(r.node.name) || ccName;
    let base;
    if (isp) {
      const n = (seqByGroup.get(isp) || 0) + 1;
      seqByGroup.set(isp, n);
      base = `${ISP_EMOJI[isp]}${isp}${region ? '-' + region : ''}-${n}-${protoTag}`;
    } else if (ccName) {
      const n = (seqByGroup.get(cc) || 0) + 1;
      seqByGroup.set(cc, n);
      base = `${flagOf(cc)}${ccName}-${n}-${protoTag}`;
    } else {
      seqUnknown += 1;
      base = `${ISP_EMOJI['三网']}三网-${seqUnknown}-${protoTag}`;
    }
    const total = (used.get(base) || 0) + 1;
    used.set(base, total);
    return total > 1 ? `${base} | [ ${String(total).padStart(2, '0')} ]` : base;
  });
};

// ---------- 自动选择组（url-test：当前节点超时/失联时自动切换到健康节点，多订阅格式共用） ----------

const UrlTestTarget = 'http://www.gstatic.com/generate_204';   // 健康检查地址（经被测节点自身发起，不经过分流规则）

/** 两位国家码整词匹配（防 US 误命中 RUSSIA、IN 误命中 SINGAPORE 这类子串） */
const ccTokenRe = (cc) => new RegExp(`(?:^|[^A-Za-z])${cc}(?![A-Za-z])`, 'i');

/** 全部节点总组 + 地区自动组：动态遍历 GEO_CN 全表（159 国/地区，全主权国家+常见地区，按大洲分组）。
 *  匹配三通道：中文名（mihomo geo 命名必含）> 国旗 emoji > 国家码整词（sing-box/Loon 源备注 #SG / US-01），长名优先防子串误判；
 *  每节点只归入命中的那一个国家组（互斥，防交叉污染）；另设运营商组（三网/电信/联通/移动 关键词归并，允许与国家组交叉）；≥2 节点成组 */
const autoGroupList = (names) => {
  const flagOfCc = (cc) => /^[A-Z]{2}$/.test(cc) ? String.fromCodePoint(...[...cc].map((ch) => 0x1F1A5 + ch.charCodeAt(0))) : '';
  const byLen = Object.entries(GEO_CN).sort((a, b) => b[1].length - a[1].length);   // 中文名长度降序
  const buckets = new Map();
  for (const n of names) {
    for (const [cc, cn] of byLen) {
      const flag = flagOfCc(cc);
      if (n.includes(cn) || (flag && n.includes(flag)) || ccTokenRe(cc).test(n)) {
        if (!buckets.has(cn)) buckets.set(cn, []);
        buckets.get(cn).push(n);
        break;   // 一节点一国：命中最长者即止
      }
    }
  }
  const list = [{ name: '♻️ 自动选择', proxies: [...names] }];
  const groups = byLen.filter(([, cn]) => (buckets.get(cn) || []).length >= 2).map(([, cn]) => ({ name: `♻️ 自动-${cn}`, proxies: buckets.get(cn) }));
  const isp = names.filter((n) => /三网|电信|联通|移动/.test(n));
  if (isp.length >= 2) groups.push({ name: '♻️ 自动-三网', proxies: isp });
  return list.concat(groups);
};

const buildYamlSubConfig = async (ips, nodeHosts, opts = {}) => {
  const mrsUrl = (file) => `${opts.geoBase}/mrs/${file}`;
  const rows = buildNodeRows(ips, nodeHosts, { ...opts, dedupe: true });   // 逐节点按域名解析 WS/XHTTP（账号/类型覆盖生效）
  const names = await buildGeoNames(rows);   // 地理命名：emoji+运营商/国家[-地区]-序号-协议（同 v4.1.02）
  const alpnList = parseAlpn(opts.alpn);
  const dohRaw = String(opts.doh || '').trim();
  const dohList = (dohRaw.includes('://') ? [dohRaw] : DefaultDoh).map(yamlVal);   // 面板 Doh 自定义 URL 覆盖主解析，auto 保持国内可达双 DoH
  const proxies = rows.map(({ host, path, server, port, uuid, proto, ed }, i) => {
    const isXhttp = proto === 'XHTTP';
    const transport = isXhttp
      ? `    network: xhttp
    xhttp-opts:
      path: ${yamlVal(path)}
      host: ${yamlVal(host)}
      mode: stream-one`
      : ed
        ? `    network: ws
    ws-opts:
      path: ${yamlVal(path)}
      headers:
        Host: ${yamlVal(host)}
      max-early-data: ${EdCapacity}
      early-data-header-name: Sec-WebSocket-Protocol`
        : `    network: ws
    ws-opts:
      path: ${yamlVal(path)}
      headers:
        Host: ${yamlVal(host)}`;   // 不带 early-data：与节点路径保持一致，兼容 dalian/ji 类极简 Snippets 子后端
    const alpn = alpnList.map(yamlVal).join(', ');
    const alpnAttr = alpn ? `\n    alpn: [${alpn}]` : '';
    return `  - name: ${yamlVal(names[i])}
    type: ${SenflareLink}
    server: ${yamlVal(server)}
    port: ${port}
    uuid: ${yamlVal(uuid)}
    udp: true
${transport}
    tls: true
    servername: ${yamlVal(host)}${alpnAttr}
    client-fingerprint: ${yamlVal(opts.fp || NodeDefaults.Fp)}${opts.ech ? `
    ech-opts:
      enable: true
      query-server-name: ${yamlVal(opts.echSni || NodeDefaults.EchDomain)}` : ''}`;
  }).join('\n');

  const group = (name, list) => `  - name: ${yamlVal(name)}\n    type: select\n    proxies: [${list.map(yamlVal).join(', ')}]`;
  const autos = autoGroupList(names);   // 自动组名插到「🚀 节点选择」首位：select 默认选第一项 → 默认自动切换，仍可手动点选节点锁定
  const urlTest = (name, list, hidden) => `  - name: ${yamlVal(name)}\n    type: url-test\n    url: ${yamlVal(UrlTestTarget)}\n    interval: 300\n    tolerance: 50\n    timeout: 3000\n    lazy: true\n    max-failed-times: 3${hidden ? '\n    hidden: true' : ''}\n    proxies: [${list.map(yamlVal).join(', ')}]`;
  const groups = [
    ...autos.map((a, i) => urlTest(a.name, a.proxies, i > 0)),   // url-test 组置顶：♻️ 自动选择 即客户端第一列标签；地区组 hidden 不显示
    group('🚀 节点选择', [...autos.map((a) => a.name), ...names, '🎯 全球直连']),
    group('🎯 全球直连', ['DIRECT']),
    group('🛑 广告拦截', ['REJECT', 'DIRECT']),
    group('🐟 漏网之鱼', ['🚀 节点选择', '🎯 全球直连']),
  ].join('\n');

  const providers = RouteProviders.map(([tag, file]) =>
    `  ${yamlVal(tag)}: { type: http, behavior: ${tag.startsWith('geoip') ? 'ipcidr' : 'domain'}, format: mrs, interval: 86400, proxy: DIRECT, url: ${yamlVal(mrsUrl(file))} }`).join('\n');

  const ruleLines = [
    ...YamlSegRules('private'),
    ...UserDirectDomains.map((d) => `  - DOMAIN-SUFFIX,${d},DIRECT`),   // 用户白名单压过广告拦截与 QUIC 阻断，被拦后路由层救不回
    ...UserProxyDomains.map((d) => `  - DOMAIN-SUFFIX,${d},🚀 节点选择`),
    ...YamlSegRules('ads'),
    '  - AND,((NETWORK,UDP),(DST-PORT,443),(NOT,((OR,((RULE-SET,geosite-cn),(RULE-SET,geoip-cn)))))),REJECT',   // 仅拦国外 QUIC，国内（B站等）放行
    ...YamlSegRules('proxy'),
    ...YamlSegRules('direct'),
    '  - MATCH,🐟 漏网之鱼',
  ].join('\n');

  return YamlBase(dohList) + `
# ===== 节点列表 =====
proxies:
${proxies}

# ===== 节点策略 =====
proxy-groups:
${groups}

# ===== 分流规则 =====
rules:
${ruleLines}

# ===== 规则集合 =====
rule-providers:
${providers}

`;
};

// ---------- S'+'i'+'n'+'g'+'-'+'b'+'o'+'x  ----------

const buildJsonSubConfig = (ips, nodeHosts, opts = {}) => {
  const fingerprint = opts.fp || NodeDefaults.Fp;
  const echSni = String(opts.echSni || NodeDefaults.EchDomain).trim() || NodeDefaults.EchDomain;
  const rows = buildWsRows(ips, nodeHosts, opts);
  for (const r of rows) if (r.path === '/') r.path = '';
  const tags = rows.map((r) => r.displayName);
  const G = { select: '🚀 节点选择', direct: '🎯 全球直连', final: '🐟 漏网之鱼' };
  const alpnList = parseAlpn(opts.alpn);
  /** DoH URL → sing-box DNS 服务器字段（https/h3/tls/quic，非法回落 null） */
  const parseDohUrl = (raw) => {
    try {
      const u = new URL(String(raw || '').trim());
      const type = { 'https:': 'https', 'h3:': 'h3', 'tls:': 'tls', 'quic:': 'quic' }[u.protocol.toLowerCase()];
      return type ? { type, server: u.hostname, ...(u.port ? { server_port: Number(u.port) } : {}), ...((type === 'https' || type === 'h3') && u.pathname && u.pathname !== '/dns-query' ? { path: u.pathname } : {}) } : null;
    } catch { return null; }
  };
  let echDnsRule = null, echDnsServer = null;
  if (opts.ech) {
    const fields = parseDohUrl(opts.echDns);
    if (fields) {
      echDnsServer = { tag: 'dns_ech', domain_resolver: 'dns_resolver', ...fields };
      echDnsRule = { domain: [echSni], server: 'dns_ech' };
    }
    if (!echDnsRule) echDnsRule = { domain: [echSni], server: 'dns_direct' };
  }
  const ruleSet = (tag) => ({
    tag, type: 'remote', format: 'binary',
    url: `${opts.geoBase}/${tag}.srs`,
    download_detour: G.direct,
  });

  const nodeOutbound = ({ host, path, displayName, server, port, uuid }) => {
    return {
      type: SenflareLink,
      tag: displayName,
      server,
      server_port: port,
      uuid,
      transport: { type: 'ws', path, headers: { Host: host }, max_early_data: EdCapacity, early_data_header_name: 'Sec-WebSocket-Protocol' },
      tls: {
        enabled: true,
        server_name: host,
        ...(alpnList.length ? { alpn: alpnList } : {}),
        utls: { enabled: true, fingerprint },
        ech: opts.ech ? { enabled: true, ...(opts.echQsn ? { query_server_name: echSni } : {}) } : undefined,   // query_server_name 仅内核 ≥1.13 写入（1.12 对未知字段整份拒载），查询域与 mihomo 对齐
      },
    };
  };

  const dns = {
    servers: [
      { tag: 'dns_proxy', type: 'tls', server: '8.8.8.8', detour: G.select },
      { tag: 'dns_direct', domain_resolver: 'dns_resolver', ...(parseDohUrl(opts.doh) || { type: 'https', server: 'dns.alidns.com' }) }, 
      { tag: 'dns_fakeip', type: 'fakeip', inet4_range: '198.18.0.0/15', inet6_range: 'fc00::/18' },
      { tag: 'dns_resolver', type: 'udp', server: '223.6.6.6' },
      ...(echDnsServer ? [echDnsServer] : []),
    ],
    rules: [
      ...(echDnsRule ? [echDnsRule] : []),
      { domain_suffix: [...UserDirectDomains, ...UserProxyDomains], server: 'dns_direct', action: 'route' },
      { rule_set: ['geosite-category-ads-all'], action: 'predefined', rcode: 'NOERROR' },
      { rule_set: ['ads'], action: 'predefined', rcode: 'NOERROR' },
      { query_type: ['HTTPS'], server: 'dns_direct' },
      { rule_set: ['geosite-microsoft', 'geosite-private'], server: 'dns_direct' },
      { query_type: ['A', 'AAAA'], server: 'dns_fakeip' },
    ],
    final: 'dns_proxy',
  };

  const inbounds = [
    { type: 'mixed', tag: 'mixed-in', listen: '127.0.0.1', listen_port: 2080 },
    { type: 'tun', tag: 'tun-in', address: ['172.19.0.1/30', 'fdfe:dcba:9876::1/126'], auto_route: true, strict_route: false },
  ];

  const autos = autoGroupList(tags);   // 自动组插到「🚀 节点选择」首位：selector 默认选第一项 → 默认自动切换，仍可手动点选锁定
  const outbounds = [
    { type: 'direct', tag: 'DIRECT' },
    ...autos.map((a) => ({ type: 'urltest', tag: a.name, outbounds: a.proxies, url: UrlTestTarget, interval: '5m', tolerance: 50 })),   // urltest 置前：♻️ 自动选择 即客户端首个策略组
    ...rows.map(nodeOutbound),
    { type: 'selector', tag: G.select, outbounds: [...autos.map((a) => a.name), ...tags, G.direct] },
    { type: 'selector', tag: G.direct, outbounds: ['DIRECT'] },
    { type: 'selector', tag: G.final, outbounds: [G.select, G.direct] },
    { type: 'selector', tag: 'GLOBAL', outbounds: [G.select, ...tags, 'DIRECT', G.direct] },
  ];

  const route = {
    rules: [
      { action: 'sniff', sniffer: ['tls', 'http', 'quic'] }, 
      { protocol: 'dns', action: 'hijack-dns' },
      { clash_mode: 'Direct', outbound: 'DIRECT' },
      { clash_mode: 'Global', outbound: 'GLOBAL' },
      { ip_is_private: true, outbound: 'DIRECT' },
      { rule_set: ['geosite-private'], outbound: 'DIRECT' },
      { domain_suffix: [...UserDirectDomains], outbound: 'DIRECT' },   // 用户白名单压过广告拦截与 QUIC 阻断，被拦后路由层救不回
      { domain_suffix: [...UserProxyDomains], outbound: G.select },
      { rule_set: ['ads'], action: 'reject' },
      { rule_set: ['geosite-category-ads-all'], action: 'reject' },
      { network: 'udp', port: 443, rule_set: ['geosite-cn', 'geoip-cn'], outbound: G.direct },   // 国内 QUIC 放行
      { network: 'udp', port: 443, action: 'reject' },
      { action: 'resolve', server: 'dns_direct' },
      { rule_set: ['geosite-github'], outbound: G.select },
      { rule_set: ['geosite-google'], outbound: G.select },
      { rule_set: ['geosite-cn', 'geoip-cn'], outbound: G.direct },
      { rule_set: ['geosite-apple-cn'], outbound: 'DIRECT' }, 
      { rule_set: ['geosite-microsoft'], outbound: 'DIRECT' },
    ],
    rule_set: ['ads', 'geosite-private', 'geosite-category-ads-all', 'geosite-github', 'geosite-google', 'geosite-cn', 'geoip-cn', 'geosite-apple-cn', 'geosite-microsoft'].map(ruleSet),
    final: G.final,
    auto_detect_interface: true,
    default_domain_resolver: 'dns_resolver',
  };

  return JSON.stringify({
    log: { timestamp: true },
    dns,
    inbounds,
    outbounds,
    route,
    experimental: {
      cache_file: { enabled: true, store_fakeip: true },
      clash_api: { external_controller: '127.0.0.1:9090' },
    },
  }, null, 2);
};

// ---------- L'+'o'+'o'+'n  ----------

/** Loon 分流规则 */
const RouteRules = [
  // 内网直连
  'IP-CIDR,10.0.0.0/8,DIRECT,no-resolve',
  'IP-CIDR,172.16.0.0/12,DIRECT,no-resolve',
  'IP-CIDR,192.168.0.0/16,DIRECT,no-resolve',
  'IP-CIDR,127.0.0.0/8,DIRECT,no-resolve',
  'IP-CIDR,169.254.0.0/16,DIRECT,no-resolve',
  'IP-CIDR,::1/128,DIRECT,no-resolve',
  'IP-CIDR,fe80::/10,DIRECT,no-resolve',
  'IP-CIDR,fc00::/7,DIRECT,no-resolve',
  'DOMAIN,localhost,DIRECT',
  'DOMAIN-SUFFIX,local,DIRECT',
  'DOMAIN-SUFFIX,localdomain,DIRECT',
  'DOMAIN-SUFFIX,home.arpa,DIRECT',
  'DOMAIN-SUFFIX,internal,DIRECT',
  ...UserDirectDomains.map((d) => `DOMAIN-SUFFIX,${d},DIRECT`),
  ...UserProxyDomains.map((d) => `DOMAIN-SUFFIX,${d},🚀 节点选择`),
  'AND,((DEST-PORT,443),(PROTOCOL,UDP),(NOT,((GEOIP,cn)))),REJECT',   // 仅拦国外 QUIC，国内放行（域名解析后命中 GEOIP，与另两端同语义）
  'GEOIP,cn,DIRECT',
];

const buildTextSubConfig = (ips, nodeHosts, opts = {}) => {
  const rows = buildWsRows(ips, nodeHosts, opts);
  const lines = rows.map(({ displayName, server, port, host, path, uuid }) =>
    `${displayName} = ${SenflareLink.toUpperCase()},${server},${port},"${uuid}",transport=ws,path=${path},host=${host},udp-relay=true,over-tls=true,tls-name=${host},skip-cert-verify=false`);
  const tags = rows.map((r) => r.displayName);
  const autos = autoGroupList(tags);   // 自动组插到「🚀 节点选择」首位：select 默认选第一项 → 默认自动切换，仍可手动点选锁定
  return [
    '[General]',
    'dns-server = 223.6.6.6, 119.29.29.29',
    'skip-proxy = 127.0.0.1, 192.168.0.0/16, 10.0.0.0/8, 172.16.0.0/12, 100.64.0.0/10, localhost, *.local',
    '',
    '[Proxy]',
    ...lines,
    '',
    '[Proxy Group]',
    ...autos.map((a) => `${a.name} = url-test, ${a.proxies.join(', ')}, url=${UrlTestTarget}, interval=300, tolerance=50`),   // 自动组置顶
    `🚀 节点选择 = select, ${[...autos.map((a) => a.name), ...tags].join(', ')}, 🎯 全球直连`,
    '🎯 全球直连 = select, DIRECT',
    '🐟 漏网之鱼 = select, 🚀 节点选择, 🎯 全球直连',
    '',
    '[Rule]',
    ...RouteRules,
    'FINAL,🐟 漏网之鱼',
  ].join('\n');
};

// ---------- Q'+'u'+'a'+'n'+'X ----------

const buildServerLocalSubConfig = (ips, nodeHosts, opts = {}) => {
  const rows = buildWsRows(ips, nodeHosts, opts);
  const lines = rows.map(({ host, path, displayName, server, port, uuid }) => {
    const addr = server.includes(':') ? `[${server}]` : server;
    return `${SenflareLink}=${addr}:${port}, method=none, password=${uuid}, obfs=wss, obfs-host=${host}, obfs-uri=${path}, udp-relay=true, tls-verification=true, tag=${displayName}`;
  });
  return ['[server_local]', ...lines].join('\n');
};

// ---------- 订阅入口 ----------

/** 订阅头用量缓存 60s（失败同样缓存：上游故障时防每次下发都等 8s 超时），每次订阅下发都查会白跑 D1 */
let poolUsageCache = null;

/** 订阅头真实用量：聚合全部活跃账号当日请求，显示为同数值 GB，失败回退时钟显示 */
const getPoolUsage = async () => {
  if (poolUsageCache && Date.now() - poolUsageCache.time < 60 * 1000) return poolUsageCache.data;
  const db = runtimeEnv?.Senflare;
  if (!db) return null;
  const accounts = (await db.prepare('SELECT id, email, accountId, authType, apiToken, globalApiKey, quota FROM cfAccounts WHERE status != \'disabled\'').all().catch(() => ({ results: [] }))).results || [];
  if (!accounts.length) { poolUsageCache = { time: Date.now(), data: null }; return null; }
  const usages = await Promise.allSettled(accounts.map((acc) => queryCfUsage(acc)));
  const ok = usages.filter((r) => r.status === 'fulfilled' && r.value?.success);
  if (!ok.length) { poolUsageCache = { time: Date.now(), data: null }; return null; }
  const MB = 2 ** 30 / 1000;   // 千分之一 GiB
  const out = {
    pages: Math.round(ok.reduce((t, r) => t + (r.value.pages || 0), 0) * MB),
    workers: Math.round(ok.reduce((t, r) => t + (r.value.workers || 0), 0) * MB),
    quota: Math.round(accounts.reduce((t, a) => t + (Number(a.quota) > 0 ? Number(a.quota) : 100000), 0) * MB),
  };
  poolUsageCache = { time: Date.now(), data: out };
  return out;
};

/** 处理订阅请求：凭证校验 → 按 UA/参数分发格式本地生成 */
const handleSubscription = async (request, conf, ctx) => {
  const url = new URL(request.url);
  const ua = request.headers.get('User-Agent') || '';
  const q = url.searchParams;
  const subPath = conf.SubPath;

  // 凭证：路径段 /{subPath}/<UUID 或 SubKey>
  const reqCred = url.pathname.startsWith(subPath + '/') ? url.pathname.slice(subPath.length + 1).split('/')[0] : '';
  const subKey = String(conf.SubKey ?? '').trim();
  if (!reqCred || (!safeEqual(reqCred.toLowerCase(), getUuid()) && !(subKey && safeEqual(reqCred, subKey)))) {   // UUID 按大小写不敏感比较，SubKey 保持原样
    logToDb(ctx, request, '订阅拒绝', reqCred ? `凭证无效: ${reqCred.slice(0, 8)}…` : '凭证缺失');
    return new Response('当前订阅无效，请检查您的 UUID ！', {
      status: 403,
      headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
    });
  }

  const inbound = String(conf.Inbound ?? 'preferred').trim().toLowerCase();
  const outbound = String(conf.Outbound ?? 'auto').trim().toLowerCase();
  const proxyMode = String(conf.ProxyIPMode || '').toUpperCase();
  // 取源与面板节点列表共用
  const { speedSource, proxySource } = pickIpSources(conf);
  const ipsPromise = resolveIpList(inbound === 'proxy' ? proxySource : speedSource);
  const poolUsagePromise = getPoolUsage().catch(() => null);   // 与 IP 源拉取并行启动，冷请求省一次串行等待

  // 链式开启且上游有效 → 按上游生成节点，否则走原管线
  const upstreamList = conf.ChainEnabled === true ? parseUpstreamEntries(conf.Upstream) : [];
  const pinExit = upstreamList.length > 0 || (outbound === 'global' && (proxyMode === 'CUSTOM' || proxyMode === 'LOCAL'));   // 链式：按上游生成节点；全局未开链式 + 列表型出口：按出口逐个生成（路径 /proxyip= 锁定）
  const exitPromise = upstreamList.length || !pinExit ? null
    : inbound === 'proxy' ? ipsPromise
      : resolveIpList(proxySource);
  const nodeHosts = await getCfAllHosts();
  if (!nodeHosts.length) {
    return new Response('未配置订阅域名！请先在面板「后端配置」页添加 Cloudflare 账号并填写数据同步域名（或订阅生成域名）！', {
      status: 503,
      headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
    });
  }
  const nodeHost = nodeHosts[0];   // ECH 兜底域

  const echParam = q.get('ech');
  const echOn = echParam === '1' ? true : echParam === '0' ? false : conf.ECH !== false;
  let echDomainCfg = String(conf.EchDomain ?? '').trim();
  if (!echDomainCfg || echDomainCfg.toUpperCase() === '__AUTO__') echDomainCfg = nodeHost;
  const subName = String(conf.SubName ?? NodeDefaults.SubName);
  const sbVer = /(?:^sf[a-z]|sing-?box)[/ ]v?(\d+)\.(\d+)/i.exec(ua);   // sing-box 内核版本（官方 SFA/SFI/SFM/SFW 与 CLI 带，第三方壳多不带）
  const opts = {
    path: q.get('path') || '/',
    ech: echOn,
    echQsn: sbVer ? +sbVer[1] > 1 || (+sbVer[1] === 1 && +sbVer[2] >= 13) : false,   // sing-box ≥1.13 才写 query_server_name（1.12 对未知字段整份拒载），版本未知按不写
    echConfig: `${echDomainCfg}${conf.EchDns ? `+${conf.EchDns}` : ''}`,   // EchDns 为空时省略 + 后缀，避免客户端解析到空 DNS 段
    echSni: echDomainCfg,
    echDns: conf.EchDns,
    doh: conf.Doh,   // 面板 Doh：自定义 URL 覆盖订阅客户端解析
    fp: conf.Fp ?? NodeDefaults.Fp,
    alpn: String(conf.Alpn ?? NodeDefaults.Alpn).trim(),
    protocol: String(conf.Protocol ?? 'WS').trim().toUpperCase(),
    protoWorker: ['WS', 'XHTTP'].includes(String(conf.ProtocolWorker ?? '').trim().toUpperCase()) ? String(conf.ProtocolWorker).trim().toUpperCase() : '',      // Worker 子后端覆盖（''=跟随全局）
    protoSnippet: ['WS', 'XHTTP'].includes(String(conf.ProtocolSnippet ?? '').trim().toUpperCase()) ? String(conf.ProtocolSnippet).trim().toUpperCase() : '',    // Snippets 子后端覆盖（''=跟随全局）
    geoBase: url.origin + '/geodata',   // 本域名规则集下载地址
  };

  const ips = await ipsPromise;
  // 链式条目附可读路径段 /socks5= / /http=，子后端解析后单连接锁定
  opts.exitList = exitPromise ? await exitPromise : [];
  if (upstreamList.length) {
    opts.exitList = upstreamList.map((e) => ({
      host: e.host, port: e.port, name: e.name || `${e.host}:${e.port}`, upstream: true,
      upstreamPath: `${e.type}=${e.username ? `${e.username}:${e.password}@` : ''}${e.host}:${e.port}`,
    }));
  }
  if (!ips.length) return new Response(inbound === 'proxy' ? '反代 IP 未配置！' : '优选 IP 未配置！', { status: 500 });

  // 节点链接懒构建：仅 b64 下发/回落时才生成，转换格式只需数量
  const nodeCount = opts.exitList.length || ips.length;
  let linksBase64 = null;
  const linksB64 = () => linksBase64 ??= b64utf8(buildLinks(ips, nodeHosts, opts).join('\n'));
  const credKind = safeEqual(reqCred.toLowerCase(), getUuid()) ? 'UUID' : 'SubKey';
  const profileTitle = /^[\x20-\x7e]*$/.test(subName) ? subName : 'base64:' + b64utf8(subName);

  // 用量栏：真实请求配额优先（1 请求 = 1 MB），全败回退假时钟
  const poolUsage = await poolUsagePromise;
  const bjNow = new Date(Date.now() + 8 * 3600 * 1000);
  const fakeUsed = Math.round((bjNow.getUTCHours() + bjNow.getUTCMinutes() / 60) * 1024 ** 4);

  const headers = {
    'Content-Type': 'text/plain; charset=utf-8',
    'Profile-Title': profileTitle,
    'Profile-Update-Interval': '24',
    'Subscription-Userinfo': `upload=${poolUsage ? poolUsage.pages : 0}; download=${poolUsage ? poolUsage.workers : fakeUsed}; total=${poolUsage ? poolUsage.quota : 24 * 1024 ** 4}; expire=4102358400`,   // 2099-12-31 UTC
    'Cache-Control': 'no-store',
  };

  if (!ua.toLowerCase().includes('mozilla')) {
    headers['Content-Disposition'] = `attachment; filename*=utf-8''${encodeURIComponent(subName)}`;
  }

  // ?target= 只认白名单，表外回落 b64：零出站
  const fmt = String(detectSubFormat(ua, url)).toLowerCase();
  const safeFormat = SubTargets.has(fmt) ? fmt : SenflareC;
  if (safeFormat === SenflareC) {
    logToDb(ctx, request, '订阅下发', `${credKind} · b64 · ${nodeCount} 个节点`);
    return new Response(linksB64(), { headers });
  }

  // 全格式本地生成：m'+'i'+'h'+'o'+'m'+'o 节点跟随面板协议（WS/XHTTP），其余格式统一 WS
  const builders = { [SenflareB]: buildJsonSubConfig, [SenflareA]: buildYamlSubConfig, [SenflareK]: buildTextSubConfig, [SenflareI]: buildServerLocalSubConfig };
  const content = await builders[safeFormat](ips, nodeHosts, opts);
  const isEchFormat = safeFormat === SenflareB || safeFormat === SenflareA;   // 仅这两种格式实现 ECH
  logToDb(ctx, request, '订阅下发', `${credKind} · ${safeFormat} · ${nodeCount} 个节点${isEchFormat && opts.ech ? ' · ECH' : ''}`);
  return new Response(content, { headers: { ...headers, 'Content-Type': subContentType(safeFormat) } });
};

// ==================== 11. 首页伪装 ====================

/** 首页伪装：FakePage 开启时仅接管 / */
const FakePassHeaders = ['user-agent', 'accept', 'accept-language', 'content-type'];
const FakeRewriteMax = 2 * 1024 * 1024;   // 文本改写上限，超限流式透传

const handleFakePage = async (request, ctx) => {
  const url = new URL(request.url);
  try {
    const fakeURL = new URL((await loadNodeConfig()).FakeUrl || 'https://www.xinhuanet.com/');
    const headers = new Headers();
    for (const h of FakePassHeaders) { const v = request.headers.get(h); if (v) headers.set(h, v); }
    headers.set('Referer', fakeURL.origin);
    headers.set('Origin', fakeURL.origin);
    headers.set('Accept-Encoding', 'identity');

    // 首页/兜底取 FakeUrl 自身路径（支持子页面/对象存储目标）；其余路径按访客路径映射到源站根下——
    // 页面资源经域名重写后落回本站路径，由主路由回源代理，任意引用形态零感知（v4.1.02 线上验证架构）
    const fakePath = url.pathname === '/' || url.pathname === '/index.html' ? fakeURL.pathname : url.pathname;
    let response = await fetch(fakeURL.origin + fakePath + url.search, { method: request.method, headers, body: request.body, cf: request.cf, signal: AbortSignal.timeout(8000) });

    // 404 回落：上游不存在该路径时改反代伪装页自身（200），不裸露源站默认 404 页
    if (response.status === 404) {
      response = await fetch(fakeURL.origin + fakeURL.pathname, { method: 'GET', headers, cf: request.cf, signal: AbortSignal.timeout(8000) });
    }

    const contentType = response.headers.get('content-type') || '';
    // HTML 不缓存（域名重写怕脏缓存）；静态资源（css/js/音频/图片）允许浏览器与边缘缓存 1 天，否则每次打开全套反代极慢
    const cacheControl = /text\/html/i.test(contentType) ? 'no-store' : 'public, max-age=86400';
    if (/text|javascript|json|xml/.test(contentType)) {
      const lenHeader = response.headers.get('content-length'), len = lenHeader == null ? NaN : Number(lenHeader);
      const outHeaders = new Headers(response.headers);
      outHeaders.set('Cache-Control', cacheControl);
      if (!Number.isFinite(len) || len > FakeRewriteMax) return new Response(response.body, { status: response.status, headers: outHeaders });
      outHeaders.delete('content-encoding');
      outHeaders.delete('content-length');
      const content = (await response.text()).replaceAll(fakeURL.host, url.host);   // 域名重写：页面内引用指向本站，继续被本函数代理
      return new Response(content, { status: response.status, headers: outHeaders });
    }
    const binHeaders = new Headers(response.headers);
    binHeaders.set('Cache-Control', cacheControl);
    return new Response(response.body, { status: response.status, headers: binHeaders });
  } catch {
    return new Response((await loadNodeConfig()).SubName || NodeDefaults.SubName, { status: 200 });
  }
};

// ==================== 12. 管理端 API ====================

/** 管理面板 API（HMAC 令牌鉴权，配置仅白名单键可写） */

// ---------- 子后端配置推送（跨账号部署用，同账号共享 D1 时无需此通道） ----------
/** 推送白名单 */
const NodeSyncKeys = ['UUID', 'ProxyIP', 'LocalProxyIP', 'ProxyIPMax', 'ChainEnabled', 'Upstream', 'Outbound', 'Doh'];   // ProxyIPMode 不在白名单：推送时单独按 nodeExitMode 归一覆盖

/** 同步域名排序：自定义域权重高于生产域（workers.dev / pages.dev） */
const sortSyncDomains = (list) => {
  const norm = (h) => String(h).replace(/^https?:\/\//i, '').replace(/\/+$/, '').trim().toLowerCase();   // 登记一律为裸主机名
  const out = [];
  for (const h of list.map(norm)) if (h && !out.includes(h)) out.push(h);
  const isProd = (h) => /\.workers\.dev$|\.pages\.dev$/i.test(h);
  return out.sort((a, b) => (isProd(a) ? 1 : 0) - (isProd(b) ? 1 : 0));
};

/** 推送节点/反代配置到各账号的同步域名
 *  返回结构（per-account 可见）：
 *   - ok/fail/versions：Worker 推送结果（域名为键）
 *   - pullBased：Snippets 拉取模式明细 [{id, name, domain}]（带 account 归属，同域名去重保留首个 account，防前端误判只显示一个）
 *   - snippets：所有 Snippets 账号的 per-account 明细 [{id, name, status, domain}]，供前端精确归属"哪个 Snippet 成功" */
const pushConfigToNodes = async (onlyId) => {
  const db = runtimeEnv?.Senflare;
  if (!db) return null;
  const rows = await db.prepare('SELECT id, name, domains, syncDomains, status, deployType FROM cfAccounts').all().catch(() => ({ results: [] }));
  const targets = [];
  const pullBased = [];   // Snippets 拉取模式明细：[{id, name, domain}]（带 account 归属）
  const snippets = [];    // 所有 Snippets 账号明细：[{id, name, status, domain}]
  const pullSeen = new Set();   // 同域名去重（保留首个 account，避免前端按域名去重后丢失后续 account）
  for (const r of rows.results || []) {
    if (onlyId && String(r.id) !== String(onlyId)) continue;   // 单账号模式：只推指定账号
    const isSnippet = String(r.deployType || 'worker') === 'snippet';
    if (isSnippet) {
      // Snippet：domains 为节点域名（订阅生成用），空时回退读 syncDomains 兼容旧数据（防 domains 空导致零贡献被掩盖）
      let ds = jsonOr(r.domains, []);
      if (!ds.length) ds = jsonOr(r.syncDomains, []);
      const domainsForSnip = ds.filter((d) => typeof d === 'string' && d.trim());
      snippets.push({ id: String(r.id), name: String(r.name || ''), status: String(r.status || 'normal'), domain: domainsForSnip[0] ? (domainsForSnip[0].trim().replace(/^https?:\/\//i, '').replace(/\/+$/, '')) : '' });
      if (String(r.status || '') === 'disabled') continue;   // 禁用 Snippet 仅登记 snippets 明细，不计入 pullBased
      for (const d of domainsForSnip) {
        const base = d.trim().replace(/\/+$/, '');
        const url = /^https?:\/\//i.test(base) ? base : `https://${base}`;
        const hostKey = url.replace(/^https?:\/\//i, '').toLowerCase();
        if (pullSeen.has(hostKey)) continue;   // 同域名去重（首个 account 优先）
        pullSeen.add(hostKey);
        pullBased.push({ id: String(r.id), name: String(r.name || ''), domain: url });
      }
      continue;
    }
    if (String(r.status || '') === 'disabled') continue;   // 禁用账号不接收配置推送
    let ds = jsonOr(r.syncDomains, []);   // Worker 推送目标只看同步域名
    for (const d of ds) {
      if (typeof d !== 'string' || !d.trim()) continue;
      const base = d.trim().replace(/\/+$/, '');
      targets.push(/^https?:\/\//i.test(base) ? base : `https://${base}`);
    }
  }
  if (!targets.length && !pullBased.length && !snippets.length) return null;
  const conf = await loadNodeConfig();
  const payload = {};
  for (const k of NodeSyncKeys) if (k in conf) payload[k] = conf[k];
  if (!isValidUuid(String(payload.UUID ?? ''))) delete payload.UUID;   // UUID 留空 = 各子后端用各自 UUID：不推空值覆盖子端自设 UUID
  payload.ProxyIPMode = nodeExitMode(conf);
  if (!targets.length) return { total: 0, ok: [], fail: [], pullBased, snippets, versions: {} };   // 纯 Snippets：无推送目标，配置由子端自动拉取
  if (!Object.keys(payload).length) return null;
  const results = await Promise.all(targets.map(async (base) => {
    try {
      const res = await fetch(`${base}/api/sync/receive-config`, {
        signal: AbortSignal.timeout(8000),
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Sync-Key': SyncKey },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => null);
      return { domain: base, ok: res.ok, version: typeof data?.version === 'string' ? data.version : null };
    } catch { return { domain: base, ok: false, version: null }; }
  }));
  return {
    total: results.length,
    ok: results.filter((r) => r.ok).map((r) => r.domain),
    fail: results.filter((r) => !r.ok).map((r) => r.domain),
    pullBased,
    snippets,
    versions: Object.fromEntries(results.filter((r) => r.ok && r.version).map((r) => [r.domain, r.version])),
  };
};

/** 部署后推送配置（含新绑域名 DNS 生效等待）：Worker / Pages 两部署链共用同一补推助手。
 *  新绑自定义域名的 DNS 记录与边缘证书生效需要时间，绑定完成立即推送会失败——
 *  推送前等 5 秒；推送结果仍有失败域名时再等 8 秒重试一次，取最好结果。等待可见（写日志）。 */
const pushConfigAfterDeploy = async (onlyId, ctx, request, label) => {
  const tag = label ? `${label}：` : '';
  if (ctx && request) logToDb(ctx, request, '新绑域名等待 DNS 生效', `${tag}推送前等待 5 秒`);
  await new Promise((r) => setTimeout(r, 5000));
  let best = await pushConfigToNodes(onlyId).catch(() => null);
  if (best && best.fail && best.fail.length) {
    if (ctx && request) logToDb(ctx, request, '新绑域名等待 DNS 生效', `${tag}${best.fail.length} 个域名失败，8 秒后重试一次`);
    await new Promise((r) => setTimeout(r, 8000));
    const retry = await pushConfigToNodes(onlyId).catch(() => null);
    if (retry) {
      // 取最好结果：重试成功数不少于首次则采用重试结果（保留 pullBased / snippets 明细合并）
      if (retry.ok.length >= (best.ok?.length || 0)) {
        if (best.pullBased?.length && !(retry.pullBased?.length)) retry.pullBased = best.pullBased;
        if (best.snippets?.length && !(retry.snippets?.length)) retry.snippets = best.snippets;
        best = retry;
      }
    }
  }
  return best;
};

// ---------- 登录 ----------

/** POST /api/login —— 登录换取 HMAC 令牌，失败限速，锁定可由面板关闭 */

/** 登录失败限速：10 分钟窗口内最多 5 次（isolate 内存态，重启即清零） */
const LoginMaxFails = 5;
const LoginFailWindow = 10 * 60 * 1000;
const loginFails = new Map();

const apiLogin = async (request, ctx) => {
  const ip = request.headers.get('CF-Connecting-IP') || '0.0.0.0';
  const conf = await loadNodeConfig();
  if (loginFails.size > 500) for (const [k, v] of loginFails) if (Date.now() >= v.until) loginFails.delete(k);   // 过量才清过期项，锁定期内保留
  const rec = loginFails.get(ip);
  if (conf.loginLockEnabled !== false && rec && Date.now() < rec.until && rec.count >= LoginMaxFails) {
    logToDb(ctx, request, '登录锁定', `失败次数过多，已拒绝本次尝试`);
    return jsonResp({ error: '失败次数过多，请 10 分钟后再试' }, 429);
  }
  const body = await request.json().catch(() => null);
  const username = String(body?.username ?? '').trim();
  const password = String(body?.password ?? '');
  const creds = await loadAdminCreds();
  if (!creds) return jsonResp({ error: '认证服务暂不可用，请稍后再试' }, 503);
  if (!username || !safeEqual(username, creds.USERNAME) || !safeEqual(password, creds.PASSWORD)) {
    logToDb(ctx, request, '登录失败', username ? `账号: ${username}` : '账号缺失');
    if (conf.loginLockEnabled !== false) {
      const count = (rec && Date.now() < rec.until ? rec.count : 0) + 1;
      loginFails.set(ip, { count, until: Date.now() + LoginFailWindow });
    }
    return jsonResp({ error: '用户名或密码错误' }, 401);
  }
  loginFails.delete(ip);
  logToDb(ctx, request, '登录后台', `账号: ${username}`);
  return jsonResp({ token: await createAdminToken(), username });
};

// ---------- 节点列表 ----------

/** GET /api/nodelist —— 面板节点列表数据源 */
const apiNodeList = async () => {
  const conf = await loadNodeConfig();
  const inbound = String(conf.Inbound ?? 'preferred').trim().toLowerCase();
  const { speedSource, proxySource } = pickIpSources(conf);
  const [preferred, proxy] = await Promise.all([resolveIpList(speedSource), resolveIpList(proxySource)]);
  return jsonResp({
    inbound,
    proxyMode: nodeExitMode(conf),
    preferred,
    proxy,
  });
};

// ---------- 运行状态 ----------

/** GET /api/status —— 面板运行状态汇总 */
const apiStatus = async (request) => {
  const conf = await loadNodeConfig();
  const { speedSource, proxySource } = pickIpSources(conf);
  const u = new URL(request.url);
  const subKey = String(conf.SubKey ?? '').trim();
  return jsonResp({
    version: AdminVersion,
    d1Bound: !!runtimeEnv?.Senflare,
    subHost: u.host,
    subUrl: `${u.protocol}//${u.host}${conf.SubPath}/${getUuid()}`,   // 完整订阅地址
    subKeyUrl: subKey ? `${u.protocol}//${u.host}${conf.SubPath}/${subKey}` : '',   // 密钥订阅地址（未设密钥为空，前端回落 UUID）
    inbound: conf.Inbound,
    proxyMode: nodeExitMode(conf),   // 子端实际运行模式
    fakePage: conf.FakePage === true,
    speedConfigured: !!String(speedSource || '').trim(),
    proxyConfigured: !!String(proxySource || '').trim() || (conf.ChainEnabled === true && parseUpstreamEntries(conf.Upstream).length > 0),   // 链式开启时出口为上游，反代池为空不算未配置
  });
};

/** CF 多账号管理 */

/** 凭据掩码回显：不泄露任何真实凭据片段 */
const maskSecret = (v) => (v ? '********' : '');

/** 校验 CF 凭据有效性并回填 accountId */
const verifyCfAccount = async (acc) => {
  if (acc.authType === 'globalKey') {
    if (!acc.email || !acc.globalApiKey) throw new Error('Global Key 模式需要邮箱与 Global API Key');
    const list = (await cfApi(acc, '/accounts', { timeout: 10000 })) || [];
    if (!list.length) throw new Error('该凭据下没有可用的账户');
    if (!acc.accountId) acc.accountId = matchAccountByEmail(list, acc.email);
    return acc;
  }
  if (!acc.apiToken) throw new Error('Token 模式需要 API Token');
  const result = (await cfApi(acc, '/user/tokens/verify', { timeout: 10000 })) || {};
  if (result.status !== 'active') throw new Error('令牌状态异常：' + (result.status || 'unknown'));
  return acc;
};

/** 逐账号校验并回填凭据：新凭据过 CF 校验，任一失败抛错 */
const verifyAccountList = async (data, prev) => {

  // 凭据唯一真相源是数据库：apiTokenSet/globalApiKeySet=true 收前端明文（校验通过才落库），否则沿用库内原值
  const resolveCred = (val, setFlag, old) => (setFlag === true ? String(val ?? '').trim() : (old || ''));
  for (const a of data.accounts) {
    const prevRow = prev.get(String(a.id ?? ''));
    const authType = String(a.authType ?? 'token');
    const token = resolveCred(a.apiToken, a.apiTokenSet, prevRow?.apiToken);
    const gak = resolveCred(a.globalApiKey, a.globalApiKeySet, prevRow?.globalApiKey);
    a.apiToken = token;
    a.globalApiKey = gak;
    const check = authType === 'globalKey' ? gak : token;
    const allEmpty = !token && !gak;
    const modeChanged = !!prevRow && authType !== String(prevRow.authType ?? 'token');

    // 任一凭据带新值都必须过 CF 校验（含非选中模式：错凭据落库后切换模式就成了当前凭据）
    const anyNew = a.apiTokenSet === true || a.globalApiKeySet === true;
    if (allEmpty && !modeChanged) continue;
    if (modeChanged && !String(check || '').trim()) {
      throw new Error(`${a.name || '该账号'}：已切换认证方式，请填写对应的凭据`);
    }
    if (!anyNew && prevRow && !modeChanged && check === (authType === 'globalKey' ? prevRow.globalApiKey : prevRow.apiToken)) continue;
    try {
      const full = { authType, email: String(a.email ?? ''), apiToken: token, globalApiKey: gak, accountId: String(a.accountId ?? '') };
      if (a.apiTokenSet === true) await verifyCfAccount({ ...full, authType: 'token' });
      if (a.globalApiKeySet === true) {
        const v = await verifyCfAccount({ ...full, authType: 'globalKey' });
        if (v.accountId) a.accountId = v.accountId;   // 校验顺带回填 accountId
      }
      // 模式切换但凭据沿用旧值：用旧凭据按新模式验证一次（确保切过去能用）
      if (!anyNew && modeChanged) {
        const v = await verifyCfAccount(full);
        if (v.accountId) a.accountId = v.accountId;
      }
      if (!String(a.accountId ?? '') && authType === 'globalKey') {
        const v = await verifyCfAccount(full).catch(() => null);
        if (v?.accountId) a.accountId = v.accountId;
      }
    } catch (e) {
      throw new Error(`${a.name || '该账号'}：${e.message}`);
    }
  }
};

/** 整表重写账号：单事务 DELETE + INSERT，deployInfo 空值沿用库内原值，防抹掉部署记录 */
const writeAccountRows = async (db, data, prev) => {
  const ins = 'INSERT INTO cfAccounts (id,name,email,accountId,authType,apiToken,globalApiKey,quota,domains,syncDomains,status,isActive,createdAt,deployInfo,deployType,protocol) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
  await db.batch([
    db.prepare('DELETE FROM cfAccounts'),
    ...data.accounts.map((a) => {
      const prevRow = prev.get(String(a.id ?? ''));
      return db.prepare(ins).bind(
        String(a.id ?? ''), String(a.name ?? ''), String(a.email ?? ''), String(a.accountId ?? ''),
        String(a.authType ?? 'token'), String(a.apiToken ?? ''), String(a.globalApiKey ?? ''),
        Number(a.quota) || 100000, JSON.stringify(sortSyncDomains(a.domains || [])), JSON.stringify(sortSyncDomains(a.syncDomains || [])), String(a.status ?? 'normal'),
        a.id === data.activeId ? 1 : 0, String(a.createdAt ?? ''),
        String(a.deployInfo ?? '') || (prevRow?.deployInfo || ''),
        String(a.deployType === 'snippet' ? 'snippet' : 'worker'),
        ['WS', 'XHTTP'].includes(String(a.protocol ?? '').trim().toUpperCase()) ? String(a.protocol).trim().toUpperCase() : ''
      );
    }),
  ]);
};

/** GET/POST /api/cfaccounts —— 账号整表管理（掩码回显 / 删除 / 整表重写） */
const apiCfAccounts = async (request, ctx) => {
  const db = runtimeEnv?.Senflare;
  if (!db) {
    // 读返回桩、写显式报错，杜绝假成功
    if (request.method === 'POST') return jsonResp({ error: '未绑定 D1，账号数据只读' }, 400);
    return jsonResp({ accounts: [], activeId: null, noD1: true });
  }

  if (request.method === 'POST') {
    const data = await request.json().catch(() => null);
    if (data?.action === 'delete' && data.id) {
      // 删除前先查部署记录，仅清理记录内资源：Worker/Pages/D1 本体 + 经面板绑定的生产域（自定义域、路由、遗留 DNS），记录外的手动部署不碰。先查后删行，避免 waitUntil 内查不到记录
      const delRow = await db.prepare('SELECT * FROM cfAccounts WHERE id = ?').bind(String(data.id)).first().catch(() => null);
      if (ctx && delRow) ctx.waitUntil((async () => {
        try {
          const acc = { ...delRow };
          if (!acc.accountId) { try { acc.accountId = await resolveAccountId(acc); } catch (e) { } }
          if (!acc.accountId) return;
          const rec = jsonOr(delRow.deployInfo, {});
          const accPath = `/accounts/${acc.accountId}`;
          const stale = [];   // Pages 项目上的绑定域，项目删除后清遗留 DNS
          if (rec.worker) {
            // Worker：挂其名下的自定义域逐个解绑（遗留 DNS 一并清）+ 各 zone 路由 + 脚本本体
            try {
              const list = (await cfApi(acc, `${accPath}/workers/domains`)) || [];
              for (const d of list) {
                if (d.service !== rec.worker) continue;
                await cfApi(acc, `${accPath}/workers/domains/${d.id}`, { method: 'DELETE' }).catch(() => { });
                if (d.zone_id) for (const x of await clearConflictingDns(acc, d.zone_id, d.hostname)) logToDb(ctx, request, '清理遗留 DNS 记录', `${acc.name || acc.email}: ${x.type} ${x.name}`);
              }
              for (const z of await listZones(acc)) {
                const routes = (await cfApi(acc, `/zones/${z.id}/workers/routes`)) || [];
                for (const rt of routes) {
                  if (rt.script !== rec.worker) continue;
                  await cfApi(acc, `/zones/${z.id}/workers/routes/${rt.id}`, { method: 'DELETE' }).catch(() => { });
                }
              }
            } catch (e) { }
            await cfApi(acc, `${accPath}/workers/scripts/${encodeURIComponent(rec.worker)}`, { method: 'DELETE' }).catch(() => { });
          }
          if (rec.project) {
            // Pages：仅记录内项目（不做前缀兜底，手动部署的项目不动）+ 项目上的绑定域
            try {
              const doms = (await cfApi(acc, `${accPath}/pages/projects/${encodeURIComponent(rec.project)}/domains`).catch(() => [])) || [];
              stale.push(...doms.map((d) => String(d.name || '')).filter(Boolean));
              await cfApi(acc, `${accPath}/pages/projects/${encodeURIComponent(rec.project)}`, { method: 'DELETE' }).catch(() => { });
            } catch (e) { }
          }
          if (stale.length) {
            const zones = await listZones(acc).catch(() => []);
            for (const h of stale) {
              const lower = h.toLowerCase();
              const z = zones.find((x) => lower === x.name || lower.endsWith('.' + x.name));
              if (z) for (const x of await clearConflictingDns(acc, z.id, h)) logToDb(ctx, request, '清理遗留 DNS 记录', `${acc.name || acc.email}: ${x.type} ${x.name}`);
            }
          }
          if (rec.d1) {
            // D1：仅记录内同名库
            try {
              const dbs = (await cfApi(acc, `${accPath}/d1/database`)) || [];
              for (const d of dbs) if (String(d.name || '') === rec.d1) await cfApi(acc, `${accPath}/d1/database/${d.uuid}`, { method: 'DELETE' }).catch(() => { });
            } catch (e) { }
          }
        } catch (e) { }
      })());
      await db.prepare('DELETE FROM cfAccounts WHERE id = ?').bind(String(data.id)).run();
      invalidateCfHosts();
      if (ctx) ctx.waitUntil(pushConfigToNodes().catch(() => { }));
      return jsonResp({ success: true });
    }
    if (Array.isArray(data?.accounts)) {
      const prev = new Map();
      const old = await db.prepare('SELECT id, apiToken, globalApiKey FROM cfAccounts').all().catch(() => ({ results: [] }));
      for (const r of old.results || []) prev.set(String(r.id), r);
      try {
        await verifyAccountList(data, prev);
      } catch (e) {
        return jsonResp({ error: e.message }, 400);
      }
      await writeAccountRows(db, data, prev);
      invalidateCfHosts();
      if (ctx) ctx.waitUntil(pushConfigToNodes().catch(() => { }));
      return jsonResp({ success: true });
    }
    return jsonResp({ error: '参数错误' }, 400);
  }

  const { results } = await db.prepare('SELECT * FROM cfAccounts ORDER BY createdAt ASC').all().catch(() => ({ results: [] }));
  const accounts = results.map((a) => {
    const domains = jsonOr(a.domains, []), syncDomains = jsonOr(a.syncDomains, []);
    return { ...a, domains, syncDomains, apiToken: maskSecret(a.apiToken), globalApiKey: maskSecret(a.globalApiKey) };
  });
  const active = accounts.find((a) => a.isActive === 1);
  return jsonResp({ accounts, activeId: active?.id || null });
};

// ---------- 配置读写 ----------

/** 可写键白名单：节点/订阅/安全配置（ConfigKeys）+ 管理员凭据（改密后旧令牌自动失效） */
const WritableKeys = [...ConfigKeys, 'USERNAME', 'PASSWORD'];

/** 配置键 → 管理员可读名称（保存日志详情用，与面板标签一致，表外键回退原始键名） */
const ConfigLabels = {
  UUID: 'UUID', IPMode: '优选IP模式', IP: '优选IP', LocalIP: '在线优选IP',
  ProxyIPMode: '反代模式', ProxyIP: '反代IP', LocalProxyIP: '在线优选反代IP', ProxyIPMax: '兜底反代', ChainEnabled: '链式代理开关', Upstream: '上游链式出口',
  Inbound: '入站模式', Outbound: '出站模式', Protocol: '协议类型', ProtocolWorker: 'Worker 子后端协议', ProtocolSnippet: 'Snippets 子后端协议', Fp: 'TLS 指纹', Alpn: 'ALPN', Doh: 'DoH 劫持',
  ECH: 'ECH', EchDns: 'ECH DNS', EchDomain: 'ECH 解析域',
  SubName: '订阅名称', SubPath: '订阅路径', SubKey: '订阅密钥',
  BE_UUIDS: '后端专属 UUID 映射',
  FakePage: '首页伪装', FakeUrl: '伪装目标 URL', Cache: '配置缓存',
  ThemeColor: '主题色', BgSource: '登录壁纸来源', BgCustomUrl: '自定义壁纸',
  loginLockEnabled: '登录锁定', sessionTimeout: '会话时长',
  USERNAME: '管理员账号', PASSWORD: '管理员密码', AdminAvatar: '管理员头像',
};

/** GET /api/config —— 全量配置回显（PASSWORD 不回传，USERNAME 供展示） */
const apiConfigGet = async () => {
  const [conf, creds] = await Promise.all([loadNodeConfig(), loadAdminCreds()]);
  const safeConf = { ...conf };
  delete safeConf.PASSWORD;
  if (safeConf.BE_UUIDS && typeof safeConf.BE_UUIDS === 'object') safeConf.BE_UUIDS = JSON.stringify(safeConf.BE_UUIDS, null, 2);   // 对象转格式化 JSON 文本回显（面板 textarea 直接编辑）
  return jsonResp({ ...safeConf, USERNAME: creds.USERNAME });
};

/** GET /api/theme —— 全站主题色 + 登录壁纸（免鉴权，各页以服务端为准），未配置返回空串/默认值 */
const apiThemeGet = async () => {
  const conf = await loadNodeConfig();
  const color = String(conf.ThemeColor || '');
  const bgSource = String(conf.BgSource || 'builtin');
  const bgCustomUrl = String(conf.BgCustomUrl || '');
  return jsonResp({
    color: /^#[0-9a-fA-F]{6}$/.test(color) ? color : '',
    bgSource,
    bgCustomUrl,
  });
};

/** POST /api/config —— 白名单键写入（字符串原样存，其他 JSON 序列化存），RESET=true 恢复出厂 */
const apiConfigPost = async (request, ctx) => {
  const db = runtimeEnv?.Senflare;
  if (!db) return jsonResp({ error: '未绑定 D1，配置只读' }, 400);
  const data = await request.json().catch(() => null);
  if (!data || typeof data !== 'object' || Array.isArray(data)) return jsonResp({ error: '参数错误' }, 400);

  if (data.RESET === true) {
    const placeholders = ConfigKeys.map(() => '?').join(',');
    await db.prepare(`DELETE FROM config WHERE key IN (${placeholders})`).bind(...ConfigKeys).run();
    logToDb(ctx, request, '重置配置', '恢复节点/订阅默认配置');
  } else {
    const BG_SOURCES = ['builtin', 'elaina', 'yeqing', 'uapis', 'custom'];
    const entries = Object.entries(data)
      .filter(([k]) => WritableKeys.includes(k))
      .filter(([k, v]) => k !== 'ThemeColor' || (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v)))
      .filter(([k, v]) => k !== 'BgSource' || BG_SOURCES.includes(String(v).toLowerCase()))
      .map(([k, v]) => [k, k === 'BgSource' ? String(v).toLowerCase() : v]);   // 壁纸来源归一小写，前端精确匹配
    const emptyCred = entries.find(([k, v]) => (k === 'USERNAME' || k === 'PASSWORD') && !String(v ?? '').trim());
    if (emptyCred) return jsonResp({ error: `${ConfigLabels[emptyCred[0]]}不能为空` }, 400);
    // UUID 语义：留空 = 各子后端用各自 UUID（BE_UUIDS 按域名映射，未映射回落内置默认）；非空 = 统一覆盖，必须合法格式
    const badUuid = entries.find(([k, v]) => k === 'UUID' && String(v ?? '').trim() && !isValidUuid(String(v).trim()));
    if (badUuid) return jsonResp({ error: 'UUID 格式不合法（8-4-4-4-12 位十六进制）' }, 400);   // 非法值会被 getUuid 静默回落默认，必须拦在写入前
    for (const [k, v] of entries) {
      if (k !== 'BE_UUIDS') continue;
      let m = v;
      if (typeof m === 'string') {
        if (!m.trim()) continue;   // 留空 = 清除映射
        try { m = JSON.parse(m); } catch { return jsonResp({ error: 'BE_UUIDS 不是合法 JSON' }, 400); }
      }
      if (!m || typeof m !== 'object' || Array.isArray(m)) return jsonResp({ error: 'BE_UUIDS 必须是对象 {域名: UUID}' }, 400);
      for (const [h, u] of Object.entries(m)) {
        if (!/^[a-zA-Z0-9.-]+$/.test(h)) return jsonResp({ error: 'BE_UUIDS 域名无效: ' + h }, 400);
        if (u && !isValidUuid(String(u))) return jsonResp({ error: 'BE_UUIDS 的 UUID 无效: ' + h }, 400);
      }
    }
    // 头像合法性：必须是图片 DataURL（面板侧已压缩为 128px，正常仅数 KB~数十 KB；此处防直写超大值撑爆 D1 单行）
    const badAvatar = entries.find(([k, v]) => k === 'AdminAvatar' && v && (typeof v !== 'string' || !/^data:image\/(png|jpe?g|webp|gif|svg\+xml);base64,/.test(v) || v.length > 800000));
    if (badAvatar) return jsonResp({ error: '头像必须是图片且不超过 500KB' }, 400);
    if (!entries.length) return jsonResp({ error: '无有效配置项' }, 400);
    const stmt = 'INSERT INTO config (key,value,updatedAt) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updatedAt=excluded.updatedAt';
    await db.batch(entries.map(([k, v]) =>
      db.prepare(stmt).bind(k, typeof v === 'string' ? v : JSON.stringify(v), Date.now())
    ));
    const isSecurity = entries.some(([k]) => k === 'loginLockEnabled' || k === 'sessionTimeout');
    const isCreds = entries.some(([k]) => k === 'USERNAME' || k === 'PASSWORD');
    const isTheme = entries.length === 1 && entries[0][0] === 'ThemeColor';
    logToDb(ctx, request,
      isTheme ? '更换主题色' : isCreds ? '修改密码' : isSecurity ? '更新安全配置' : '保存配置',
      entries.map(([k]) => ConfigLabels[k] || k).join(', '));
  }

  // 清空本实例缓存，其他实例 5 分钟后自动更新（UUID 随 nodeConf 一并生效，无独立缓存；IP 列表即拉即用无缓存）
  nodeConf = null, nodeConfTime = 0, nodeConfFailUntil = 0;
  adminCreds = null, adminCredsTime = 0;
  if (ctx) ctx.waitUntil(pushConfigToNodes().catch(() => { }));
  return jsonResp({ status: 'ok', message: '配置保存成功' });
};

/** POST /api/nodes-sync —— 面板手动触发：把当前配置推送到各账号登记的数据同步域名 */
const apiNodesSync = async () => {
  const r = await pushConfigToNodes();
  if (!r) return jsonResp({ error: '没有可同步的目标：请先在账号中填写数据同步域名（禁用账号不参与）' }, 400);
  // Snippets 为拉取模式（子端每 5 分钟拉 /api/node-config），无推送成功数；Worker 推送才有 ok/fail
  const snipActive = (r.snippets || []).filter((s) => s.status !== 'disabled' && s.domain);
  const hasWorker = r.total > 0;
  let message;
  if (hasWorker && snipActive.length) message = `推送完成：Worker 成功 ${r.ok.length}/${r.total}；${snipActive.length} 个 Snippets 节点自动拉取（≤5 分钟生效）`;
  else if (hasWorker) message = `同步完成：成功 ${r.ok.length}/${r.total}`;
  else if (snipActive.length) message = `${snipActive.length} 个 Snippets 节点为拉取模式，配置已就绪，子端每 5 分钟自动拉取（≤5 分钟生效）`;
  else message = '同步完成';
  return jsonResp({ total: r.total, ok: r.ok, fail: r.fail, versions: r.versions, pullBased: r.pullBased, snippets: r.snippets, message });
};

// ---------- 操作日志 ----------

/** GET /api/logs?limit=N —— 面板「系统日志」数据源（默认 500，上限 MaxLogs） */
const apiLogsGet = async (request) => {
  const db = runtimeEnv?.Senflare;
  if (!db) return jsonResp([]);
  const q = Number(new URL(request.url).searchParams.get('limit'));
  const limit = Math.min(Math.max(Number.isFinite(q) && q > 0 ? Math.floor(q) : 500, 1), MaxLogs);
  const { results } = await db.prepare('SELECT * FROM logs ORDER BY id DESC LIMIT ?').bind(limit).all();
  return jsonResp(results || []);
};

/** 管理端 API 分发（/api 前缀，登录与主题色免鉴权，其余 Bearer 令牌鉴权） */
const handleApi = async (request, ctx) => {
  const path = new URL(request.url).pathname.replace(/\/+$/, '') || '/api';

  if (request.method === 'POST' && path === '/api/login') return apiLogin(request, ctx);
  if (request.method === 'GET' && path === '/api/theme') return apiThemeGet();

  // Snippets 子后端配置拉取：与推送通道共用 SyncKey 鉴权，无需管理员令牌
  // （snippets-node 无 /api/sync/receive-config，固定向本地址 GET 拉配置，键子集以外的键由其忽略）
  if (request.method === 'GET' && path === '/api/node-config') {
    if (!safeEqual(request.headers.get('X-Sync-Key'), SyncKey)) return jsonResp({ error: 'Not Found' }, 404);
    const conf = await loadNodeConfig();
    const payload = {};
    for (const k of NodeSyncKeys) if (k in conf) payload[k] = conf[k];
    if (!isValidUuid(String(payload.UUID ?? ''))) delete payload.UUID;   // 留空不下发：Snippets 子端保持自己的 UUID（BE_UUIDS 映射语义）
    payload.ProxyIPMode = nodeExitMode(conf);   // 推送通道同款归一：Snippets 子端也需要出口模式
    return jsonResp({ ...payload, version: AdminVersion });
  }

  // 构建标记：确认线上跑的 Worker 是否包含对应修复版本（公开只读，部署排障用）
  // 构建+自诊断探针：部署后开这一个 URL 即可确认版本/D1 绑定/伪装配置读取结果
  if (request.method === 'GET' && path === '/api/build') {
    const c = await loadNodeConfig();
    return jsonResp({
      build: 'fake-v15-445f-20261010',
      d1Bound: !!runtimeEnv?.Senflare,
      bindingKeys: runtimeEnv ? Object.keys(runtimeEnv).filter((k) => runtimeEnv[k] && typeof runtimeEnv[k].prepare === 'function') : [],
      fakePage: c.FakePage === true,
      fakeUrl: String(c.FakeUrl || '').slice(0, 80),
      uuidSet: !!String(c.UUID || '').trim(),
    });
  }

  const authz = request.headers.get('Authorization') || '';
  const token = authz.startsWith('Bearer ') ? authz.slice(7).trim() : '';
  if (!(await verifyAdminToken(token))) return jsonResp({ error: '未授权' }, 401);

  switch (`${request.method} ${path}`) {
    case 'GET /api/session': {
      const c = await loadAdminCreds();
      if (!c) return jsonResp({ error: '认证服务暂不可用，请稍后再试' }, 503);
      return jsonResp({ ok: true, username: c.USERNAME });
    }
    case 'POST /api/logout':
      return jsonResp({ ok: true });   // 无状态令牌：由前端丢弃即可
    case 'GET /api/config':
      return apiConfigGet();
    case 'POST /api/config':
      return apiConfigPost(request, ctx);
    case 'GET /api/nodelist':
      return apiNodeList();
    case 'GET /api/logs':
      return apiLogsGet(request);
    case 'GET /api/status':
      return apiStatus(request);
    case 'POST /api/usage': {
      const b = await request.json().catch(() => ({}));
      let usageAccName = '账号';
      try {
        if (typeof b?.id === 'string' && b.id && runtimeEnv?.Senflare) {
          const row = await runtimeEnv.Senflare
            .prepare('SELECT name, email, accountId, authType, apiToken, globalApiKey FROM cfAccounts WHERE id = ?')
            .bind(b.id).first().catch(() => null);
          if (row) {
            usageAccName = row.email || row.name || '账号';
            return jsonResp(await queryCfUsage(row));
          }
        }
        return jsonResp(await queryCfUsage({
          email: typeof b?.Email === 'string' ? b.Email : '',
          globalApiKey: typeof b?.GlobalAPIKey === 'string' ? b.GlobalAPIKey : '',
          accountId: typeof b?.AccountID === 'string' ? b.AccountID : '',
          apiToken: typeof b?.APIToken === 'string' ? b.APIToken : '',
        }));
      } catch (e) {
        const msg = String(e?.message || '查询失败');
        if (!/authentication|invalid request headers|9106/i.test(msg)) return jsonResp({ success: false, error: msg });
        if (usageAccName === '账号' && typeof b?.Email === 'string' && b.Email.trim()) usageAccName = b.Email.trim();
        return jsonResp({ success: false, error: `「${usageAccName}」凭证已失效，请更新该账号凭证` });
      }
    }
    case 'GET /api/cfaccounts':
    case 'POST /api/cfaccounts':
      return apiCfAccounts(request, ctx);
    case 'POST /api/nodes-sync':
      return apiNodesSync();
    case 'POST /api/deploy':
      return apiDeploy(request, ctx);
    default:
      return jsonResp({ error: 'Not Found' }, 404);
  }
};

// ==================== 13. CF 资源部署（跨账号批量部署编排） ====================

/** 部署 Worker/Pages 的兼容日期：取 CF 已发布的最新日期（手工部署时请同步此值） */
const DeployCompatDate = '2026-10-01';

/** 子后端 D1 数据库绑定名 */
const DeployD1BindingName = 'Senflare';

/** 部署目标账号：按 id 取行（禁用不参与） */
const getDeployAccount = async (accountId) => {
  const db = runtimeEnv?.Senflare;
  if (!db || !accountId) return null;
  const row = await db.prepare('SELECT * FROM cfAccounts WHERE id = ?').bind(String(accountId)).first().catch(() => null);
  if (!row || row.status === 'disabled') return null;
  const acc = { ...row };
  if (acc.authType === 'globalKey') {
    if (!acc.email || !acc.globalApiKey) throw new Error('该账号缺少邮箱或 Global API Key，请在「编辑账号」补填后再部署');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(acc.email))) throw new Error('该账号邮箱格式无效（CF 报 Invalid request headers 的常见原因），请在「编辑账号」修正');
  } else if (!acc.apiToken) {
    throw new Error('该账号未配置 API Token，请在「编辑账号」补填后再部署');
  }
  if (!acc.accountId) {
    try { acc.accountId = await resolveAccountId(acc); } catch { }
  }
  return acc.accountId ? acc : null;
};

/** 部署账号守卫：异常 400、缺失/禁用 404，resp 存在即返回 */
const loadDeployAcc = async (body) => {
  try {
    const acc = await getDeployAccount(body.accountId);
    if (acc) return { acc };
    return { resp: jsonResp({ error: '账号不存在或已禁用' }, 404) };
  } catch (e) {
    return { resp: jsonResp({ error: e.message }, 400) };
  }
};

/** 编排动作统一壳：异常转 JSON 并记「部署失败」日志 */
const withDeployAcc = async (body, ctx, request, fn) => {
  const { acc, resp } = await loadDeployAcc(body);
  if (resp) return resp;
  try {
    return await fn(acc);
  } catch (e) {
    logToDb(ctx, request, '部署失败', `${acc.name || acc.email}: ${e.message}`);
    return jsonResp({ error: e.message }, 502);
  }
};

/** 部署记录回写（worker/d1/project），失败不影响部署 */
const recordDeployInfo = async (accountId, patch) => {
  const db = runtimeEnv?.Senflare;
  if (!db || !accountId) return;
  const prev = await db.prepare('SELECT deployInfo FROM cfAccounts WHERE id = ?').bind(String(accountId)).first().catch(() => null);
  const info = jsonOr(prev?.deployInfo, {});
  // lastMode 供徽章显示，worker/project 双保留供切换认回
  const lastMode = patch.worker ? 'worker' : patch.project ? 'pages' : info.lastMode;
  await db.prepare('UPDATE cfAccounts SET deployInfo = ? WHERE id = ?').bind(JSON.stringify({ ...info, ...patch, lastMode }), String(accountId)).run();
};

/** 查找或创建 D1，返回 { uuid, created } */
const ensureD1 = async (acc, name) => {
  const list = (await cfApi(acc, `/accounts/${acc.accountId}/d1/database`)) || [];
  const hit = list.find((d) => d.name === name);
  if (hit) return { uuid: hit.uuid || hit.database_id, created: false };
  const created = await cfApi(acc, `/accounts/${acc.accountId}/d1/database`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name }),
  });
  return { uuid: created.uuid, created: true };
};

/** 拉取账户 zone 列表（每页 50 循环翻页） */
const listZones = async (acc) => {
  const acct = acc.accountId ? `&account.id=${acc.accountId}` : '';
  const zones = [];
  for (let page = 1; page <= 10; page++) {
    const list = (await cfApi(acc, `/zones?per_page=50&page=${page}${acct}`)) || [];
    zones.push(...list);
    if (list.length < 50) break;
  }
  return zones;
};

/** 按域名匹配 zone（精确或子域后缀） */
const findZoneByHost = async (acc, host) => {
  const lower = String(host || '').toLowerCase();
  return (await listZones(acc)).find((z) => lower === z.name || lower.endsWith('.' + z.name)) || null;
};

/** 清理同名 DNS 记录（A/AAAA/CNAME，精确名匹配），返回删除的记录：Pages 绑定冲突让位、拆资源时清遗留 */
const clearConflictingDns = async (acc, zoneId, host) => {
  const list = (await cfApi(acc, `/zones/${zoneId}/dns_records?name=${encodeURIComponent(host)}`)) || [];
  const gone = [];
  for (const rec of list) {
    if (!/^(A|AAAA|CNAME)$/.test(String(rec.type))) continue;
    await cfApi(acc, `/zones/${zoneId}/dns_records/${rec.id}`, { method: 'DELETE' }).catch(() => { });
    gone.push(rec);
  }
  return gone;
};

/** 直链代拉（绕开 CORS）：仅 https、≤10MB，返回 base64 */
const apiFetchUrl = async (body) => {
  const url = String(body.url || '').trim();
  if (!/^https:\/\//i.test(url)) return jsonResp({ error: '仅支持 https 直链' }, 400);
  const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
  if (!res.ok) return jsonResp({ error: `HTTP ${res.status}` }, 400);
  if (Number(res.headers.get('content-length') || 0) > 10 * 1024 * 1024) return jsonResp({ error: '内容超过 10MB' }, 400);   // 先查声明长度，避免大响应进内存
  const buf = new Uint8Array(await res.arrayBuffer());
  if (buf.length > 10 * 1024 * 1024) return jsonResp({ error: '内容超过 10MB' }, 400);
  return jsonResp({ success: true, base64: bytesB64(buf) });
};

/** 绑定归一为 PUT 接受的形态（保留控制台手动加的绑定） */
const cleanBinding = (b) => {
  if (b.type === 'd1' || b.type === 'd1_database') return { type: 'd1', id: b.id || b.database_id, name: b.name };
  if (b.type === 'kv_namespace') return { type: 'kv_namespace', namespace_id: b.namespace_id || b.id, name: b.name };
  const copy = { ...b };
  delete copy.last_deployed_from;
  return copy;
};

/** 上传/更新 Worker（PUT 全量替换）：合并既有绑定 + 写入 D1（既有绑定由调用方并行预取传入） */
const uploadWorkerScript = async (acc, name, source, d1Uuid, existing = []) => {
  const bindings = existing.filter((b) => b.name !== DeployD1BindingName).map(cleanBinding);
  bindings.push({ type: 'd1', id: d1Uuid, name: DeployD1BindingName });
  const isModule = /export\s+default|export\s*\{/.test(source);
  const form = new FormData();
  form.append('metadata', JSON.stringify({
    bindings,
    compatibility_date: DeployCompatDate,
    observability: { enabled: true },
    ...(isModule ? { main_module: 'worker.js' } : { body_part: 'script' }),
  }));
  form.append(isModule ? 'worker.js' : 'script', new Blob([source], { type: isModule ? 'application/javascript+module' : 'application/javascript' }), 'worker.js');
  await cfApi(acc, `/accounts/${acc.accountId}/workers/scripts/${encodeURIComponent(name)}`, { method: 'PUT', body: form, timeout: 30000 });
};

/** Worker 部署：建 D1 → 上传 → 域登记 → 推送配置 */
const apiDeployWorker = async (body, ctx, request) => {
  const { acc, resp } = await loadDeployAcc(body);
  if (resp) return resp;
  const workerName = String(body.workerName || '').trim();
  const d1Name = String(body.d1Name || '').trim();
  if (!/^[a-zA-Z0-9_-]{1,58}$/.test(workerName)) return jsonResp({ error: 'Worker 名称不合法（字母/数字/连字符/下划线，≤58）' }, 400);
  if (!d1Name) return jsonResp({ error: '缺少 D1 数据库名（必绑）' }, 400);
  const code = String(body.source?.text || '');
  if (!code.trim()) return jsonResp({ error: '源码为空' }, 400);
  if (code.length > 10 * 1024 * 1024) return jsonResp({ error: '源码超过 10MB' }, 400);
  try {
    // 建 D1 与拉取既有绑定相互独立，一轮并行（PUT 前两者都要就绪）
    const [d1, existingBindings] = await Promise.all([
      ensureD1(acc, d1Name),
      cfApi(acc, `/accounts/${acc.accountId}/workers/scripts/${encodeURIComponent(workerName)}/bindings`).catch(() => []),
    ]);
    await uploadWorkerScript(acc, workerName, code, d1.uuid, existingBindings);
    let previewUrl = '';
    // 启用子域与查询子域名并行，两者都成功才产出 previewUrl（保持原有耦合语义）
    const [enableOk, sub] = await Promise.all([
      cfApi(acc, `/accounts/${acc.accountId}/workers/scripts/${encodeURIComponent(workerName)}/subdomain`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: true }),
      }).then(() => true).catch(() => false),
      cfApi(acc, `/accounts/${acc.accountId}/workers/subdomain`).catch(() => null),
    ]);
    if (enableOk && sub?.subdomain) previewUrl = `https://${workerName}.${sub.subdomain}.workers.dev`;
    // 域登记：自定义模式整体替换，默认模式仅生产域
    const db2 = runtimeEnv?.Senflare;
    if (db2) {
      try {
        const old2 = await db2.prepare('SELECT syncDomains, domains FROM cfAccounts WHERE id = ?').bind(String(body.accountId)).first().catch(() => null);
        let syncList;
        if (Array.isArray(body.syncDomains) && body.syncDomains.length) {
          syncList = body.syncDomains;
        } else {
          syncList = previewUrl ? [previewUrl] : [];
        }
        syncList = sortSyncDomains(syncList);
        if (syncList.length) {
          const domStr = Array.isArray(body.subDomains) && body.subDomains.length ? JSON.stringify(body.subDomains) : String(old2?.domains || '[]');
          await db2.prepare('UPDATE cfAccounts SET syncDomains = ?, domains = ? WHERE id = ?').bind(JSON.stringify(syncList), domStr, String(body.accountId)).run().catch(() => { });
        }
      } catch { }
    }
    const push = await pushConfigAfterDeploy(body.accountId, ctx, request, 'Worker 部署');   // 新绑域名 DNS 生效等待 + 失败重试（单账号只推当前账号同步域名）
    await recordDeployInfo(acc.id, { worker: workerName, d1: d1Name }).catch(() => { });
    logToDb(ctx, request, '部署 Worker', `${acc.name || acc.email}: ${workerName} · D1:${d1Name} · ${d1.created ? '新建' : '复用'}`);
    return jsonResp({
      success: true,
      d1: { name: d1Name, created: d1.created },
      previewUrl,
      push: push ? { total: push.total, ok: push.ok.length, versions: push.versions } : null,
    });
  } catch (e) {
    logToDb(ctx, request, '部署失败', `${acc.name || acc.email}: ${workerName} · ${e.message}`);
    return jsonResp({ error: e.message || '部署失败' }, 502);
  }
};

/** Pages 项目名白名单（小写字母/数字/连字符，≤58） */
const PagesNameRe = /^[a-z0-9](?:[a-z0-9-]{0,56}[a-z0-9])?$/;

/** Pages 部署一 */
const apiPagesInit = async (body, ctx, request) => withDeployAcc(body, ctx, request, async (acc) => {
  const wantName = String(body.project || '').trim().toLowerCase();
  if (!PagesNameRe.test(wantName)) return jsonResp({ error: 'Pages 项目名不合法（小写字母/数字/连字符，2-58）' }, 400);
  const d1Name = String(body.d1Name || '').trim();
  if (!d1Name) return jsonResp({ error: '缺少 D1 数据库名（必绑）' }, 400);
  const branch = String(body.branch || 'main').trim() || 'main';
  let project = wantName;
  let info;
  for (let attempt = 0; ; attempt++) {
    try {
      info = await cfApi(acc, `/accounts/${acc.accountId}/pages/projects/${encodeURIComponent(project)}`);
      break;
    } catch {
      try {
        info = await cfApi(acc, `/accounts/${acc.accountId}/pages/projects`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: project, production_branch: branch }),
        });
        break;
      } catch (e) {
        const conflict = /exist|taken|unavailable|subdomain|already/i.test(String(e.message || ''));
        if (!conflict || attempt >= 2) throw e;
        project = (wantName + '-' + Math.random().toString(36).slice(2, 6)).slice(0, 58).replace(/-+$/, '');
      }
    }
  }
  const projectPath = `/accounts/${acc.accountId}/pages/projects/${encodeURIComponent(project)}`;

  // D1 绑定：已绑同名 D1 则跳过，缺失时写入
  const cfg = info?.deployment_configs || {};
  const prodD1 = cfg.production?.d1_databases?.[DeployD1BindingName];
  let d1 = null, d1Reused = !!prodD1?.id;
  
  // 预览部署关闭
  await cfApi(acc, projectPath, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ preview_deployment_setting: 'none' }),   // 尽力而为，拒绝不影响绑定
  }).catch(() => { });
  if (!d1Reused) {
    d1 = await ensureD1(acc, d1Name);

    // 双环境同写：单边更新 CF 400（实测）
    const merged = (env) => ({
      ...(cfg[env] || {}),
      observability: { enabled: true },
      compatibility_date: DeployCompatDate,
      d1_databases: { ...((cfg[env] || {}).d1_databases || {}), [DeployD1BindingName]: { id: d1.uuid } },
    });
    await cfApi(acc, projectPath, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deployment_configs: { production: merged('production'), preview: merged('preview') } }),
    });
  }
  const token = await cfApi(acc, `${projectPath}/upload-token`);
  await recordDeployInfo(acc.id, { project: project, d1: d1Name }).catch(() => { });   // 跨设备回填绑定状态
  return jsonResp({ success: true, project, uploadToken: token?.jwt || token?.token || '', d1: { name: d1Name, reused: d1Reused, created: d1 ? d1.created : false }, branch: String(info?.production_branch || branch) });
});

/** Pages 部署二：资产分片直传（令牌鉴权，≤100 文件 / 14MB 每片） */
const apiPagesUpload = async (body) => {
  const jwt = String(body.uploadToken || '');
  if (!jwt) return jsonResp({ error: '缺少上传令牌' }, 400);
  const files = Array.isArray(body.files) ? body.files : [];
  if (!files.length || files.length > 100) return jsonResp({ error: '分片为空或超过 100 个文件' }, 400);
  let total = 0;
  for (const f of files) {
    if (!/^[a-f0-9]{32}$/.test(String(f.hash || ''))) return jsonResp({ error: '非法文件哈希：' + String(f.path || '') }, 400);
    total += String(f.base64 || '').length;
  }
  if (total > 14 * 1024 * 1024) return jsonResp({ error: '分片超过 14MB，请减小单请求数量' }, 400);
  const res = await fetch(CfApiBase + '/pages/assets/upload', {
    signal: AbortSignal.timeout(30000),
    method: 'POST',
    headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(files.map((f) => ({ key: f.hash, value: f.base64, base64: true, metadata: { contentType: f.contentType || 'application/octet-stream' } }))),
  });
  let data = null;
  try { data = await res.json(); } catch { }
  if (!res.ok || data?.success === false) return jsonResp({ error: data?.errors?.[0]?.message || `资产上传失败 HTTP ${res.status}` }, 502);
  return jsonResp({ success: true, uploaded: files.length });
};

/** Pages 部署三：注册哈希 + 创建部署 */
const apiPagesCommit = async (body, ctx, request) => withDeployAcc(body, ctx, request, async (acc) => {
  const project = String(body.project || '').trim().toLowerCase();
  if (!PagesNameRe.test(project)) return jsonResp({ error: 'Pages 项目名不合法' }, 400);
  const jwt = String(body.uploadToken || '');
  if (!jwt) return jsonResp({ error: '缺少上传令牌' }, 400);
  const manifest = {};
  for (const [path, hash] of Object.entries(body.manifest || {})) {
    if (!String(path).startsWith('/') || String(path).includes('..') || !/^[a-f0-9]{32}$/.test(String(hash))) {
      return jsonResp({ error: 'manifest 非法：' + String(path) }, 400);
    }
    manifest[path] = String(hash);
  }
  // _worker.js 独立表单字段（不进资产清单），空 manifest 仅它存在时合法
  const workerB64 = String(body.worker || '').trim();
  if (!Object.keys(manifest).length && !workerB64) return jsonResp({ error: 'manifest 为空' }, 400);
  let workerBytes = null;
  if (workerB64) {
    if (workerB64.length > 14 * 1024 * 1024) return jsonResp({ error: '_worker.js 超过 14MB' }, 400);
    const bin = atob(workerB64);
    workerBytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) workerBytes[i] = bin.charCodeAt(i);
  }
  const branch = String(body.branch || 'main').trim() || 'main';
  const hashes = await fetch(CfApiBase + '/pages/assets/upsert-hashes', {
    signal: AbortSignal.timeout(15000),
    method: 'POST',
    headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ hashes: [...new Set(Object.values(manifest))] }),
  });
  if (!hashes.ok) return jsonResp({ error: `资产哈希注册失败 HTTP ${hashes.status}` }, 502);
  const form = new FormData();
  form.append('manifest', JSON.stringify(manifest));
  form.append('branch', branch);
  form.append('commit_dirty', 'false');
  form.append('commit_hash', crypto.randomUUID().replace(/-/g, '').slice(0, 40));
  form.append('commit_message', 'Deploy via Senflare Link Lite');
  if (workerBytes) form.append('_worker.js', new Blob([workerBytes], { type: 'application/javascript+module' }), '_worker.js');
  await cfApi(acc, `/accounts/${acc.accountId}/pages/projects/${encodeURIComponent(project)}/deployments`, { method: 'POST', body: form, timeout: 30000 });
  // 上线即推配置，默认模式将生产域设为唯一同步域（自定义模式已由 persist-page-domains 写入）
  const db2 = runtimeEnv?.Senflare;
  const prodUrl = `https://${project}.pages.dev`;
  if (db2 && body.defaultMode) {
    try {
      const row = await db2.prepare('SELECT syncDomains FROM cfAccounts WHERE id = ?').bind(String(acc.id)).first().catch(() => null);
      let syncList = jsonOr(row?.syncDomains, []);
      if (syncList.length !== 1 || String(syncList[0]).toLowerCase() !== prodUrl) {
        syncList = sortSyncDomains([prodUrl]);
        await db2.prepare('UPDATE cfAccounts SET syncDomains = ? WHERE id = ?').bind(JSON.stringify(syncList), String(acc.id)).run().catch(() => { });
      }
    } catch { }
  }
  await pushConfigAfterDeploy(null, ctx, request, 'Pages 部署');   // 新绑域名 DNS 生效等待 + 失败重试（等待可见，与 Worker 部署同款补推助手）
  await recordDeployInfo(acc.id, { project }).catch(() => { });
  logToDb(ctx, request, '部署 Pages', `${acc.name || acc.email}: ${project} · ${Object.keys(manifest).length} 个文件${workerBytes ? ' · 含 Functions' : ''}`);
  return jsonResp({ success: true, url: `https://${project}.pages.dev` });   // 生产域（CF 返回的 deployment url 为快照预览，不外发）
});

/** /api/deploy action 分发 */
const apiDeploy = async (request, ctx) => {
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== 'object') return jsonResp({ error: '参数错误' }, 400);
  // 顶层兜底：CF API 抛错转 JSON，避免 500 HTML
  try {
    return await apiDeployDispatch(body, ctx, request);
  } catch (e) {
    logToDb(ctx, request, '部署处理异常', String(e.message || e));   // logToDb 已吞错且同步返回，勿链 .catch
    return jsonResp({ error: '部署处理异常：' + (e.message || e) }, 500);
  }
};

const apiDeployDispatch = async (body, ctx, request) => {
  switch (body.action) {

    // ---------- Worker 部署与管理 ----------
    case 'deploy-worker': return apiDeployWorker(body, ctx, request);
    case 'list-pages': {
      const { acc, resp } = await loadDeployAcc(body);
      if (resp) return resp;
      const list = (await cfApi(acc, `/accounts/${acc.accountId}/pages/projects`)) || [];
      return jsonResp({ success: true, projects: list.map((x) => ({ name: x.name, domains: (x.domains || []).map((d) => d.name || d) })) });
    }
    case 'check-worker': {   // 扫描同名 Worker/D1 回写部署记录（手动部署接管）
      return withDeployAcc(body, ctx, request, async (acc) => {
        const name = String(body.workerName || '').trim();
        if (!name) return jsonResp({ error: '需要 workerName' }, 400);
        const list = (await cfApi(acc, `/accounts/${acc.accountId}/workers/scripts`)) || [];
        const hasWorker = list.some((w) => w.id === name);
        const dbs = (await cfApi(acc, `/accounts/${acc.accountId}/d1/database`)) || [];
        const d1 = (dbs.find((d) => d.name === name) || {}).name || '';
        if (hasWorker) await recordDeployInfo(acc.id, { worker: name, d1: d1 || name });
        return jsonResp({ success: true, hasWorker, d1: d1 || null, recorded: hasWorker });
      });
    }
    case 'list-worker-routes': {   // 扫描各 zone 指向该 Worker 的路由（部署弹窗回显已建传输域）
      return withDeployAcc(body, ctx, request, async (acc) => {
        const worker = String(body.workerName || '').trim();
        if (!worker) return jsonResp({ error: '需要 workerName' }, 400);
        const zones = await listZones(acc);
        const hosts = [];
        for (const z of zones) {
          const list = (await cfApi(acc, `/zones/${z.id}/workers/routes`).catch(() => null)) || [];
          for (const rt of list) {
            if (rt.script !== worker || !rt.pattern) continue;
            const h = String(rt.pattern).split('/')[0].toLowerCase().trim();
            if (h && hosts.indexOf(h) === -1) hosts.push(h);
          }
        }
        return jsonResp({ success: true, hosts });
      });
    }
    case 'push-config': {   // 单账号配置重推（绑定传输域完成后调用，首次自定义部署时内建推送早于绑定而失败）
      const accountId = String(body.accountId || '');
      if (!accountId) return jsonResp({ error: '需要 accountId' }, 400);
      const push = await pushConfigToNodes(accountId).catch(() => null);
      if (!push) return jsonResp({ error: '没有可同步的目标：请先登记数据同步域名（Snippets 节点需填节点域名，禁用账号不参与）' }, 400);
      return jsonResp({ success: true, total: push.total, ok: push.ok, fail: push.fail, versions: push.versions, pullBased: push.pullBased, snippets: push.snippets });
    }
    case 'pages-init': return apiPagesInit(body, ctx, request);
    case 'pages-upload': return apiPagesUpload(body);
    case 'pages-commit': return apiPagesCommit(body, ctx, request);

    // ---------- Zone 与 DNS ----------
    case 'list-zones':   // 账户域名列表（分页拉全）
      return withDeployAcc(body, ctx, request, async (acc) => {
        const zones = await listZones(acc);
        return jsonResp({ success: true, zones: zones.map((z) => ({ id: z.id, name: z.name, status: z.status })) });
      });

    // ---------- Worker 接入（自定义域 / 路由） ----------
    case 'add-worker-domain': {   // Worker 传输域绑定：同步域自定义域接管，订阅生成域仅路由规则
      const host = String(body.hostname || '').trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      const worker = String(body.workerName || '').trim();
      if (!host || !worker) return jsonResp({ error: '需要 hostname 与 workerName' }, 400);
      return withDeployAcc(body, ctx, request, async (acc) => {
        const zone = await findZoneByHost(acc, host);
        if (!zone) return jsonResp({ error: `「${host}」未找到匹配的 Zone（域名需已接入该 CF 账号）` }, 404);

        // 前置检查一轮并行预取（原逐个串行是绑定慢的主因）：跳过判定、切换抢占、清理都吃这批数据
        const [routes, pagesProjects, workerDomains, hostDns] = await Promise.all([
          cfApi(acc, `/zones/${zone.id}/workers/routes`).catch(() => []),
          cfApi(acc, `/accounts/${acc.accountId}/pages/projects`).catch(() => []),
          cfApi(acc, `/accounts/${acc.accountId}/workers/domains`).catch(() => []),
          cfApi(acc, `/zones/${zone.id}/dns_records?name=${encodeURIComponent(host)}`).catch(() => []),
        ]);
        const goneDns = [];
        const grpcOn = () => cfApi(acc, `/zones/${zone.id}/settings/grpc`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ value: 'on' }) }).catch((e) => logToDb(ctx, request, 'gRPC 开关开启失败（需 Zone Settings 编辑权限）', `${acc.name || acc.email}: ${e && e.message || e}`));   // best-effort，失败仅记日志

        // 切换抢占：Pages 占用同名时先解绑（各项目域名清单并行拉取），清指向其他 Worker 的残留路由
        await Promise.all(pagesProjects.map(async (p) => {
          const pd = (await cfApi(acc, `/accounts/${acc.accountId}/pages/projects/${encodeURIComponent(p.name)}/domains`).catch(() => [])) || [];
          for (const d of pd) {
            if (String(d.name || '').toLowerCase() !== host.toLowerCase()) continue;
            await cfApi(acc, `/accounts/${acc.accountId}/pages/projects/${encodeURIComponent(p.name)}/domains/${encodeURIComponent(host)}`, { method: 'DELETE' }).catch(() => { });
            logToDb(ctx, request, '解绑 Pages 域名（切换抢占）', `${acc.name || acc.email}: ${host} ✕ ${p.name}`);
          }
        }));
        for (const rt of routes) {
          if (String(rt.pattern || '').toLowerCase().indexOf(host.toLowerCase()) !== 0 || rt.script === worker) continue;
          await cfApi(acc, `/zones/${zone.id}/workers/routes/${rt.id}`, { method: 'DELETE' }).catch(() => { });
          logToDb(ctx, request, '清理 Worker 路由（切换抢占）', `${acc.name || acc.email}: ${rt.pattern} ✕ ${rt.script}`);
        }

        const mine = workerDomains.find((d) => String(d.hostname || '').toLowerCase() === host.toLowerCase());
        if (body.dns !== false) {
          // 数据同步域：自定义域接管（CF 托管 DNS + 路由，Worker 详情可见）
          // 已绑定同 Worker 且域名下有 DNS 记录：跳过清理与重绑（重复一键部署不翻动记录）
          if (mine && mine.service === worker && hostDns.length) {
            if (ctx) ctx.waitUntil(grpcOn());
            logToDb(ctx, request, '绑定传输域（已绑定跳过）', `${acc.name || acc.email}: ${host} → ${worker}`);
            return jsonResp({ success: true, zone: zone.name, skipped: true, removedDns: [] });
          }
          // 未绑定/换绑：先清同名手工记录（externally managed 冲突不再出现）
          for (const x of hostDns) {
            if (!/^(A|AAAA|CNAME)$/.test(String(x.type))) continue;
            await cfApi(acc, `/zones/${zone.id}/dns_records/${x.id}`, { method: 'DELETE' }).catch(() => { });
            goneDns.push(`${x.type} ${x.name}`);
            logToDb(ctx, request, '清理遗留 DNS 记录', `${acc.name || acc.email}: ${x.type} ${x.name}`);
          }
          await cfApi(acc, `/zones/${zone.id}/workers/domains`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ environment: 'production', hostname: host, service: worker, zone_id: zone.id }) });
        } else {
          // 订阅生成域：仅路由规则（节点流量 SNI 分流），DNS 由用户自指优选，旧接管残留解绑
          for (const d of workerDomains) {
            if (String(d.hostname || '').toLowerCase() !== host.toLowerCase()) continue;
            await cfApi(acc, `/accounts/${acc.accountId}/workers/domains/${d.id}`, { method: 'DELETE' }).catch(() => { });
            logToDb(ctx, request, '解绑自定义域（接管残留）', `${acc.name || acc.email}: ${host} ✕ ${d.service || ''}`);
          }
          const has = routes.some((rt) => String(rt.pattern || '').split('/')[0].toLowerCase() === host.toLowerCase() && rt.script === worker);
          if (!has) {
            try {
              await cfApi(acc, `/zones/${zone.id}/workers/routes`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pattern: `${host}/*`, script: worker }) });
            } catch (e) {
              if (!/already|exist/i.test(String(e.message || ''))) throw e;   // 已有同 pattern 路由幂等跳过
            }
          }
        }
        if (ctx) ctx.waitUntil(grpcOn());   // 开 gRPC（部分协议需要）：后台执行不挡响应
        logToDb(ctx, request, '绑定传输域', `${acc.name || acc.email}: ${host} → ${worker}（${body.dns !== false ? '自定义域' : '仅路由'}）`);
        return jsonResp({ success: true, zone: zone.name, removedDns: goneDns });
      });
    }
    case 'add-page-domain': {   // Pages 绑自定义域（需域名已接入同账号）
      const domain = String(body.domain || '').trim().replace(/^https?:\/\//, '').replace(/\/.*/, '');
      const project = String(body.project || '').trim();
      if (!domain || !project) return jsonResp({ error: '需要 domain 与 project' }, 400);
      return withDeployAcc(body, ctx, request, async (acc) => {
        // 切换抢占：解绑 Worker 域占用并清理残留路由（两份清单并行预取）
        const zone = await findZoneByHost(acc, domain);
        const [wd, routes] = await Promise.all([
          cfApi(acc, `/accounts/${acc.accountId}/workers/domains`).catch(() => []),
          cfApi(acc, `/zones/${zone?.id}/workers/routes`).catch(() => []),
        ]);
        await Promise.all(wd.map(async (d) => {
          if (String(d.hostname || '').toLowerCase() !== domain.toLowerCase()) return;
          await cfApi(acc, `/accounts/${acc.accountId}/workers/domains/${d.id}`, { method: 'DELETE' }).catch(() => { });
          logToDb(ctx, request, '解绑自定义域（切换抢占）', `${acc.name || acc.email}: ${domain} ✕ ${d.service || ''}`);
        }));
        for (const rt of routes) {
          if (!zone || String(rt.pattern || '').toLowerCase().indexOf(domain.toLowerCase()) !== 0) continue;
          await cfApi(acc, `/zones/${zone.id}/workers/routes/${rt.id}`, { method: 'DELETE' }).catch(() => { });
          logToDb(ctx, request, '清理 Worker 路由（切换抢占）', `${acc.name || acc.email}: ${rt.pattern}`);
        }
        const path = `/accounts/${acc.accountId}/pages/projects/${encodeURIComponent(project)}/domains`;
        const attach = () => cfApi(acc, path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: domain }) });
        const goneDns = [];
        try {
          await attach();
        } catch (e) {
          const msg = String(e.message || '');
          if (/externally managed/i.test(msg)) {
            if (zone) for (const x of await clearConflictingDns(acc, zone.id, domain)) {
              goneDns.push(`${x.type} ${x.name}`);
              logToDb(ctx, request, '清理遗留 DNS 记录', `${acc.name || acc.email}: ${x.type} ${x.name}`);
            }   // 同名手工记录让位
            await attach();
          } else if (!/already|exist/i.test(msg)) {
            throw e;   // 已绑定不报错
          }
        }
        // DNS 兜底：CNAME 指向生产域——已正确零写入，指向别处原位更新（模式切换残留），缺失才新建
        if (zone) {
          const prodHost = `${project}.pages.dev`;
          const recs = (await cfApi(acc, `/zones/${zone.id}/dns_records?name=${encodeURIComponent(domain)}`).catch(() => [])) || [];
          const cname = recs.find((x) => /^CNAME$/i.test(String(x.type)));
          const recBody = JSON.stringify({ type: 'CNAME', name: domain, content: prodHost, proxied: true });
          try {
            if (!cname) await cfApi(acc, `/zones/${zone.id}/dns_records`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: recBody });
            else if (String(cname.content || '').toLowerCase() !== prodHost) await cfApi(acc, `/zones/${zone.id}/dns_records/${cname.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: recBody });
          } catch (e) {
            if (!/already|exist|81057/i.test(String(e.message || ''))) logToDb(ctx, request, 'DNS 记录创建失败（非致命）', `${domain}: ${e.message || e}`);
          }
        }
        // 开 gRPC（部分协议需要，Pages 承载子后端时节点流量同样经过该 zone）：后台执行不挡响应
        if (zone && ctx) ctx.waitUntil(cfApi(acc, `/zones/${zone.id}/settings/grpc`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ value: 'on' }) }).catch((e) => logToDb(ctx, request, 'gRPC 开关开启失败（需 Zone Settings 编辑权限）', `${acc.name || acc.email}: ${e && e.message || e}`)));
        logToDb(ctx, request, '绑定 Pages 域名', `${acc.name || acc.email}: ${domain} → ${project}`);
        return jsonResp({ success: true, domain, removedDns: goneDns });
      });
    }
    case 'remove-deployment': {   // 模式切换清理：删除另一模式的旧资源（D1 同名库保留）
      const keep = String(body.keep || '').trim();
      if (keep !== 'worker' && keep !== 'pages') return jsonResp({ error: '需要 keep=worker|pages' }, 400);
      return withDeployAcc(body, ctx, request, async (acc) => {
        const db = runtimeEnv?.Senflare;
        const row = db ? await db.prepare('SELECT deployInfo FROM cfAccounts WHERE id = ?').bind(String(body.accountId)).first().catch(() => null) : null;
        const rec = jsonOr(row?.deployInfo, {});
        const accPath = `/accounts/${acc.accountId}`;
        const removed = { workers: 0, pages: 0, domains: 0 };
        if (keep === 'pages' && rec.worker) {
          // 清 Worker：域绑定 + 全部路由 + 脚本本体
          try {
            const list = (await cfApi(acc, `${accPath}/workers/domains`)) || [];
            for (const d of list) {
              if (d.service !== rec.worker) continue;
              await cfApi(acc, `${accPath}/workers/domains/${d.id}`, { method: 'DELETE' }).then(() => removed.domains++).catch(() => { });
              if (d.zone_id) for (const x of await clearConflictingDns(acc, d.zone_id, d.hostname)) logToDb(ctx, request, '清理遗留 DNS 记录', `${acc.name || acc.email}: ${x.type} ${x.name}`);   // 解绑后遗留记录一并清
            }
            for (const z of await listZones(acc)) {
              const routes = (await cfApi(acc, `/zones/${z.id}/workers/routes`)) || [];
              for (const rt of routes) {
                if (rt.script !== rec.worker) continue;
                await cfApi(acc, `/zones/${z.id}/workers/routes/${rt.id}`, { method: 'DELETE' }).catch(() => { });
              }
            }
          } catch { }
          await cfApi(acc, `${accPath}/workers/scripts/${encodeURIComponent(rec.worker)}`, { method: 'DELETE' }).then(() => removed.workers++).catch(() => { });
        }
        if (keep === 'worker' && rec.project) {
          // 清 Pages：记录项目 + senflarelink-node-* 遗留项目
          const stale = [];
          try {
            const ps = (await cfApi(acc, `${accPath}/pages/projects`)) || [];
            for (const p of ps) {
              const nm = String(p.name || '');
              if (nm !== rec.project && !nm.startsWith('senflarelink-node-')) continue;
              const doms = (await cfApi(acc, `${accPath}/pages/projects/${encodeURIComponent(nm)}/domains`).catch(() => [])) || [];
              stale.push(...doms.map((d) => String(d.name || '')).filter(Boolean));
              await cfApi(acc, `${accPath}/pages/projects/${encodeURIComponent(nm)}`, { method: 'DELETE' }).then(() => removed.pages++).catch(() => { });
            }
          } catch { }
          if (stale.length) {
            const zones = await listZones(acc).catch(() => []);
            for (const h of stale) {
              const lower = h.toLowerCase();
              const z = zones.find((x) => lower === x.name || lower.endsWith('.' + x.name));
              if (z) for (const x of await clearConflictingDns(acc, z.id, h)) logToDb(ctx, request, '清理遗留 DNS 记录', `${acc.name || acc.email}: ${x.type} ${x.name}`);   // 项目删除后遗留记录一并清
            }
          }
        }
        if (db && row) {
          const info = jsonOr(row.deployInfo, {});
          if (keep === 'pages') delete info.worker;
          if (keep === 'worker') delete info.project;
          await db.prepare('UPDATE cfAccounts SET deployInfo = ? WHERE id = ?').bind(JSON.stringify(info), String(body.accountId)).run().catch(() => { });
        }
        logToDb(ctx, request, '模式切换清理', `${acc.name || acc.email}: Worker ×${removed.workers} / Pages ×${removed.pages} / 域 ×${removed.domains}`);
        return jsonResp({ success: true, removed });
      });
    }
    case 'delete-worker-domain': {   // 解绑自定义域（主机名+服务名对账）
      const host = String(body.hostname || '').trim().toLowerCase();
      const worker = String(body.workerName || '').trim();
      if (!host || !worker) return jsonResp({ error: '需要 hostname 与 workerName' }, 400);
      return withDeployAcc(body, ctx, request, async (acc) => {
        const list = (await cfApi(acc, `/accounts/${acc.accountId}/workers/domains`)) || [];
        let removed = 0;
        for (const d of list) {
          if (String(d.hostname || '').toLowerCase() !== host || d.service !== worker) continue;
          await cfApi(acc, `/accounts/${acc.accountId}/workers/domains/${d.id}`, { method: 'DELETE' }).then(() => removed++).catch(() => { });
        }
        // 同步域在新模型下无自定义域附着：清掉指向本 Worker 生产域的同名 DNS 记录（对账移除不留死记录，用户自有记录不动）
        const sub = await cfApi(acc, `/accounts/${acc.accountId}/workers/subdomain`).catch(() => null);
        const prodHost = sub?.subdomain ? `${worker}.${sub.subdomain}.workers.dev` : '';
        if (prodHost) {
          const zone = await findZoneByHost(acc, host);
          if (zone) {
            const recs = (await cfApi(acc, `/zones/${zone.id}/dns_records?name=${encodeURIComponent(host)}`).catch(() => [])) || [];
            for (const x of recs) {
              if (!/^CNAME$/i.test(String(x.type)) || String(x.content || '').toLowerCase() !== prodHost.toLowerCase()) continue;
              await cfApi(acc, `/zones/${zone.id}/dns_records/${x.id}`, { method: 'DELETE' }).catch(() => { });
              logToDb(ctx, request, '清理遗留 DNS 记录', `${acc.name || acc.email}: ${x.type} ${x.name}`);
            }
          }
        }
        logToDb(ctx, request, '解绑自定义域', `${acc.name || acc.email}: ${host} ✕ ${worker}`);
        return jsonResp({ success: true, removed });
      });
    }
    case 'delete-page-domain': {   // 解绑 Pages 项目自定义域
      const domain = String(body.domain || '').trim();
      const project = String(body.project || '').trim();
      if (!domain || !project) return jsonResp({ error: '需要 domain 与 project' }, 400);
      return withDeployAcc(body, ctx, request, async (acc) => {
        await cfApi(acc, `/accounts/${acc.accountId}/pages/projects/${encodeURIComponent(project)}/domains/${encodeURIComponent(domain)}`, { method: 'DELETE' }).catch(() => { });
        logToDb(ctx, request, '解绑 Pages 域名', `${acc.name || acc.email}: ${domain} ✕ ${project}`);
        return jsonResp({ success: true });
      });
    }

    // ---------- 通用工具 ----------
    case 'persist-page-domains': { 
      const syncD = Array.isArray(body.syncDomains) ? body.syncDomains : [];
      const subD = Array.isArray(body.subDomains) ? body.subDomains : [];
      if (!syncD.length && !subD.length) return jsonResp({ success: true });
      const dbp = runtimeEnv?.Senflare;
      if (!dbp || !body.accountId) return jsonResp({ success: true });
      const prev = await dbp.prepare('SELECT domains FROM cfAccounts WHERE id = ?').bind(String(body.accountId)).first().catch(() => null);
      const domStr = subD.length ? JSON.stringify(subD) : String(prev?.domains || '[]');
      await dbp.prepare('UPDATE cfAccounts SET syncDomains = ?, domains = ? WHERE id = ?').bind(JSON.stringify(syncD), domStr, String(body.accountId)).run().catch(() => { });
      return jsonResp({ success: true });
    }
    case 'fetch-url': return apiFetchUrl(body);
    default: return jsonResp({ error: '未知操作：' + String(body.action) }, 400);
  }
};

// ==================== 14. 前端面板反代 ====================

/** 面板源站密钥（与密文配套的异或解密用，仅防明文扫描） */
const PanelCipherKey = 'SfLink2026Panel';

/** 面板源站密文（XOR + Base64，主备双源，替换域名后须经配套加密命令重新生成） */
const PanelOriginCipher = [
  'OxI4GR1RHR9BUz4HAgQeNgolBwUYHENXUzMKQAYC',
  'OxI4GR1RHR9BUz4HAgQeNgolBwUYHEBTUTUSQAEJJQ==',
];

/** 解密出的源站缓存（进程内一次解密，常驻复用） */
let panelOriginCache = null;

/** 当前存活源站下标 + 存活期（避免每次请求双探测） */
let panelOriginAlive = { idx: 0, until: 0 };

/** 异或解密：密文 Base64 解码后逐字节与密钥异或还原明文 */
function decryptOrigin(text) {
  const bin = atob(text);
  let out = '';
  for (let i = 0; i < bin.length; i++) {
    out += String.fromCharCode(bin.charCodeAt(i) ^ PanelCipherKey.charCodeAt(i % PanelCipherKey.length));
  }
  return out;
}

/** 面板源站清单：解密内置主备双源（进程内一次解密，常驻复用） */
function panelOrigins() {
  if (!panelOriginCache) panelOriginCache = PanelOriginCipher.map(decryptOrigin);
  return panelOriginCache;
}

/** 面板反代：主备容灾，媒体文件缓存 1h，页面与 JS/CSS no-store（面板更新即生效） */
async function servePanel(request, ctx, onError) {   // onError：面板源站全挂时的兜底响应（可选）
  const url = new URL(request.url);
  const origins = panelOrigins();
  const target = (o) => o + url.pathname + url.search;
  const isMedia = request.method === 'GET' && /\.(webp|png|jpe?g|gif|svg|ico|woff2?|ttf|otf|wasm)$/i.test(url.pathname);   // 媒体白名单才缓存，页面/JS/CSS 实时回源
  const cache = caches.default;

  if (isMedia) {
    for (const o of origins) {
      const hit = await cache.match(target(o));
      if (hit) return hit;
    }
  }

  const now = Date.now();
  const first = panelOriginAlive.until > now ? panelOriginAlive.idx : 0;
  const order = origins.length > 1 ? [first, 1 - first] : [0];

  for (const idx of order) {
    try {
      let res, hop = target(origins[idx]);
      for (let i = 0; i < 3; i++) {
        res = await fetch(hop, { redirect: 'manual', headers: { 'User-Agent': request.headers.get('User-Agent') || 'Senflare-Panel-Proxy' }, signal: AbortSignal.timeout(10000) });
        const loc = res.headers.get('location');
        if ([301, 302, 303, 307, 308].includes(res.status) && loc) {
          hop = new URL(loc, hop).href;
          continue;
        }
        break;
      }
      if (!res.ok) throw new Error('panel origin HTTP ' + res.status);
      // 媒体响应校验类型，防 HTML 兜底页被当图片缓存
      if (isMedia && !/^(image|font|audio|video)\//i.test(res.headers.get('content-type') || '') && !/^application\/wasm/i.test(res.headers.get('content-type') || '')) throw new Error('panel origin non-media type ' + res.headers.get('content-type'));
      const headers = new Headers(res.headers);
      headers.set('Cache-Control', isMedia ? 'public, max-age=3600' : 'no-store');
      const out = new Response(res.body, { status: res.status, headers });
      // 挂 waitUntil：响应返回后未挂接的 I/O 会被取消，裸挂 cache.put 缓存写不进去
      if (isMedia && ctx?.waitUntil) ctx.waitUntil(cache.put(target(origins[idx]), out.clone()).catch(() => { }));
      panelOriginAlive = { idx, until: now + 5 * 60 * 1000 };
      return out;
    } catch {
      // 失败记忆切源：主源挂掉期间后续请求直接从另一源开始，不再每个请求先撞一次主源
      if (origins.length > 1) panelOriginAlive = { idx: 1 - idx, until: Date.now() + 60 * 1000 };
    }
  }

  // 媒体全败回 404，防 200 文本被边缘缓存
  if (isMedia) return new Response('Not Found', { status: 404, headers: { 'content-type': 'text/plain; charset=UTF-8', 'cache-control': 'no-store' } });
  return onError ? onError() : unknownResp();   // 主端双源全挂：伪装开启时出伪装首页，否则默认文案挡回
}

// ==================== 15. 主路由 ====================

export default {
  async fetch(request, env, ctx) {
    runtimeEnv = env;
    // 绑定名自动识别：优先 allinone/AllinOne 别名，否则扫描全部绑定找带 prepare 方法的（D1 特征）——绑定名任意命名均可读
    if (env && !env.Senflare) {
      env.Senflare = env.AllinOne || env.allinone ||
        env[Object.keys(env).find((k) => env[k] && typeof env[k].prepare === 'function')] || null;
    }
    const url = new URL(request.url);

    // 配置置顶加载
    const conf = await loadNodeConfig();

    // 管理端 API（登录/配置/节点列表/状态/用量/CF账号，置顶避免被订阅路径或伪装页误吞）
    if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
      return handleApi(request, ctx || null);
    }

    // 订阅路由
    const subPath = conf.SubPath;
    if (url.pathname === subPath || url.pathname.startsWith(subPath + '/')) {
      return handleSubscription(request, conf, ctx || null);
    }

    // Geodata 静态代理：客户端从本域名拉取，规避 GitHub/jsDelivr 国内不可达
    if (request.method === 'GET' && url.pathname.startsWith('/geodata/')) {
      return handleGeodata(request, url.pathname.slice('/geodata/'.length), ctx || null);
    }

    // 伪装总开关：FakePage ON 且目标非空才生效；留空/关闭 = 不伪装
    const fakeOn = conf.FakePage === true && String(conf.FakeUrl || '').trim();

    // 静态资源：伪装开启时仅放行后台必需文件（精确文件名清单，不用目录前缀）——线上 SPA 兜底会让 ASSETS
    // 对任意路径回 200+index.html，目录前缀放行会把伪装站同名路径（如烟花站的 /js//css/）劫持成本站文件
    const ADMIN_STATIC = /^\/(login|sf-admin)(\.html)?$|^\/(css\/(?:admin|login|SenflareUI|theme)\.css|js\/(?:admin|admin-ui|login-ui|theme)\.js|assets\/)/i;
    if (env.ASSETS && (!fakeOn || ADMIN_STATIC.test(url.pathname))) {
      const assetRes = await env.ASSETS.fetch(request);
      if (assetRes && assetRes.status !== 404) {
        // 伪装开启时：带扩展名的非 html 路径若回成 text/html，是 SPA 兜底（文件不存在），放行给伪装代理；
        // 无扩展名路径（/sf-admin 等后台短路径）回 html 是 Pages 的正常行为，不算未命中
        const extMiss = fakeOn && assetRes.status === 200 &&
          /text\/html/i.test(assetRes.headers.get('content-type') || '') &&
          /\.[a-z0-9]+$/i.test(url.pathname) && !/\.html?$/i.test(url.pathname);
        if (!extMiss) return assetRes;
      }
    }

    if (request.method === 'GET' || request.method === 'HEAD') {
      if (fakeOn) return handleFakePage(request, ctx || null);   // 伪装开启：一切非白名单路径回源代理（含随机路径 404 回落）
      return servePanel(request, ctx || null);
    }

    // 其他方法（POST 等）：伪装开启时同样回源代理，否则统一 200 挡回
    return fakeOn ? handleFakePage(request, ctx || null) : unknownResp();
  },
};
